import { base44 } from './base44Client';


export const Supplier = base44.entities.Supplier;

export const Product = base44.entities.Product;

export const Invoice = base44.entities.Invoice;

export const InvoiceItem = base44.entities.InvoiceItem;

export const Department = base44.entities.Department;



// auth sdk:
export const User = base44.auth;