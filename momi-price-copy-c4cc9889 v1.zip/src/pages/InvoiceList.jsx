import React, { useState, useEffect } from "react";
import { Invoice, Supplier } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  FileText, 
  Search, 
  Filter,
  Eye,
  Calendar,
  DollarSign
} from "lucide-react";
import { format } from "date-fns";
import { he } from "date-fns/locale";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function InvoiceList() {
  const navigate = useNavigate();
  const [invoices, setInvoices] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [filteredInvoices, setFilteredInvoices] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    filterInvoices();
  }, [invoices, searchTerm, statusFilter]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [invoicesData, suppliersData] = await Promise.all([
        Invoice.list('-created_date'),
        Supplier.list()
      ]);
      setInvoices(invoicesData);
      setSuppliers(suppliersData);
    } catch (error) {
      console.error('Error loading data:', error);
    }
    setIsLoading(false);
  };

  const filterInvoices = () => {
    let filtered = invoices;

    if (searchTerm) {
      filtered = filtered.filter(invoice => 
        invoice.invoice_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
        invoice.store_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        invoice.receiver_name?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter !== "all") {
      filtered = filtered.filter(invoice => invoice.status === statusFilter);
    }

    setFilteredInvoices(filtered);
  };

  const getSupplierName = (supplierId) => {
    const supplier = suppliers.find(s => s.id === supplierId);
    return supplier?.name || 'ספק לא זוהה';
  };

  const statusConfig = {
    'pending_review': { label: 'ממתין לבדיקה', color: 'bg-yellow-100 text-yellow-800' },
    'approved': { label: 'אושר', color: 'bg-green-100 text-green-800' },
    'disputed': { label: 'במחלוקת', color: 'bg-red-100 text-red-800' },
    'resolved': { label: 'נפתר', color: 'bg-blue-100 text-blue-800' }
  };

  return (
    <div className="p-4 md:p-8 bg-gradient-to-br from-gray-50 to-blue-50 min-h-screen" dir="rtl">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
            כל החשבוניות
          </h1>
          <p className="text-gray-600 text-lg">
            ניהול וסקירת חשבוניות מספקים
          </p>
        </div>

        {/* Filters */}
        <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="חפש לפי מספר חשבונית, חנות או מקבל..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pr-10"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                {Object.entries(statusConfig).map(([status, config]) => (
                  <Button
                    key={status}
                    variant={statusFilter === status ? "default" : "outline"}
                    size="sm"
                    onClick={() => setStatusFilter(statusFilter === status ? "all" : status)}
                    className={statusFilter === status ? "bg-blue-600" : ""}
                  >
                    {config.label}
                  </Button>
                ))}
                <Button
                  variant={statusFilter === "all" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setStatusFilter("all")}
                  className={statusFilter === "all" ? "bg-blue-600" : ""}
                >
                  הכל
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Invoice List */}
        <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-600" />
              חשבוניות ({filteredInvoices.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {Array(6).fill(0).map((_, i) => (
                  <div key={i} className="p-4 border rounded-xl animate-pulse">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-gray-200 rounded-xl"></div>
                        <div className="space-y-2">
                          <div className="h-4 bg-gray-200 rounded w-48"></div>
                          <div className="h-3 bg-gray-200 rounded w-32"></div>
                        </div>
                      </div>
                      <div className="h-6 bg-gray-200 rounded w-20"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredInvoices.length > 0 ? (
              <div className="space-y-4">
                {filteredInvoices.map((invoice) => {
                  const statusInfo = statusConfig[invoice.status];
                  
                  return (
                    <div 
                      key={invoice.id}
                      className="p-4 border-2 border-gray-200 rounded-xl hover:border-blue-300 hover:bg-blue-50 transition-all duration-200 cursor-pointer"
                      onClick={() => navigate(createPageUrl("InvoiceDetails") + `?id=${invoice.id}`)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4 flex-1">
                          <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
                            <FileText className="w-6 h-6 text-blue-600" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="font-semibold text-gray-900">
                                חשבונית #{invoice.invoice_number}
                              </h3>
                              <Badge className={statusInfo.color}>
                                {statusInfo.label}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-gray-600">
                              <span>{getSupplierName(invoice.supplier_id)}</span>
                              <span>•</span>
                              <span>{invoice.store_name}</span>
                              <span>•</span>
                              <span>{format(new Date(invoice.invoice_date), 'dd/MM/yyyy', { locale: he })}</span>
                            </div>
                            <div className="text-xs text-gray-500 mt-1">
                              מקבל: {invoice.receiver_name}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-4">
                          <div className="text-left">
                            <p className="text-sm text-gray-500">סכום כולל</p>
                            <p className="text-lg font-bold">₪{invoice.total_amount?.toFixed(2)}</p>
                            {invoice.potential_savings > 0 && (
                              <p className="text-xs text-green-600 font-medium">
                                חיסכון: ₪{invoice.potential_savings.toFixed(2)}
                              </p>
                            )}
                          </div>
                          
                          <div className="text-center">
                            {invoice.overcharge_count > 0 && (
                              <Badge variant="destructive" className="mb-2">
                                {invoice.overcharge_count} חריגים
                              </Badge>
                            )}
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                navigate(createPageUrl("InvoiceDetails") + `?id=${invoice.id}`);
                              }}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-12">
                <FileText className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  אין חשבוניות למסננים שנבחרו
                </h3>
                <p className="text-gray-600 mb-4">
                  נסה להתאים את המסננים או לחפש משהו אחר
                </p>
                <Button 
                  variant="outline"
                  onClick={() => {
                    setSearchTerm("");
                    setStatusFilter("all");
                  }}
                >
                  נקה מסננים
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}