
import React, { useState, useEffect } from "react";
import { User, Supplier } from "@/components/utils/entityImports"; // Changed import path for User and Supplier
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Settings as SettingsIcon,
  User as UserIcon,
  Building2,
  Bell,
  Shield,
  Save,
  CheckCircle,
  AlertCircle,
  Truck,
  HelpCircle,
  Download,
  DatabaseBackup,
  Activity // Added Activity icon for system monitoring tab
} from "lucide-react";

import UserProfile from "../components/settings/UserProfile";
import StoreSettings from "../components/settings/StoreSettings";
import NotificationSettings from "../components/settings/NotificationSettings";
import SupplierManagement from "../components/settings/SupplierManagement";
// New imports for System tab
import SystemMonitor from "../components/settings/SystemMonitor"; // Assuming this component exists
import DataBackup from "../components/settings/DataBackup"; // Assuming this component exists

export default function Settings() {
  const [currentUser, setCurrentUser] = useState(null);
  const [suppliers, setSuppliers] = useState([]);
  const [activeTab, setActiveTab] = useState('profile');
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setIsLoading(true);
    try {
      const [userData, suppliersData] = await Promise.all([
        User.me(),
        Supplier.list()
      ]);
      setCurrentUser(userData);
      setSuppliers(suppliersData);
    } catch (error) {
      console.error('Error loading settings:', error);
      setError('שגיאה בטעינת ההגדרות');
    }
    setIsLoading(false);
  };

  const handleSaveProfile = async (profileData) => {
    setIsSaving(true);
    setError(null);
    try {
      await User.updateMyUserData(profileData);
      setCurrentUser(prev => ({ ...prev, ...profileData }));
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (error) {
      console.error('Error saving profile:', error);
      setError('שגיאה בשמירת הפרופיל');
    }
    setIsSaving(false);
  };

  const handleSaveSupplier = async (supplierData) => {
    setIsSaving(true);
    setError(null);
    try {
      if (supplierData.id) {
        await Supplier.update(supplierData.id, supplierData);
        setSuppliers(prev => prev.map(s => s.id === supplierData.id ? { ...s, ...supplierData } : s));
      } else {
        const newSupplier = await Supplier.create(supplierData);
        setSuppliers(prev => [...prev, newSupplier]);
      }
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (error) {
      console.error('Error saving supplier:', error);
      setError('שגיאה בשמירת פרטי הספק');
    }
    setIsSaving(false);
  };

  const tabs = [
    { id: 'profile', label: 'פרופיל אישי', icon: UserIcon },
    { id: 'store', label: 'הגדרות חנות', icon: Building2 },
    { id: 'notifications', label: 'התראות', icon: Bell },
    { id: 'suppliers', label: 'ניהול ספקים', icon: Truck },
    { id: 'system', label: 'מערכת וגיבוי', icon: Activity } // New tab for system settings
  ];

  if (isLoading) {
    return (
      <div className="w-full max-w-4xl mx-auto">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-slate-200 rounded w-48"></div>
          <div className="grid md:grid-cols-4 gap-4">
            {Array(4).fill(0).map((_, i) => (
              <div key={i} className="h-12 bg-slate-200 rounded"></div>
            ))}
          </div>
          <div className="h-96 bg-slate-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-6xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <SettingsIcon className="w-8 h-8 text-[hsl(var(--primary))]" />
          <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900">
            הגדרות מערכת
          </h1>
        </div>
        <p className="text-slate-600 text-lg">
          ניהול פרופיל, ספקים והגדרות מערכת
        </p>
      </div>

      {/* Success/Error Messages */}
      {saveSuccess && (
        <Alert className="mb-6 border-[hsl(var(--success))] bg-[hsl(var(--success-light))]">
          <CheckCircle className="h-4 w-4 text-[hsl(var(--success))]" />
          <AlertDescription className="text-[hsl(var(--success-dark))]">
            השינויים נשמרו בהצלחה!
          </AlertDescription>
        </Alert>
      )}

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 mb-8">
        {tabs.map((tab) => (
          <Button
            key={tab.id}
            variant={activeTab === tab.id ? "default" : "outline"}
            onClick={() => setActiveTab(tab.id)}
            className={`gap-2 ${
              activeTab === tab.id 
                ? 'bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]' 
                : 'hover:bg-[hsl(var(--primary-light))] hover:text-[hsl(var(--primary))]'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </Button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          {activeTab === 'profile' && (
            <UserProfile 
              user={currentUser}
              onSave={handleSaveProfile}
              isSaving={isSaving}
            />
          )}

          {activeTab === 'store' && (
            <StoreSettings 
              user={currentUser}
              onSave={handleSaveProfile}
              isSaving={isSaving}
            />
          )}

          {activeTab === 'notifications' && (
            <NotificationSettings 
              user={currentUser}
              onSave={handleSaveProfile}
              isSaving={isSaving}
            />
          )}

          {activeTab === 'suppliers' && (
            <SupplierManagement 
              suppliers={suppliers}
              onSaveSupplier={handleSaveSupplier}
              isSaving={isSaving}
            />
          )}

          {activeTab === 'system' && (
            <div className="space-y-6">
              <SystemMonitor />
              <DataBackup />
            </div>
          )}

        </div>

        {/* Sidebar Info */}
        <div className="space-y-6">
          {/* User Info Card */}
          <Card className="shadow-lg border-0 bg-[hsl(var(--card))]">
            <CardHeader>
              <CardTitle className="text-lg font-bold flex items-center gap-2">
                <UserIcon className="w-5 h-5 text-[hsl(var(--primary))]" />
                פרטי משתמש
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-[hsl(var(--primary-light))] rounded-full flex items-center justify-center">
                    <span className="text-[hsl(var(--primary))] font-bold">
                      {currentUser?.full_name?.charAt(0) || 'U'}
                    </span>
                  </div>
                  <div>
                    <p className="font-semibold">{currentUser?.full_name || 'משתמש'}</p>
                    <p className="text-sm text-slate-500">{currentUser?.email}</p>
                  </div>
                </div>
                <div className="pt-3 border-t">
                  <Badge variant={currentUser?.role === 'admin' ? 'default' : 'secondary'}>
                    {currentUser?.role === 'admin' ? 'מנהל' : 'משתמש'}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* System Info */}
          <Card className="shadow-lg border-0 bg-[hsl(var(--card))]">
            <CardHeader>
              <CardTitle className="text-lg font-bold flex items-center gap-2">
                <Shield className="w-5 h-5 text-[hsl(var(--success))]" />
                מידע מערכת
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-600">גרסת מערכת:</span>
                  <span className="font-semibold">v1.2.0</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">ספקים פעילים:</span>
                  <span className="font-semibold">{suppliers.filter(s => s.is_active).length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">עדכון אחרון:</span>
                  <span className="font-semibold">היום</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="shadow-lg border-0 bg-[hsl(var(--card))]">
            <CardHeader>
              <CardTitle className="text-lg font-bold">פעולות מהירות</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                 <Button variant="outline" className="w-full justify-start gap-2 text-sm" onClick={() => alert('תכונה זו תהיה זמינה בקרוב: גיבוי נתונים לענן')}>
                  <DatabaseBackup className="w-4 h-4"/>
                  גיבוי נתונים
                </Button>
                <Button variant="outline" className="w-full justify-start gap-2 text-sm" onClick={() => alert('תכונה זו תהיה זמינה בקרוב: ייצוא דו"ח מערכת כ-CSV')}>
                  <Download className="w-4 h-4"/>
                  ייצא דו״ח מערכת
                </Button>
                <Button asChild variant="outline" className="w-full justify-start gap-2 text-sm">
                  <a href="mailto:support@momi.app">
                    <HelpCircle className="w-4 h-4"/>
                    צור קשר עם תמיכה
                  </a>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
