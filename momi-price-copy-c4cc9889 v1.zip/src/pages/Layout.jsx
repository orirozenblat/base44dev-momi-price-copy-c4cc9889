
import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  LayoutDashboard,
  Camera,
  Package,
  AlertTriangle,
  TrendingUp,
  Settings,
  Menu,
  X,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import ErrorBoundary from "@/components/ErrorBoundary";
import ConnectionMonitor from "@/components/connectivity/ConnectionMonitor";
import RetryQueueStatus from "@/components/connectivity/RetryQueueStatus";
import SystemHealth from "@/components/SystemHealth";

const navigationItems = [
  {
    title: "לוח בקרה",
    url: createPageUrl("Dashboard"),
    icon: LayoutDashboard,
  },
  {
    title: "צילום חשבונית",
    url: createPageUrl("InvoiceCapture"),
    icon: Camera,
  },
  {
    title: "קטלוג מוצרים",
    url: createPageUrl("ProductCatalog"),
    icon: Package,
  },
  {
    title: "התראות מחיר",
    url: createPageUrl("PriceAlerts"),
    icon: AlertTriangle,
  }
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div dir="rtl" className="min-h-screen flex w-full bg-slate-50">
      <ConnectionMonitor />
      <SystemHealth />

      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 bg-white border-l shadow-sm z-20">
        <div className="flex items-center gap-3 p-4 border-b">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-800 to-blue-500 rounded-lg flex items-center justify-center">
            <TrendingUp className="w-6 h-6 text-white" />
          </div>
          <div className="flex flex-col">
            <span className="font-bold text-lg text-gray-900">MomiPrice</span>
            <span className="text-xs text-slate-500">Price Management</span>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4">
          <div className="space-y-2">
            <div className="text-sm font-medium text-gray-500 mb-2 px-2">ניווט</div>
            {navigationItems.map((item) => (
              <Link 
                key={item.title}
                to={item.url} 
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors duration-200 ${
                  location.pathname === item.url 
                    ? 'bg-blue-800 text-white' 
                    : 'text-slate-700 hover:bg-blue-50 hover:text-blue-800'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.title}</span>
                {item.url === createPageUrl("PriceAlerts") && (
                  <Badge variant="destructive" className="mr-auto">3</Badge>
                )}
              </Link>
            ))}
            
            <div className="text-sm font-medium text-gray-500 mb-2 mt-6 px-2 pt-4 border-t">מערכת</div>
            <Link 
              to={createPageUrl("Settings")}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors duration-200 ${
                location.pathname === createPageUrl("Settings") 
                  ? 'bg-blue-800 text-white' 
                  : 'text-slate-700 hover:bg-blue-50 hover:text-blue-800'
              }`}
            >
              <Settings className="w-5 h-5" />
              <span className="font-medium">הגדרות</span>
            </Link>
          </div>
        </div>
        
        <div className="mt-auto p-4 text-xs text-center text-slate-500 border-t">
          © 2024 MomiPrice
        </div>
      </aside>

      {/* Main content area */}
      <main className="flex-1 flex flex-col lg:pr-64">
        {/* Mobile Header */}
        <header className="lg:hidden flex items-center justify-between p-4 border-b bg-white shadow-sm z-30">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-800 to-blue-500 rounded-md flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-md">MomiPrice</span>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setMobileMenuOpen(true)} 
          >
            <Menu className="w-6 h-6" />
          </Button>
        </header>
        
        {/* Mobile Menu Overlay */}
        {mobileMenuOpen && (
          <div 
            className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-40"
            onClick={() => setMobileMenuOpen(false)}
          />
        )}
        
        {/* Mobile Sidebar */}
        <div className={`lg:hidden fixed top-0 right-0 bottom-0 w-72 bg-white z-50 transform transition-transform duration-300 ease-in-out shadow-lg ${
          mobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
        }`}>
          <div className="flex items-center justify-between p-4 border-b">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-800 to-blue-500 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-lg">MomiPrice</span>
                <span className="text-xs text-slate-500">Price Management</span>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={() => setMobileMenuOpen(false)}>
              <X className="w-6 h-6" />
            </Button>
          </div>
          
          <div className="flex-1 overflow-y-auto p-4">
            <div className="space-y-2">
              <div className="text-sm font-medium text-gray-500 mb-2 px-2">ניווט</div>
              {navigationItems.map((item) => (
                <Link 
                  key={item.title}
                  to={item.url} 
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors duration-200 ${
                    location.pathname === item.url 
                      ? 'bg-blue-800 text-white' 
                      : 'text-slate-700 hover:bg-blue-50 hover:text-blue-800'
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="font-medium text-base">{item.title}</span>
                  {item.url === createPageUrl("PriceAlerts") && (
                    <Badge variant="destructive" className="mr-auto">3</Badge>
                  )}
                </Link>
              ))}
              
              <div className="text-sm font-medium text-gray-500 mb-2 mt-6 px-2 pt-4 border-t">מערכת</div>
              <Link 
                to={createPageUrl("Settings")} 
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors duration-200 ${
                  location.pathname === createPageUrl("Settings") 
                    ? 'bg-blue-800 text-white' 
                    : 'text-slate-700 hover:bg-blue-50 hover:text-blue-800'
                }`}
              >
                <Settings className="w-5 h-5" />
                <span className="font-medium text-base">הגדרות</span>
              </Link>
            </div>
          </div>
          
          <div className="mt-auto p-4 text-xs text-center text-slate-500 border-t">
            © 2024 MomiPrice
          </div>
        </div>

        {/* Page Content */}
        <div className="flex-1 overflow-auto bg-slate-50 p-4 md:p-6 lg:p-8">
          <div className="mb-4">
            <RetryQueueStatus />
          </div>
          
          <ErrorBoundary>
            {children}
          </ErrorBoundary>
        </div>
      </main>
    </div>
  );
}
