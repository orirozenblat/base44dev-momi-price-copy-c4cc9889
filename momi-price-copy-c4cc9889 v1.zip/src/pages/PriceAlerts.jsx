
import React, { useState, useEffect } from "react";
import { InvoiceItem } from "@/api/entities";
import { Invoice } from "@/api/entities";
import { Product } from "@/api/entities";
import { Supplier } from "@/api/entities";
import { SendEmail } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  AlertTriangle, 
  Phone, 
  Mail,
  TrendingDown,
  CheckCircle,
  Clock,
  DollarSign,
  Info
} from "lucide-react";

import AlertsList from "../components/alerts/AlertsList";
import AlertDetails from "../components/alerts/AlertDetails"; // Changed from AlertsDetails to AlertDetails
import NegotiationPanel from "../components/alerts/NegotiationPanel";
import AlertsStats from "../components/alerts/AlertsStats";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function PriceAlerts() {
  const navigate = useNavigate();
  const [allAlerts, setAllAlerts] = useState([]);
  const [filteredAlerts, setFilteredAlerts] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [selectedAlert, setSelectedAlert] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [showNegotiation, setShowNegotiation] = useState(false);
  const [productFilter, setProductFilter] = useState(null);
  
  const urlParams = new URLSearchParams(window.location.search);
  const productId = urlParams.get('product');

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    const applyProductFilter = async () => {
        if (productId && !productFilter) {
            try {
                const products = await Product.list();
                const product = products.find(p => p.id === productId);
                if (product) {
                    setProductFilter(product);
                }
            } catch (e) {
                console.error("Failed to load product for filtering", e);
            }
        } else if (!productId && productFilter) {
          setProductFilter(null);
        }
    }
    applyProductFilter();
  }, [productId, productFilter]);

  useEffect(() => {
    let alertsToFilter = allAlerts;
    if (productFilter) {
        alertsToFilter = allAlerts.filter(a => a.barcode === productFilter.barcode);
    }
    setFilteredAlerts(alertsToFilter);
    if (alertsToFilter.length > 0) {
      setSelectedAlert(alertsToFilter[0]);
    } else {
      setSelectedAlert(null);
    }
  }, [allAlerts, productFilter]);


  const loadData = async () => {
    setIsLoading(true);
    try {
      // Get overcharged items with invoice details
      const overchargedItems = await InvoiceItem.filter({ is_overcharged: true }, '-created_date');
      const invoiceIds = [...new Set(overchargedItems.map(item => item.invoice_id))];
      
      const [invoicesData, suppliersData] = await Promise.all([
        Promise.all(invoiceIds.map(id => Invoice.list().then(invoices => invoices.find(inv => inv.id === id)))),
        Supplier.list()
      ]);
      
      setAllAlerts(overchargedItems);
      setFilteredAlerts(overchargedItems);
      setInvoices(invoicesData.filter(Boolean));
      setSuppliers(suppliersData);
    } catch (error) {
      console.error('Error loading alerts:', error);
    }
    setIsLoading(false);
  };

  const getInvoiceForAlert = (alert) => {
    if (!alert) return null;
    return invoices.find(invoice => invoice.id === alert.invoice_id);
  };

  const getSupplierForInvoice = (invoice) => {
    if (!invoice) return null;
    return suppliers.find(s => s.id === invoice.supplier_id);
  }

  const handleResolveAlert = async (alertId, resolution) => {
    setActionLoading(true);
    try {
      const alertToUpdate = allAlerts.find(a => a.id === alertId);
      if (alertToUpdate) {
        await InvoiceItem.update(alertId, {
          is_overcharged: false,
          resolution_notes: resolution,
          resolved_date: new Date().toISOString()
        });
        
        await loadData();
        setSelectedAlert(null);
      }
    } catch (error) {
      console.error('Error resolving alert:', error);
    }
    setActionLoading(false);
  };

  const handleSendEmail = async (supplierEmail, subject, body) => {
    if (!supplierEmail) {
      alert('לא נמצא אימייל עבור ספק זה.');
      return;
    }
    setActionLoading(true);
    try {
      await SendEmail({
        to: supplierEmail,
        subject: subject,
        body: body,
        from_name: "מומי - ניהול רכישות"
      });
      
      alert('האימייל נשלח בהצלחה!');
    } catch (error) {
      console.error('Error sending email:', error);
      alert('שגיאה בשליחת האימייל');
    }
    setActionLoading(false);
  };

  const calculateStats = (alertsToStat) => {
    const criticalAlerts = alertsToStat.filter(alert => alert.overcharge_percentage >= 15);
    const moderateAlerts = alertsToStat.filter(alert => 
      alert.overcharge_percentage >= 8 && alert.overcharge_percentage < 15
    );
    const totalSavings = alertsToStat.reduce((sum, alert) => 
      sum + (alert.price_difference * alert.quantity), 0
    );

    return {
      total: alertsToStat.length,
      critical: criticalAlerts.length,
      moderate: moderateAlerts.length,
      totalSavings
    };
  };

  const stats = calculateStats(filteredAlerts);
  const selectedInvoice = getInvoiceForAlert(selectedAlert);
  const selectedSupplier = getSupplierForInvoice(selectedInvoice);

  return (
    <div className="w-full max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-6 lg:mb-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-2">
              התראות מחיר
            </h1>
            <p className="text-slate-600 text-lg">
              ניהול חריגי מחיר ומשא ומתן עם ספקים
            </p>
          </div>
          {selectedAlert && (
            <Button 
              onClick={() => setShowNegotiation(true)}
              className="bg-[hsl(var(--primary))] hover:bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] gap-2"
            >
              <Phone className="w-4 h-4" />
              פתח משא ומתן
            </Button>
          )}
        </div>
        {productFilter && (
          <Alert className="mt-4 border-[hsl(var(--primary))] bg-[hsl(var(--primary-light))] text-[hsl(var(--primary))]">
            <Info className="h-4 w-4" />
            <AlertDescription className="text-blue-800">
              מציג התראות עבור המוצר: <strong>{productFilter.product_title}</strong>. 
              <Button variant="link" onClick={() => navigate(createPageUrl("PriceAlerts"))} className="p-1 h-auto text-blue-800">נקה סינון</Button>
            </AlertDescription>
          </Alert>
        )}
      </div>

      {/* Stats */}
      <AlertsStats stats={stats} />

      {/* Main Content */}
      <div className="grid lg:grid-cols-3 gap-6 lg:gap-8 mt-6">
        {/* Alerts List */}
        <div className="lg:col-span-2">
          <AlertsList 
            alerts={filteredAlerts}
            invoices={invoices}
            suppliers={suppliers}
            isLoading={isLoading}
            selectedAlert={selectedAlert}
            onSelectAlert={setSelectedAlert}
            onResolveAlert={handleResolveAlert}
            actionLoading={actionLoading}
          />
        </div>

        {/* Side Panel */}
        <div className="space-y-6">
          {selectedAlert ? (
            <AlertDetails 
              alert={selectedAlert}
              invoice={selectedInvoice}
              supplier={selectedSupplier}
              onResolve={handleResolveAlert}
              onSendEmail={handleSendEmail}
              actionLoading={actionLoading}
            />
          ) : (
            <Card className="shadow-lg border-0 bg-[hsl(var(--card))]">
              <CardContent className="p-8 text-center flex flex-col justify-center items-center h-full">
                <AlertTriangle className="w-12 h-12 mx-auto mb-4 text-slate-300" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  בחר התראה
                </h3>
                <p className="text-slate-600">
                  בחר התראת מחיר מהרשימה כדי לראות פרטים או לטפל בה.
                </p>
              </CardContent>
            </Card>
          )}

          {/* Quick Actions */}
          <Card className="shadow-lg border-0 bg-[hsl(var(--card))]">
            <CardHeader>
              <CardTitle className="text-lg font-bold">פעולות מהירות</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Button variant="outline" className="w-full justify-start gap-2" onClick={() => alert('תכונה זו תהיה זמינה בקרוב: שליחת מייל לכל הספקים עם חריגות')}>
                  <Mail className="w-4 h-4" />
                  שלח מייל לכל הספקים
                </Button>
                <Button variant="outline" className="w-full justify-start gap-2" onClick={() => alert('תכונה זו תהיה זמינה בקרוב: יצירת דו"ח PDF של כל חריגות המחיר')}>
                  <TrendingDown className="w-4 h-4" />
                  דו״ח חריגי מחיר
                </Button>
                <Button variant="outline" className="w-full justify-start gap-2" onClick={() => alert(`סך החיסכון הפוטנציאלי מכל ההתראות המוצגות הוא: ₪${stats.totalSavings.toFixed(2)}`)}>
                  <DollarSign className="w-4 h-4" />
                  חשב חיסכון פוטנציאלי
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Negotiation Panel */}
      {showNegotiation && selectedAlert && (
        <NegotiationPanel 
          alert={selectedAlert}
          invoice={selectedInvoice}
          supplier={selectedSupplier}
          onClose={() => setShowNegotiation(false)}
          onSendEmail={handleSendEmail}
          onResolve={handleResolveAlert}
          actionLoading={actionLoading}
        />
      )}
    </div>
  );
}
