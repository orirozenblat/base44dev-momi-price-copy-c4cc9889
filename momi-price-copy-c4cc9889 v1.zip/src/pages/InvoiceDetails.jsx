
import React, { useState, useEffect } from "react";
import { Invoice } from "@/api/entities";
import { InvoiceItem } from "@/api/entities";
import { Product } from "@/api/entities";
import { Supplier } from "@/api/entities";
import { SendEmail } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  ArrowRight, 
  Phone, 
  Mail, 
  CheckCircle, 
  AlertTriangle,
  FileText,
  Calendar,
  User,
  Building2,
  DollarSign,
  Clock
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import { he } from "date-fns/locale";

export default function InvoiceDetails() {
  const navigate = useNavigate();
  const [invoice, setInvoice] = useState(null);
  const [invoiceItems, setInvoiceItems] = useState([]);
  const [supplier, setSupplier] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [notes, setNotes] = useState('');

  // Get invoice ID from URL parameters
  const urlParams = new URLSearchParams(window.location.search);
  const invoiceId = urlParams.get('id');

  useEffect(() => {
    if (invoiceId) {
      loadInvoiceDetails();
    }
  }, [invoiceId]);

  const loadInvoiceDetails = async () => {
    setIsLoading(true);
    try {
      const invoices = await Invoice.list();
      const currentInvoice = invoices.find(inv => inv.id === invoiceId);
      
      if (currentInvoice) {
        setInvoice(currentInvoice);
        setNotes(currentInvoice.notes || '');
        
        // Load invoice items
        const items = await InvoiceItem.filter({ invoice_id: invoiceId });
        setInvoiceItems(items);
        
        // Load supplier
        const suppliers = await Supplier.list();
        const currentSupplier = suppliers.find(sup => sup.id === currentInvoice.supplier_id);
        setSupplier(currentSupplier);
      }
    } catch (error) {
      console.error('Error loading invoice details:', error);
    }
    setIsLoading(false);
  };

  const handleStatusUpdate = async (newStatus) => {
    setActionLoading(true);
    try {
      await Invoice.update(invoiceId, { 
        status: newStatus,
        notes: notes
      });
      setInvoice(prev => ({ ...prev, status: newStatus, notes }));
    } catch (error) {
      console.error('Error updating status:', error);
    }
    setActionLoading(false);
  };

  const handleSendEmail = async () => {
    if (!supplier?.email) return;
    
    setActionLoading(true);
    try {
      const overchargedItems = invoiceItems.filter(item => item.is_overcharged);
      const totalSavings = overchargedItems.reduce((sum, item) => 
        sum + (item.price_difference * item.quantity), 0
      );

      const emailBody = `
שלום ${supplier.contact_person},

בהמשך לחשבונית מספר ${invoice.invoice_number} מתאריך ${format(new Date(invoice.invoice_date), 'dd/MM/yyyy', { locale: he })},

זיהינו הפרשי מחיר בפריטים הבאים:

${overchargedItems.map(item => 
  `• ${item.product_name} - מחיר מקטלוג: ₪${item.catalog_price?.toFixed(2)}, מחיר שחויב: ₪${item.unit_price?.toFixed(2)} (הפרש: +${item.overcharge_percentage?.toFixed(1)}%)`
).join('\n')}

סה"כ חיסכון פוטנציאלי: ₪${totalSavings.toFixed(2)}

אנא בדקו ותקנו את המחירים בהתאם למחירון.

בברכה,
צוות רכישות
      `;

      await SendEmail({
        to: supplier.email,
        subject: `תיקון מחירים - חשבונית ${invoice.invoice_number}`,
        body: emailBody
      });

      alert('האימייל נשלח בהצלחה!');
    } catch (error) {
      console.error('Error sending email:', error);
      alert('שגיאה בשליחת האימייל');
    }
    setActionLoading(false);
  };

  const statusConfig = {
    'pending_review': { label: 'ממתין לבדיקה', color: 'bg-yellow-100 text-yellow-800', icon: Clock },
    'approved': { label: 'אושר', color: 'bg-green-100 text-green-800', icon: CheckCircle },
    'disputed': { label: 'במחלוקת', color: 'bg-red-100 text-red-800', icon: AlertTriangle },
    'resolved': { label: 'נפתר', color: 'bg-blue-100 text-blue-800', icon: CheckCircle }
  };

  if (isLoading) {
    return (
      <div className="p-4 md:p-8 bg-gradient-to-br from-gray-50 to-blue-50 min-h-screen" dir="rtl">
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-64"></div>
            <div className="h-64 bg-gray-200 rounded"></div>
            <div className="h-96 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!invoice) {
    return (
      <div className="p-4 md:p-8 bg-gradient-to-br from-gray-50 to-blue-50 min-h-screen" dir="rtl">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">חשבונית לא נמצאה</h1>
          <Button onClick={() => navigate(createPageUrl("Dashboard"))}>
            חזור ללוח הבקרה
          </Button>
        </div>
      </div>
    );
  }

  const statusInfo = statusConfig[invoice.status];
  const overchargedItems = invoiceItems.filter(item => item.is_overcharged);
  const totalSavings = overchargedItems.reduce((sum, item) => 
    sum + (item.price_difference * item.quantity), 0
  );

  return (
    <div className="p-4 md:p-8 bg-gradient-to-br from-gray-50 to-blue-50 min-h-screen" dir="rtl">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Button 
              variant="outline" 
              onClick={() => navigate(createPageUrl("Dashboard"))}
              className="gap-2"
            >
              <ArrowRight className="w-4 h-4" />
              חזור
            </Button>
            <h1 className="text-3xl font-bold text-gray-900">
              חשבונית #{invoice.invoice_number}
            </h1>
            <Badge className={statusInfo.color}>
              {statusInfo.label}
            </Badge>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Invoice Header */}
            <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-blue-600" />
                  פרטי חשבונית
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <Building2 className="w-4 h-4 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-500">ספק</p>
                        <p className="font-semibold">{supplier?.name || 'לא זוהה'}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Calendar className="w-4 h-4 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-500">תאריך חשבונית</p>
                        <p className="font-semibold">
                          {format(new Date(invoice.invoice_date), 'dd/MM/yyyy', { locale: he })}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <User className="w-4 h-4 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-500">מקבל</p>
                        <p className="font-semibold">{invoice.receiver_name}</p>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <DollarSign className="w-4 h-4 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-500">סכום כולל</p>
                        <p className="font-semibold text-lg">₪{invoice.total_amount?.toFixed(2)}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <AlertTriangle className="w-4 h-4 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-500">חריגי מחיר</p>
                        <p className="font-semibold text-red-600">{invoice.overcharge_count}</p>
                      </div>
                    </div>
                    {totalSavings > 0 && (
                      <div className="flex items-center gap-3">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        <div>
                          <p className="text-sm text-gray-500">חיסכון פוטנציאלי</p>
                          <p className="font-semibold text-green-600">₪{totalSavings.toFixed(2)}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Invoice Items */}
            <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>פריטים בחשבונית ({invoiceItems.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {invoiceItems.map((item, index) => (
                    <div 
                      key={index}
                      className={`p-4 rounded-xl border-2 ${
                        item.is_overcharged ? 'border-red-200 bg-red-50' : 'border-green-200 bg-green-50'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900 mb-2">
                            {item.product_name}
                          </h3>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                            <div>
                              <span className="text-gray-500">כמות:</span>
                              <p className="font-semibold">{item.quantity}</p>
                            </div>
                            <div>
                              <span className="text-gray-500">מחיר יחידה:</span>
                              <p className="font-semibold">₪{item.unit_price?.toFixed(2)}</p>
                            </div>
                            {item.catalog_price && (
                              <div>
                                <span className="text-gray-500">מחיר מקטלוג:</span>
                                <p className="font-semibold text-green-600">₪{item.catalog_price.toFixed(2)}</p>
                              </div>
                            )}
                            <div>
                              <span className="text-gray-500">סה"כ:</span>
                              <p className="font-semibold">₪{item.total_price?.toFixed(2)}</p>
                            </div>
                          </div>
                        </div>
                        <div className="text-left">
                          {item.is_overcharged ? (
                            <Badge variant="destructive">
                              +{item.overcharge_percentage?.toFixed(1)}%
                            </Badge>
                          ) : (
                            <Badge className="bg-green-100 text-green-800">
                              ✓ תקין
                            </Badge>
                          )}
                        </div>
                      </div>
                      {item.is_overcharged && (
                        <div className="mt-3 p-3 bg-red-100 rounded-lg">
                          <p className="text-sm font-semibold text-red-800">
                            חיסכון פוטנציאלי: ₪{(item.price_difference * item.quantity).toFixed(2)}
                          </p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Notes */}
            <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>הערות</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="הוסף הערות על החשבונית..."
                  rows={4}
                />
                <Button 
                  onClick={() => handleStatusUpdate(invoice.status)}
                  disabled={actionLoading}
                  className="mt-3"
                >
                  שמור הערות
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar Actions */}
          <div className="space-y-6">
            {/* Status Actions */}
            <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>פעולות</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {invoice.status === 'pending_review' && (
                  <>
                    <Button 
                      onClick={() => handleStatusUpdate('approved')}
                      disabled={actionLoading}
                      className="w-full bg-green-600 hover:bg-green-700 gap-2"
                    >
                      <CheckCircle className="w-4 h-4" />
                      אשר חשבונית
                    </Button>
                    {overchargedItems.length > 0 && (
                      <Button 
                        onClick={() => handleStatusUpdate('disputed')}
                        disabled={actionLoading}
                        variant="outline"
                        className="w-full gap-2"
                      >
                        <AlertTriangle className="w-4 h-4" />
                        סמן כמחלוקת
                      </Button>
                    )}
                  </>
                )}
                
                {invoice.status === 'disputed' && (
                  <Button 
                    onClick={() => handleStatusUpdate('resolved')}
                    disabled={actionLoading}
                    className="w-full bg-blue-600 hover:bg-blue-700 gap-2"
                  >
                    <CheckCircle className="w-4 h-4" />
                    סמן כנפתר
                  </Button>
                )}

                {supplier?.email && (
                  <Button 
                    onClick={handleSendEmail}
                    disabled={actionLoading}
                    variant="outline"
                    className="w-full gap-2"
                  >
                    <Mail className="w-4 h-4" />
                    שלח מייל לספק
                  </Button>
                )}

                {supplier?.phone && (
                  <Button 
                    variant="outline"
                    className="w-full gap-2"
                    onClick={() => window.open(`tel:${supplier.phone}`)}
                  >
                    <Phone className="w-4 h-4" />
                    התקשר לספק
                  </Button>
                )}
              </CardContent>
            </Card>

            {/* Supplier Info */}
            {supplier && (
              <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>פרטי ספק</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm text-gray-500">שם החברה</p>
                      <p className="font-semibold">{supplier.name}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">איש קשר</p>
                      <p className="font-semibold">{supplier.contact_person}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">טלפון</p>
                      <p className="font-semibold">{supplier.phone}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">אימייל</p>
                      <p className="font-semibold">{supplier.email}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">תנאי תשלום</p>
                      <p className="font-semibold">{supplier.payment_terms}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Invoice Image */}
            {invoice.image_urls && invoice.image_urls[0] && (
              <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>תמונת חשבונית</CardTitle>
                </CardHeader>
                <CardContent>
                  <img 
                    src={invoice.image_urls[0]} 
                    alt="Invoice" 
                    className="w-full rounded-lg border cursor-pointer"
                    onClick={() => window.open(invoice.image_urls[0], '_blank')}
                  />
                  <Button 
                    variant="outline" 
                    className="w-full mt-3"
                    onClick={() => window.open(invoice.image_urls[0], '_blank')}
                  >
                    הצג בגודל מלא
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
