
import React, { useState, useEffect, useRef } from "react";
import { Product } from "@/api/entities";
import { Supplier } from "@/api/entities";
import { ExtractDataFromUploadedFile, UploadFile } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Upload,
  Search,
  Filter,
  Package,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  FileSpreadsheet
} from "lucide-react";

import CatalogUpload from "../components/catalog/CatalogUpload";
import ProductList from "../components/catalog/ProductList";
import ProductFilters from "../components/catalog/ProductFilters";
import UploadProgress from "../components/catalog/UploadProgress";

// Import enhanced NLP utilities
import { HebrewTextProcessor } from "../components/utils/textProcessing";
import { parseCsv } from "../components/utils/csvParser"; // Import the new parser
import { SmartCache } from "../components/utils/smartCache"; // Import the cache utility


export default function ProductCatalog() {
  const [products, setProducts] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSupplier, setSelectedSupplier] = useState("all");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [isLoading, setIsLoading] = useState(true);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadError, setUploadError] = useState(null);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const fileInputRef = useRef(null);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    filterProducts();
  }, [products, searchTerm, selectedSupplier, selectedCategory]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      // Only cache lightweight data like suppliers list
      let suppliersData = SmartCache.get('suppliers');
      
      if (!suppliersData) {
        suppliersData = await Supplier.filter({ is_active: true });
        SmartCache.set('suppliers', suppliersData, 600); // Cache for 10 minutes
      }

      // Always fetch products fresh - they're too large to cache efficiently
      const productsData = await Product.list('-updated_date');
      
      setProducts(productsData);
      setSuppliers(suppliersData);
    } catch (error) {
      console.error('Error loading data:', error);
    }
    setIsLoading(false);
  };

  const clearAllProducts = async () => {
    if (!confirm('האם אתה בטוח שברצונך למחוק את כל המוצרים? פעולה זו לא ניתנת לביטול!')) {
      return;
    }

    setIsClearing(true);
    try {
      const allProducts = await Product.list('-updated_date', 10000);
      console.log(`Found ${allProducts.length} products to delete. Processing one by one to avoid rate limits.`);
      
      if (allProducts.length === 0) {
        alert('אין מוצרים למחיקה');
        setIsClearing(false);
        return;
      }
      
      let deletedCount = 0;
      let alreadyDeletedCount = 0;
      let errorCount = 0;
      const MAX_ERRORS = 20;
      
      for (let i = 0; i < allProducts.length; i++) {
        const product = allProducts[i];
        
        try {
          await Product.delete(product.id);
          deletedCount++;
          console.log(`Deleted product ${deletedCount}/${allProducts.length}: ${product.id}`);
        } catch (error) {
          if (error.message.includes('404') || error.message.includes('Entity not found')) {
            alreadyDeletedCount++;
            console.log(`Product ${product.id} was already deleted`);
          } else if (error.message.includes('429') || (error.response && error.response.status === 429) || error.message.includes('Rate limit exceeded')) {
            console.warn(`Rate limit hit at product ${i + 1}. Waiting 30 seconds before continuing...`);
            
            alert(`הגענו למגבלת הקצב של השרת. 
                   ממתין 30 שניות לפני המשך...
                   
                   התקדמות עד כה:
                   נמחקו: ${deletedCount}
                   כבר היו מחוקים: ${alreadyDeletedCount}
                   נותרו: ${allProducts.length - i} מוצרים`);
            
            // Wait 30 seconds and retry the same product
            await new Promise(resolve => setTimeout(resolve, 30000));
            i--; // Retry the same product
            continue;
          } else {
            errorCount++;
            console.error(`Failed to delete product ${product.id}:`, error);
            
            // Guardrail: Stop if too many errors
            if (errorCount >= MAX_ERRORS) {
              alert(`נתקלנו ב-${errorCount} שגיאות במחיקת המוצרים. 
                     המערכת עוצרת כדי למנוע נזק נוסף.
                     
                     מוצרים שנמחקו בהצלחה: ${deletedCount}
                     מוצרים שכבר היו מחוקים: ${alreadyDeletedCount}
                     
                     אנא בדוק את החיבור לאינטרנט ונסה שוב מאוחר יותר.
                     אם הבעיה נמשכת, פנה לתמיכה טכנית.`);
              break;
            }
          }
        }
        
        // Add a delay between each request to be very gentle with the server
        await new Promise(resolve => setTimeout(resolve, 200)); // 200ms delay between requests
      }
      
      const totalProcessed = deletedCount + alreadyDeletedCount;
      console.log(`Deletion complete. Deleted: ${deletedCount}, Already deleted: ${alreadyDeletedCount}, Errors: ${errorCount}`);
      
      SmartCache.cleanup();
      await loadData();
      
      const remainingProducts = await Product.list('-updated_date', 10000);
      
      if (remainingProducts.length === 0) {
        alert(`כל המוצרים נמחקו בהצלחה! 
               נמחקו: ${deletedCount} מוצרים
               כבר היו מחוקים: ${alreadyDeletedCount} מוצרים
               סה"כ: ${totalProcessed} מוצרים`);
      } else {
        const successMessage = errorCount >= MAX_ERRORS ? 'נעצרה בגלל שגיאות רבות' : 'הושלמה';
        alert(`מחיקה ${successMessage}: 
               נמחקו: ${deletedCount} מוצרים
               כבר היו מחוקים: ${alreadyDeletedCount} מוצרים  
               שגיאות: ${errorCount} מוצרים
               נותרו: ${remainingProducts.length} מוצרים
               
               ${errorCount < MAX_ERRORS ? 'נסה שוב למחוק את השאר.' : 'בדוק את החיבור ונסה מאוחר יותר.'}`);
      }
      
    } catch (error) {
      console.error('Error clearing products:', error);
      alert('שגיאה במחיקת המוצרים: ' + error.message);
    } finally {
      setIsClearing(false);
    }
  };

  const filterProducts = () => {
    let filtered = products;

    if (searchTerm) {
      filtered = filtered.filter(product =>
        product.product_title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.brand?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.barcode.includes(searchTerm)
      );
    }

    if (selectedSupplier !== "all") {
      filtered = filtered.filter(product => product.supplier_id === selectedSupplier);
    }

    if (selectedCategory !== "all") {
      // Ensure we are comparing strings to strings
      filtered = filtered.filter(product => String(product.dept_code) === String(selectedCategory));
    }

    setFilteredProducts(filtered);
  };

  // Enhanced helper functions using NLP
  const extractAmountValue = (size) => {
    if (!size) return 1; // Default to 1 if size is empty
    const sizeInfo = HebrewTextProcessor.extractSizeInfo(size); // Use the NLP processor here
    return sizeInfo.value || 1; // Return the extracted value, default to 1
  };

  const mapSizeType = (sizeType) => {
    if (!sizeType) return 'יחידה';

    // Mapping of common size type strings to normalized Hebrew units
    const mapping = {
      'g': 'גרם', 'gram': 'גרם', 'גרם': 'גרם',
      'kg': 'קילו', 'kilo': 'קילו', 'קילו': 'קילו',
      'ml': 'מ״ל', 'מל': 'מ״ל',
      'l': 'ליטר', 'liter': 'ליטר', 'ליטר': 'ליטר',
      'unit': 'יחידה', 'יחידה': 'יחידה',
      'pack': 'חבילה', 'חבילה': 'חבילה', 'חב': 'חבילה'
    };

    return mapping[sizeType.toLowerCase()] || 'יחידה'; // Default to 'יחידה' if no match
  };

  const extractPackaging = (title) => {
    if (!title) return 'אריזה';

    const cleanedTitle = HebrewTextProcessor.normalizeProductName(title); // Normalize title before checking keywords
    const packagingMap = {
      'בקבוק': ['בקבוק', 'bottle'],
      'שקית': ['שקית', 'שק', 'bag'],
      'קופסה': ['קופסה', 'קופס', 'קרטון', 'box'],
      'פחית': ['פחית', 'פח', 'can'],
      'אריזה': ['אריזה', 'חבילה', 'package'] // General packaging type
    };

    for (const [type, keywords] of Object.entries(packagingMap)) {
      if (keywords.some(keyword => cleanedTitle.toLowerCase().includes(keyword))) {
        return type;
      }
    }

    return 'אריזה'; // Default packaging type
  };

  const mapProductDataFromItem = (item) => {
    console.log('Processing item:', JSON.stringify(item, null, 2));
    
    // Create a lowercase version of the item for case-insensitive lookups.
    const lowerCaseItem = Object.fromEntries(
        Object.entries(item).map(([k, v]) => [k.toLowerCase(), v])
    );

    const getField = (aliases, defaultValue = null) => {
        for (const alias of aliases) {
            // All aliases are lowercase, look up in the lowerCaseItem
            const value = lowerCaseItem[alias];
            if (value !== undefined && value !== null && String(value).trim() !== '' && String(value).trim().toLowerCase() !== 'ריק') {
                return value;
            }
        }
        return defaultValue;
    };

    // ALL ALIASES ARE NOW LOWERCASE FOR RELIABLE MATCHING
    const code = getField(['code', 'barcode', 'id', 'מקט']);
    const productName = getField(['name', 'alias', 'product_name', 'product_title', 'שם המוצר'], '');
    const supplier = getField(['supplier', 'supplier name', 'supplier_name', 'שם ספק'], '');
    const department = getField(['department', 'שם מחלקה', 'grp', 'קבוצה', 'dept_code'], 'כללי');
    const brandFromTitle = HebrewTextProcessor.extractBrandFromTitle(productName);
    const brand = getField(['trade_mark', 'brand', 'manufacturer', 'מותג'], brandFromTitle || '');

    const size = getField(['weight', 'size', 'גודל']);
    const sizeType = getField(['size_type', 'סוג גודל']);

    const sizeFromName = HebrewTextProcessor.extractSizeInfo(productName);
    const amountValue = size ? extractAmountValue(size) : sizeFromName.value;
    const amountUnit = sizeType ? mapSizeType(sizeType) : sizeFromName.unit;

    // Use your exact CSV headers - cost_brutto and cost
    const costPrice = parseFloat(getField(['cost_brutto', 'cost', 'cost_price', 'מחיר עלות'], 0));
    
    const retailPrice = parseFloat(getField(['sale_price', 'retail_price', 'price', 'מחיר מכירה'], 0));
    
    const salePrice = retailPrice > 0 ? retailPrice : (costPrice ? costPrice * 1.2 : 0);

    const mappedData = {
        barcode: code ? String(code).trim() : null,
        product_title: productName ? HebrewTextProcessor.normalizeProductName(productName) : null,
        brand: String(brand).trim(),
        amount_value: amountValue,
        amount_unit: String(amountUnit),
        packaging: extractPackaging(productName),
        supplier_id: supplier ? String(supplier).trim() : null,
        cost_price: costPrice,
        retail_price: salePrice,
        dept_code: String(department).trim(),
    };

    console.log('Mapped data:', JSON.stringify(mappedData, null, 2)); // Better logging
    return mappedData;
  };

  const processExtractedProducts = async (products) => {
    try {
      console.log('Raw products data:', JSON.stringify(products, null, 2));

      if (!products || !Array.isArray(products) || products.length === 0) {
        throw new Error('לא נמצאו מוצרים בנתונים שהתקבלו');
      }
      
      const processedProducts = products.map((item, index) => {
        console.log(`Processing item ${index}:`, JSON.stringify(item, null, 2));
        const mappedData = mapProductDataFromItem(item);
        
        // Generate sku_id only if barcode and supplier_id are available
        const sku_id = (mappedData.barcode && mappedData.supplier_id)
            ? `${mappedData.barcode}_${mappedData.supplier_id}`.replace(/[^a-zA-Z0-9_\u0590-\u05FF]/g, '_')
            : `AUTO_SKU_${Date.now()}_${index}`; // Fallback SKU ID

        return {
            ...mappedData,
            sku_id: sku_id,
            last_updated: new Date().toISOString()
        };
      });

      // Enhanced validation with detailed debugging and error counting
      let validationErrorCount = 0;
      const MAX_VALIDATION_ERRORS = 20; // Define max validation errors for the guardrail
      
      const validProducts = processedProducts.filter((product, index) => {
        // Find the original item that generated this product for detailed logging
        const originalItem = products[index];

        const hasBarcode = product.barcode && product.barcode.trim() && product.barcode !== 'undefined' && product.barcode !== '0' && product.barcode.toLowerCase() !== 'ריק';
        const hasTitle = product.product_title && product.product_title.trim() && product.product_title !== 'undefined' && product.product_title.toLowerCase() !== 'ריק';
        const hasSupplier = product.supplier_id && product.supplier_id.trim() && product.supplier_id !== 'undefined' && product.supplier_id.toLowerCase() !== 'ריק';
        const hasCostPrice = product.cost_price && product.cost_price > 0;

        const isValid = hasBarcode && hasTitle && hasSupplier && hasCostPrice;
        
        if (!isValid) {
          validationErrorCount++;
          console.log(`Product ${index} failed validation:`, {
            originalItem: originalItem, // This is the raw data from the file
            mappedProduct: product,   // This is the data after our mapping attempt
            validation: {
              hasBarcode: hasBarcode ? '✓' : '✗ (missing/empty barcode)',
              hasTitle: hasTitle ? '✓' : '✗ (missing/empty product name)', 
              hasSupplier: hasSupplier ? '✓' : '✗ (missing/empty supplier)',
              hasCostPrice: hasCostPrice ? '✓' : '✗ (missing/zero cost price)'
            },
            rawValues: {
              code: originalItem.code,
              name: originalItem.name,
              alias: originalItem.alias,
              supplier: originalItem.supplier,
              'supplier name': originalItem['supplier name'],
              cost: originalItem.cost,
              cost_brutto: originalItem.cost_brutto
            }
          });
          
          // Guardrail: Stop processing if too many validation errors
          if (validationErrorCount >= MAX_VALIDATION_ERRORS) {
            console.error(`Too many validation errors (${validationErrorCount}), stopping validation process`);
            throw new Error(`נתקלנו ב-${validationErrorCount} שגיאות אימות במהלך עיבוד הקובץ.
                           זה מצביע על בעיה במבנה הקובץ או בנתונים.
                           
                           בדוק שהקובץ מכיל את העמודות הנדרשות:
                           - ברקוד (code/barcode)
                           - שם מוצר (name/product_name/alias)
                           - ספק (supplier/supplier_name)
                           - מחיר עלות (cost/cost_price/cost_brutto)
                           
                           אם הקובץ נראה תקין, נסה לשמור אותו שוב כ-CSV או פנה לתמיכה טכנית.`);
          }
        }
        
        return isValid;
      });

      console.log(`Valid products: ${validProducts.length} out of ${processedProducts.length} (${validationErrorCount} validation errors)`);

      if (validProducts.length === 0) {
        // Show first few rejected products for debugging
        const sampleRejected = processedProducts.slice(0, 3);
        console.error('Sample rejected products:', JSON.stringify(sampleRejected, null, 2));
        throw new Error(`לא נמצאו מוצרים תקינים מתוך ${processedProducts.length} מוצרים.
        נמצאו ${validationErrorCount} שגיאות אימות.
        
        בדוק שהעמודות הבאות קיימות ומכילות נתונים:
        - ברקוד (code/barcode)
        - שם מוצר (name/alias/product_name) 
        - ספק (supplier/supplier_name)
        - מחיר עלות (cost_brutto/cost/cost_price)
        
        ${validationErrorCount >= MAX_VALIDATION_ERRORS ? 
          'יותר מדי שגיאות - יתכן שמבנה הקובץ לא נתמך.' : 
          'בדוק את מבנה הקובץ ונסה שוב.'}`);
      }

      // Bulk create products
      console.log('Creating products in database...');
      await Product.bulkCreate(validProducts);

      // Reload data after successful upload (no caching needed)
      SmartCache.remove('products'); // Specifically remove products cache
      await loadData();

      setUploadProgress(100);
      setUploadSuccess(true);

      setTimeout(() => {
        setUploadSuccess(false);
        setUploadProgress(0);
      }, 3000);

      console.log(`Successfully created ${validProducts.length} products`);

    } catch (error) {
      console.error('Error processing products:', error);
      throw new Error(`שגיאה בשמירת המוצרים למסד הנתונים: ${error.message}`);
    }
  };

  const getStats = () => {
    const categories = [...new Set(products.map(p => p.dept_code))].length;
    const avgPrice = products.length > 0 ?
      products.reduce((sum, p) => sum + (p.cost_price || 0), 0) / products.length : 0;

    return {
      totalProducts: products.length,
      categories,
      avgPrice,
      suppliers: suppliers.length
    };
  };

  const stats = getStats();

  const handleFileUpload = async (file) => {
    if (!file) return;

    // Check file type first
    const allowedTypes = ['.csv', '.json'];
    const fileExtension = file.name.toLowerCase().slice(file.name.lastIndexOf('.'));

    if (!allowedTypes.includes(fileExtension)) {
      setUploadError(`סוג קובץ לא נתמך: ${fileExtension}. אנא השתמש בקבצי CSV או JSON בלבד.`);
      return;
    }

    // Check file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      setUploadError('הקובץ גדול מדי. גודל מקסימלי: 10MB');
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);
    setUploadError(null);
    setUploadSuccess(false);

    let productsData = null; // Initialize productsData here
    let uploadedFileUrl = null; // To store URL if upload is needed

    try {
      setUploadProgress(10);

      // --- Attempt AI Extraction for CSV files by first uploading ---
      if (fileExtension === '.csv') {
        try {
          const uploadResult = await UploadFile({ file });
          if (!uploadResult || !uploadResult.file_url) {
            throw new Error('שגיאה ראשונית בהעלאת קובץ');
          }
          uploadedFileUrl = uploadResult.file_url; // Store the URL
          setUploadProgress(20);

          const extractResult = await ExtractDataFromUploadedFile({
            file_url: uploadedFileUrl,
            json_schema: {
              type: "object",
              properties: {
                data: {
                  type: "array",
                  items: { type: "object" } // Keep it generic
                }
              }
            }
          });
          
          setUploadProgress(40); // Adjusted progress for AI extraction
          console.log('AI Extract Result:', JSON.stringify(extractResult, null, 2));

          // Robustly check for extracted data from various possible structures
          if (extractResult.output) {
            if (Array.isArray(extractResult.output)) {
              productsData = extractResult.output;
            } else if (extractResult.output.data && Array.isArray(extractResult.output.data)) {
              productsData = extractResult.output.data;
            } else {
                 const key = Object.keys(extractResult.output).find(k => Array.isArray(extractResult.output[k]));
                 if(key) productsData = extractResult.output[key];
            }
          }
        } catch (aiError) {
          console.warn("AI extraction failed, proceeding to fallback parser. Error:", aiError.message);
          // productsData remains null/empty, triggering fallback if necessary
        }
      }
      
      // --- Fallback Method for CSV or Direct Parsing for JSON ---
      if (fileExtension === '.csv' && (!productsData || productsData.length === 0)) {
        console.log("Triggering fallback manual CSV parser.");
        setUploadProgress(75); // Update progress for fallback
        
        productsData = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = (event) => {
            try {
              const text = event.target.result;
              const parsedData = parseCsv(text);
              resolve(parsedData);
            } catch (e) {
              reject(e);
            }
          };
          reader.onerror = (error) => reject(error);
          reader.readAsText(file, 'UTF-8'); // Specify encoding
        });
      } else if (fileExtension === '.json') {
        // For JSON, read directly from file, no AI extraction via URL is typical
        setUploadProgress(60);
        productsData = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = (event) => {
            try {
              const text = event.target.result;
              const jsonData = JSON.parse(text);
              // Expect either { products: [...] } or a direct array
              resolve(jsonData.products || (Array.isArray(jsonData) ? jsonData : []));
            } catch (e) {
              reject(e);
            }
          };
          reader.onerror = (error) => reject(error);
          reader.readAsText(file, 'UTF-8'); // Read JSON as text
        });
        setUploadProgress(70); // Adjusted progress for JSON parsing
      }
      
      // --- Process whichever data we got (from AI, CSV fallback, or JSON) ---
      if (productsData && Array.isArray(productsData) && productsData.length > 0) {
        console.log(`Processing ${productsData.length} products.`);
        setUploadProgress(80);
        await processExtractedProducts(productsData);
      } else {
        throw new Error('לא הצלחנו לחלץ נתונים מהקובץ. בדוק את תקינות הקובץ ומבנה העמודות.');
      }

    } catch (error) {
      console.error('Upload error (main catch):', error);

      // Provide user-friendly error messages based on common issues
      if (error.message.includes('400')) {
        setUploadError('שגיאה בהעלאת הקובץ - פורמט קובץ לא תקין או גודל גדול מדי.');
      } else if (error.message.includes('Unsupported file type')) {
        setUploadError('סוג קובץ לא נתמך. אנא השתמש בקבצי CSV או JSON בלבד.');
      } else if (error.message.includes('Network')) {
        setUploadError('שגיאת רשת - בדוק את החיבור לאינטרנט ונסה שוב.');
      } else {
        setUploadError(error.message || 'שגיאה בעיבוד הקובץ. אנא בדוק את הפורמט ונסה שוב.');
      }
    } finally {
        setIsUploading(false);
    }
  };


  return (
    <div className="w-full max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
              קטלוג מוצרים
            </h1>
            <p className="text-slate-600 text-lg">
              ניהול מחירי ספקים ועדכון קטלוג
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={clearAllProducts}
              disabled={isClearing || products.length === 0}
              variant="outline"
              className="text-red-600 border-red-300 hover:bg-red-50 gap-2"
            >
              <AlertCircle className="w-4 h-4" />
              {isClearing ? 'מוחק...' : 'מחק הכל'}
            </Button>
            <Button
              onClick={() => fileInputRef.current?.click()}
              className="bg-blue-700 hover:bg-blue-800 text-white gap-2"
              disabled={isUploading}
            >
              <Upload className="w-4 h-4" />
              העלה מחיון
            </Button>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="shadow-lg border-0 bg-[hsl(var(--card))]">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">סה״כ מוצרים</p>
                <p className="text-2xl font-bold text-gray-900">{stats.totalProducts}</p>
              </div>
              <Package className="w-8 h-8 text-blue-900" />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg border-0 bg-[hsl(var(--card))]">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">קטגוריות</p>
                <p className="text-2xl font-bold text-gray-900">{stats.categories}</p>
              </div>
              <Filter className="w-8 h-8 text-blue-700" />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg border-0 bg-[hsl(var(--card))]">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">מחיר ממוצע</p>
                <p className="text-2xl font-bold text-gray-900">₪{stats.avgPrice.toFixed(2)}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-blue-700" />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-lg border-0 bg-[hsl(var(--card))]">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">ספקים פעילים</p>
                <p className="text-2xl font-bold text-gray-900">{stats.suppliers}</p>
              </div>
              <FileSpreadsheet className="w-8 h-8 text-blue-900" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Upload Progress */}
      {isUploading && (
        <UploadProgress
          progress={uploadProgress}
          isUploading={isUploading}
        />
      )}

      {/* Upload Success */}
      {uploadSuccess && (
        <Alert className="mb-6 border-blue-700 bg-blue-50">
          <CheckCircle className="h-4 w-4 text-blue-700" />
          <AlertDescription className="text-blue-900">
            המחיון הועלה בהצלחה! הקטלוג עודכן.
          </AlertDescription>
        </Alert>
      )}

      {/* Upload Error */}
      {uploadError && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{uploadError}</AlertDescription>
        </Alert>
      )}

      {/* Upload Component */}
      <CatalogUpload
        onFileUpload={handleFileUpload}
        fileInputRef={fileInputRef}
        isUploading={isUploading}
      />

      {/* Filters and Search */}
      <Card className="shadow-lg border-0 bg-[hsl(var(--card))] mb-6">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="חפש מוצר, מותג או ברקוד..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10"
                />
              </div>
            </div>
            <ProductFilters
              suppliers={suppliers}
              selectedSupplier={selectedSupplier}
              setSelectedSupplier={setSelectedSupplier}
              selectedCategory={selectedCategory}
              setSelectedCategory={setSelectedCategory}
            />
          </div>
        </CardContent>
      </Card>

      {/* Products List */}
      <ProductList
        products={filteredProducts}
        isLoading={isLoading}
        suppliers={suppliers}
      />
    </div>
  );
}
