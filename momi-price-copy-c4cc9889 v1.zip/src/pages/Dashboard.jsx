
import React, { useState, useEffect } from "react";
import { Invoice, InvoiceItem, Product, Supplier } from "@/components/utils/entityImports";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Camera,
  Package,
  ShoppingCart,
  AlertTriangle,
  TrendingUp, // This icon is imported but not used in the provided snippet. Keeping it for consistency.
  DollarSign,
  FileText
} from "lucide-react";

// Simple inline components since external ones might be missing
function StatsGrid({ stats, isLoading }) {
  const statsConfig = [
    {
      title: "חיסכון פוטנציאלי",
      value: `₪${stats.totalSavings.toFixed(2)}`,
      icon: DollarSign,
      color: "text-green-600",
      bgColor: "bg-green-100"
    },
    {
      title: "התראות פעילות",
      value: stats.activeAlerts,
      icon: AlertTriangle,
      color: "text-red-600",
      bgColor: "bg-red-100"
    },
    {
      title: "חשבוניות לבדיקה",
      value: stats.pendingInvoices,
      icon: FileText,
      color: "text-blue-600",
      bgColor: "bg-blue-100"
    },
    {
      title: "מוצרים בקטלוג",
      value: stats.totalProducts,
      icon: Package,
      color: "text-blue-600",
      bgColor: "bg-blue-100"
    }
  ];

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {Array(4).fill(0).map((_, index) => (
          <Card key={index} className="shadow-lg border-0">
            <CardContent className="p-6">
              <div className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded mb-2"></div>
                <div className="h-8 bg-gray-200 rounded"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statsConfig.map((stat, index) => (
        <Card key={index} className="shadow-lg border-0 bg-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500 mb-1">
                  {stat.title}
                </p>
                <div className="text-2xl font-bold text-gray-900">
                  {stat.value}
                </div>
              </div>
              <div className={`w-12 h-12 ${stat.bgColor} rounded-xl flex items-center justify-center`}>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

export default function Dashboard() {
  const [invoices, setInvoices] = useState([]);
  const [overchargedItems, setOverchargedItems] = useState([]);
  const [products, setProducts] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [connectionError, setConnectionError] = useState(null);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setIsLoading(true);
    setConnectionError(null);

    try {
      const [invoicesData, itemsData, productsData, suppliersData] = await Promise.all([
        Invoice.list('-created_date', 10).catch(err => {
          console.warn('Failed to load invoices:', err);
          return [];
        }),
        InvoiceItem.filter({ is_overcharged: true }, '-created_date', 20).catch(err => {
          console.warn('Failed to load overcharged items:', err);
          return [];
        }),
        Product.list('-updated_date', 100).catch(err => {
          console.warn('Failed to load products:', err);
          return [];
        }),
        Supplier.filter({ is_active: true }).catch(err => {
          console.warn('Failed to load suppliers:', err);
          return [];
        })
      ]);

      setInvoices(invoicesData);
      setOverchargedItems(itemsData);
      setProducts(productsData);
      setSuppliers(suppliersData);

    } catch (error) {
      console.error('Error loading dashboard data:', error);
      setConnectionError(error.message);
    }

    setIsLoading(false);
  };

  const calculateStats = () => {
    const totalSavings = overchargedItems.reduce((sum, item) =>
      sum + (item.price_difference * item.quantity || 0), 0
    );

    const pendingInvoices = invoices.filter(inv => inv.status === 'pending_review').length;
    const activeAlerts = overchargedItems.length;

    return {
      totalSavings,
      pendingInvoices,
      activeAlerts,
      totalProducts: products.length,
      activeSuppliers: suppliers.length
    };
  };

  const stats = calculateStats();

  return (
    <div className="w-full max-w-7xl mx-auto space-y-8 bg-white min-h-screen">
      {/* Header */}
      <div className="mb-6 lg:mb-8">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-2">
              לוח בקרה ראשי
            </h1>
            <p className="text-slate-600 text-base lg:text-lg">
              מעקב אחר מחירים וניהול ספקים
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
            <Link to={createPageUrl("ProductCatalog")} className="w-full sm:w-auto">
              <Button variant="outline" className="gap-2 w-full sm:w-auto">
                <Package className="w-4 h-4" />
                קטלוג מוצרים
              </Button>
            </Link>
            <Link to={createPageUrl("InvoiceCapture")} className="w-full sm:w-auto">
              <Button variant="default" className="gap-2 w-full sm:w-auto">
                <Camera className="w-4 h-4" />
                צלם חשבונית
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Connection Error */}
      {connectionError && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          <strong className="font-bold">שגיאת חיבור!</strong>
          <span className="block sm:inline mr-2">נתונים עשויים להיות לא עדכניים. {connectionError}</span>
        </div>
      )}

      {/* Stats Grid */}
      <StatsGrid stats={stats} isLoading={isLoading} />

      {/* Main Content */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 lg:gap-8">
        {/* Recent Invoices */}
        <div className="xl:col-span-2">
          <Card className="shadow-lg border-0 bg-white">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-600" />
                חשבוניות אחרונות ({invoices.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                 <div className="space-y-4">
                  {Array(3).fill(0).map((_, index) => (
                    <div key={index} className="animate-pulse h-16 bg-gray-200 rounded-xl"></div>
                  ))}
                </div>
              ) : invoices.length > 0 ? (
                <div className="space-y-4">
                  {invoices.slice(0, 5).map((invoice) => (
                    <div key={invoice.id} className="p-4 border rounded-xl hover:bg-gray-50 transition-colors">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold">חשבונית #{invoice.invoice_number}</h3>
                          <p className="text-sm text-gray-600">₪{invoice.total_amount?.toFixed(2) || '0.00'}</p>
                        </div>
                        <Button size="sm" asChild variant="default">
                          <Link to={createPageUrl("InvoiceDetails") + `?id=${invoice.id}`}>
                            הצג
                          </Link>
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p>אין חשבוניות במערכת</p>
                  <Link to={createPageUrl("InvoiceCapture")}>
                    <Button className="mt-4" variant="default">צלם חשבונית ראשונה</Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div>
          <Card className="shadow-lg border-0 bg-white">
            <CardHeader>
              <CardTitle className="text-lg font-bold flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-blue-900" />
                פעולות מהירות
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Link to={createPageUrl("InvoiceCapture")} className="block">
                  <div className="p-4 border-2 border-dashed border-blue-200 rounded-xl hover:border-blue-400 hover:bg-blue-50 transition-all duration-200">
                    <Camera className="w-8 h-8 text-blue-900 mb-2" />
                    <h3 className="font-semibold mb-1">צילום חשבונית חדשה</h3>
                    <p className="text-sm text-slate-600">
                      צלם וזהה מחירים בזמן אמת
                    </p>
                  </div>
                </Link>

                <Link to={createPageUrl("ProductCatalog")} className="block">
                  <div className="p-4 border-2 border-dashed border-blue-200 rounded-xl hover:border-blue-400 hover:bg-blue-50 transition-all duration-200">
                    <Package className="w-8 h-8 text-blue-700 mb-2" />
                    <h3 className="font-semibold mb-1">עדכון קטלוג</h3>
                    <p className="text-sm text-slate-600">
                      העלה מחירון חדש מספק
                    </p>
                  </div>
                </Link>

                <Link to={createPageUrl("PriceAlerts")} className="block">
                  <div className="p-4 border-2 border-dashed border-blue-200 rounded-xl hover:border-blue-400 hover:bg-blue-50 transition-all duration-200">
                    <AlertTriangle className="w-8 h-8 text-blue-700 mb-2" />
                    <h3 className="font-semibold mb-1">סקירת התראות</h3>
                    <p className="text-sm text-slate-600">
                      בדוק חריגי מחיר ונהל משא ומתן
                    </p>
                  </div>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
