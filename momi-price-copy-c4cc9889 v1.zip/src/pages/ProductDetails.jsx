import React, { useState, useEffect } from "react";
import { Product, Supplier, InvoiceItem } from "@/components/utils/entityImports";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  ArrowRight, 
  Package, 
  Edit, 
  Save,
  TrendingUp,
  AlertTriangle,
  Calendar,
  BarChart3
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import { he } from "date-fns/locale";

export default function ProductDetails() {
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);
  const [supplier, setSupplier] = useState(null);
  const [recentPrices, setRecentPrices] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setSaving] = useState(false);
  const [editData, setEditData] = useState({});
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Get product ID from URL parameters
  const urlParams = new URLSearchParams(window.location.search);
  const productId = urlParams.get('id');

  useEffect(() => {
    if (productId) {
      loadProductDetails();
    }
  }, [productId]);

  const loadProductDetails = async () => {
    setIsLoading(true);
    try {
      const products = await Product.list();
      const currentProduct = products.find(prod => prod.id === productId);
      
      if (currentProduct) {
        setProduct(currentProduct);
        setEditData(currentProduct);
        
        // Load supplier
        const suppliers = await Supplier.list();
        const currentSupplier = suppliers.find(sup => sup.id === currentProduct.supplier_id);
        setSupplier(currentSupplier);
        
        // Load recent price history from invoice items
        const invoiceItems = await InvoiceItem.filter({ barcode: currentProduct.barcode });
        const priceHistory = invoiceItems
          .map(item => ({
            date: item.created_date,
            price: item.unit_price,
            catalog_price: item.catalog_price,
            is_overcharged: item.is_overcharged,
            invoice_id: item.invoice_id
          }))
          .sort((a, b) => new Date(b.date) - new Date(a.date))
          .slice(0, 10);
        setRecentPrices(priceHistory);
      }
    } catch (error) {
      console.error('Error loading product details:', error);
    }
    setIsLoading(false);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await Product.update(productId, {
        ...editData,
        last_updated: new Date().toISOString()
      });
      setProduct(editData);
      setIsEditing(false);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (error) {
      console.error('Error saving product:', error);
    }
    setSaving(false);
  };

  const handleEdit = (field, value) => {
    setEditData(prev => ({ ...prev, [field]: value }));
  };

  if (isLoading) {
    return (
      <div className="p-4 md:p-8 bg-gradient-to-br from-gray-50 to-blue-50 min-h-screen" dir="rtl">
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-64"></div>
            <div className="h-64 bg-gray-200 rounded"></div>
            <div className="h-96 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="p-4 md:p-8 bg-gradient-to-br from-gray-50 to-blue-50 min-h-screen" dir="rtl">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">מוצר לא נמצא</h1>
          <Button onClick={() => navigate(createPageUrl("ProductCatalog"))}>
            חזור לקטלוג
          </Button>
        </div>
      </div>
    );
  }

  const avgPrice = recentPrices.length > 0 ? 
    recentPrices.reduce((sum, p) => sum + p.price, 0) / recentPrices.length : 0;
  const overchargeCount = recentPrices.filter(p => p.is_overcharged).length;

  return (
    <div className="p-4 md:p-8 bg-gradient-to-br from-gray-50 to-blue-50 min-h-screen" dir="rtl">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Button 
              variant="outline" 
              onClick={() => navigate(createPageUrl("ProductCatalog"))}
              className="gap-2"
            >
              <ArrowRight className="w-4 h-4" />
              חזור לקטלוג
            </Button>
            <h1 className="text-3xl font-bold text-gray-900">
              {product.product_title}
            </h1>
            <Badge variant="outline">{product.brand}</Badge>
          </div>

          {saveSuccess && (
            <Alert className="mb-4 border-green-200 bg-green-50">
              <Save className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800">
                המוצר עודכן בהצלחה!
              </AlertDescription>
            </Alert>
          )}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Product Details */}
            <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Package className="w-5 h-5 text-blue-600" />
                    פרטי מוצר
                  </CardTitle>
                  <Button
                    variant="outline"
                    onClick={() => setIsEditing(!isEditing)}
                    className="gap-2"
                  >
                    <Edit className="w-4 h-4" />
                    {isEditing ? 'ביטול' : 'עריכה'}
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label>שם המוצר</Label>
                      {isEditing ? (
                        <Input
                          value={editData.product_title}
                          onChange={(e) => handleEdit('product_title', e.target.value)}
                        />
                      ) : (
                        <p className="font-semibold">{product.product_title}</p>
                      )}
                    </div>
                    <div>
                      <Label>מותג</Label>
                      {isEditing ? (
                        <Input
                          value={editData.brand}
                          onChange={(e) => handleEdit('brand', e.target.value)}
                        />
                      ) : (
                        <p className="font-semibold">{product.brand}</p>
                      )}
                    </div>
                    <div>
                      <Label>ברקוד</Label>
                      <p className="font-mono text-sm bg-gray-100 p-2 rounded">{product.barcode}</p>
                    </div>
                    <div>
                      <Label>גודל אריזה</Label>
                      <p className="font-semibold">{product.amount_value} {product.amount_unit}</p>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <Label>מחיר עלות</Label>
                      {isEditing ? (
                        <Input
                          type="number"
                          step="0.01"
                          value={editData.cost_price}
                          onChange={(e) => handleEdit('cost_price', parseFloat(e.target.value))}
                        />
                      ) : (
                        <p className="font-semibold text-lg">₪{product.cost_price?.toFixed(2)}</p>
                      )}
                    </div>
                    <div>
                      <Label>מחיר מומלץ</Label>
                      {isEditing ? (
                        <Input
                          type="number"
                          step="0.01"
                          value={editData.retail_price}
                          onChange={(e) => handleEdit('retail_price', parseFloat(e.target.value))}
                        />
                      ) : (
                        <p className="font-semibold">₪{product.retail_price?.toFixed(2)}</p>
                      )}
                    </div>
                    <div>
                      <Label>קטגוריה</Label>
                      {isEditing ? (
                        <Input
                          value={editData.dept_code}
                          onChange={(e) => handleEdit('dept_code', e.target.value)}
                        />
                      ) : (
                        <p className="font-semibold">{product.dept_code}</p>
                      )}
                    </div>
                    <div>
                      <Label>אריזה</Label>
                      <p className="font-semibold">{product.packaging}</p>
                    </div>
                  </div>
                </div>

                {isEditing && (
                  <div className="flex gap-3 mt-6 pt-6 border-t">
                    <Button 
                      onClick={handleSave}
                      disabled={isSaving}
                      className="bg-green-600 hover:bg-green-700 gap-2"
                    >
                      <Save className="w-4 h-4" />
                      {isSaving ? 'שומר...' : 'שמור שינויים'}
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={() => {
                        setIsEditing(false);
                        setEditData(product);
                      }}
                    >
                      ביטול
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Price History */}
            <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-purple-600" />
                  היסטוריית מחירים ({recentPrices.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {recentPrices.length > 0 ? (
                  <div className="space-y-3">
                    {recentPrices.map((price, index) => (
                      <div 
                        key={index}
                        className={`p-4 rounded-lg border ${
                          price.is_overcharged ? 'border-red-200 bg-red-50' : 'border-green-200 bg-green-50'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-semibold">₪{price.price?.toFixed(2)}</p>
                            <p className="text-sm text-gray-600">
                              {format(new Date(price.date), 'dd/MM/yyyy', { locale: he })}
                            </p>
                          </div>
                          <div className="text-left">
                            {price.is_overcharged ? (
                              <Badge variant="destructive">
                                יקר ב-{(((price.price - price.catalog_price) / price.catalog_price) * 100).toFixed(1)}%
                              </Badge>
                            ) : (
                              <Badge className="bg-green-100 text-green-800">
                                מחיר תקין
                              </Badge>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              className="mt-1"
                              onClick={() => navigate(createPageUrl("InvoiceDetails") + `?id=${price.invoice_id}`)}
                            >
                              הצג חשבונית
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <BarChart3 className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                    <p>אין נתוני מחירים קודמים</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Stats */}
            <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-blue-600" />
                  סטטיסטיקות
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-500">מחיר ממוצע בחשבוניות</p>
                    <p className="text-lg font-bold">₪{avgPrice.toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">חריגי מחיר</p>
                    <p className={`text-lg font-bold ${overchargeCount > 0 ? 'text-red-600' : 'text-green-600'}`}>
                      {overchargeCount} מתוך {recentPrices.length}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">עדכון אחרון</p>
                    <p className="font-semibold">
                      {format(new Date(product.last_updated), 'dd/MM/yyyy', { locale: he })}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Supplier Info */}
            {supplier && (
              <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>פרטי ספק</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm text-gray-500">שם החברה</p>
                      <p className="font-semibold">{supplier.name}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">איש קשר</p>
                      <p className="font-semibold">{supplier.contact_person}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">טלפון</p>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => window.open(`tel:${supplier.phone}`)}
                        className="text-blue-600"
                      >
                        {supplier.phone}
                      </Button>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">אימייל</p>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => window.open(`mailto:${supplier.email}`)}
                        className="text-blue-600"
                      >
                        {supplier.email}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Quick Actions */}
            <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>פעולות מהירות</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  variant="outline" 
                  className="w-full justify-start gap-2"
                  onClick={() => navigate(createPageUrl("PriceAlerts") + `?product=${productId}`)}
                >
                  <AlertTriangle className="w-4 h-4" />
                  הצג התראות מחיר
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start gap-2"
                  onClick={() => {
                    const text = `מוצר: ${product.product_title}\nברקוד: ${product.barcode}\nמחיר עלות: ₪${product.cost_price}`;
                    navigator.clipboard.writeText(text);
                    alert('פרטי המוצר הועתקו ללוח');
                  }}
                >
                  <Package className="w-4 h-4" />
                  העתק פרטי מוצר
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}