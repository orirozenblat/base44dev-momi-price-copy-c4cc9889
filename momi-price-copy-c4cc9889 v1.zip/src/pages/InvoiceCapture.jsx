
import React, { useState, useRef } from "react";
import { Invoice, InvoiceItem, Product, Supplier } from "@/api/entities";
import { ExtractDataFromUploadedFile, UploadFile } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Camera, 
  Upload, 
  CheckCircle, 
  AlertTriangle,
  RefreshCw,
  Clock,
  Wifi,
  WifiOff
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

// Optimized imports - only load when needed
import { OperationEngine, QuickText } from "../components/utils/operationEngine";
import { SmartCache, DataFetcher } from "../components/utils/smartCache";

import CameraCapture from "../components/capture/CameraCapture";
import ImagePreview from "../components/capture/ImagePreview";
import ItemsReview from "../components/capture/ItemsReview";
import ProcessingStatus from "../components/capture/ProcessingStatus";

export default function InvoiceCapture() {
  const navigate = useNavigate();
  const [step, setStep] = useState('capture');
  const [capturedImages, setCapturedImages] = useState([]);
  const [extractedData, setExtractedData] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState(null);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [offlineQueue, setOfflineQueue] = useState([]);
  const fileInputRef = useRef(null);

  React.useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      if (offlineQueue.length > 0) {
        processOfflineQueue();
      }
    };
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [offlineQueue]);

  const processOfflineQueue = async () => {
    for (const queuedInvoice of offlineQueue) {
      try {
        await processInvoiceOnline(queuedInvoice);
      } catch (error) {
        console.error('Error processing queued invoice:', error);
      }
    }
    setOfflineQueue([]);
  };

  const handleImageCapture = (imageFile) => {
    setCapturedImages(prev => [...prev, imageFile]);
    setStep('preview');
    setError(null);
  };

  const handleFileUpload = (event) => {
    const files = Array.from(event.target.files);
    setCapturedImages(prev => [...prev, ...files]);
    setStep('preview');
    setError(null);
  };

  const removeImage = (index) => {
    setCapturedImages(prev => prev.filter((_, i) => i !== index));
    if (capturedImages.length === 1) {
      setStep('capture');
    }
  };

  const processInvoice = async () => {
    if (capturedImages.length === 0) return;

    if (!isOnline) {
      const offlineInvoice = {
        images: capturedImages,
        timestamp: new Date().toISOString(),
        id: Date.now().toString()
      };
      setOfflineQueue(prev => [...prev, offlineInvoice]);
      
      alert('אין חיבור לאינטרנט. החשבונית נשמרה ותעובד כשהחיבור יחזור.');
      setStep('capture');
      setCapturedImages([]);
      return;
    }

    await processInvoiceOnline({ images: capturedImages });
  };

  const processInvoiceOnline = async (invoiceData) => {
    setIsProcessing(true);
    setStep('process');
    setError(null);

    try {
      const uploadPromises = invoiceData.images.map(file => UploadFile({ file }));
      const uploadResults = await Promise.all(uploadPromises);
      const imageUrls = uploadResults.map(result => result.file_url);

      // Optimized extraction with intelligent cost management
      const extractResult = await ExtractDataFromUploadedFile({
        file_url: imageUrls[0],
        json_schema: {
          type: "object",
          properties: {
            supplier_name: { type: "string" },
            invoice_number: { type: "string" },
            invoice_date: { type: "string", format: "date" },
            total_amount: { type: "number" },
            items: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  barcode: { type: "string" },
                  product_name: { type: "string" },
                  quantity: { type: "number" },
                  unit_price: { type: "number" },
                  total_price: { type: "number" }
                },
                required: ["product_name", "quantity", "unit_price"]
              }
            }
          },
          required: ["supplier_name", "items"]
        }
      });

      if (extractResult.status === "success") {
        // Use smart caching for product lookups
        const cacheKey = 'all_products';
        let allProducts = SmartCache.get(cacheKey);
        
        if (!allProducts) {
          allProducts = await Product.list();
          SmartCache.set(cacheKey, allProducts, 600000); // 10 minutes
        }
        
        // Process items with intelligent matching
        const processedItems = await Promise.all(
          extractResult.output.items.map(async (item) => {
            const matchResult = OperationEngine.findBestMatch(
              item.product_name,
              allProducts,
              { threshold: 0.7, maxCost: 100 }
            );

            const processedItem = {
              ...item,
              product_name: QuickText.normalizeHebrew(item.product_name),
              matched_product_id: matchResult.item?.id,
              catalog_price: matchResult.item?.cost_price,
              confidence_score: matchResult.score,
              match_method: matchResult.method,
              processing_cost: matchResult.cost
            };

            // Smart price anomaly detection
            if (matchResult.item && matchResult.score > 0.8) {
              const priceDiff = item.unit_price - matchResult.item.cost_price;
              const overchargePercentage = (priceDiff / matchResult.item.cost_price) * 100;
              
              if (overchargePercentage >= 8) {
                processedItem.is_overcharged = true;
                processedItem.price_difference = priceDiff;
                processedItem.overcharge_percentage = overchargePercentage;
              }
            }

            return processedItem;
          })
        );

        setExtractedData({
          ...extractResult.output,
          items: processedItems,
          image_urls: imageUrls,
          processing_stats: {
            total_cost: processedItems.reduce((sum, item) => sum + (item.processing_cost || 0), 0),
            cache_stats: SmartCache.getStats()
          }
        });
        setStep('review');
      } else {
        throw new Error(extractResult.details || 'Failed to extract invoice data');
      }
    } catch (error) {
      console.error('Processing error:', error);
      setError('שגיאה בעיבוד החשבונית. אנא נסה שוב.');
      setStep('preview');
    }

    setIsProcessing(false);
  };

  const saveInvoice = async (finalData) => {
    try {
      const invoice = await Invoice.create({
        supplier_id: finalData.supplier_name,
        invoice_number: finalData.invoice_number,
        invoice_date: finalData.invoice_date,
        store_name: "חנות ראשית",
        receiver_name: "מקבל",
        total_amount: finalData.total_amount,
        status: finalData.items.some(item => item.is_overcharged) ? 'disputed' : 'approved',
        overcharge_count: finalData.items.filter(item => item.is_overcharged).length,
        image_urls: finalData.image_urls,
        processing_metadata: finalData.processing_stats
      });

      // Batch create items for efficiency
      const itemsToCreate = finalData.items.map(item => ({
        ...item,
        invoice_id: invoice.id
      }));
      
      await InvoiceItem.bulkCreate(itemsToCreate);

      // Clear cache to ensure fresh data on next load
      SmartCache.cleanup();
      
      navigate(createPageUrl("Dashboard"));
    } catch (error) {
      console.error('Save error:', error);
      setError('שגיאה בשמירת החשבונית. אנא נסה שוב.');
    }
  };

  return (
    <div className="min-h-screen bg-white p-4 md:p-8" dir="rtl">
      <div className="max-w-4xl mx-auto">
        {/* Header with performance stats */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">
                צילום וזיהוי חשבונית
              </h1>
              <p className="text-gray-600">
                צלם את החשבונית וקבל בדיקת מחירים אוטומטית
              </p>
            </div>
            <div className="flex items-center gap-2">
              {isOnline ? (
                // Fix: Align badge colors with progress indicator's success color
                <Badge className="bg-green-500 text-white">
                  <Wifi className="w-3 h-3 mr-1" />
                  מקוון
                </Badge>
              ) : (
                // Fix: Use a standard red for offline status, consistent with progress indicator's text color
                <Badge className="bg-red-500 text-white">
                  <WifiOff className="w-3 h-3 mr-1" />
                  לא מקוון
                </Badge>
              )}
              {extractedData?.processing_stats && (
                // Fix: Align badge colors with progress indicator's primary color
                <Badge className="bg-blue-600 text-white">
                  עלות: {extractedData.processing_stats.total_cost}
                </Badge>
              )}
            </div>
          </div>
        </div>

        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex items-center justify-between max-w-md mx-auto">
            {['capture', 'preview', 'process', 'review'].map((stepName, index) => (
              <div key={stepName} className="flex items-center">
                <div className={`w-10 h-10 md:w-12 md:h-12 rounded-full flex items-center justify-center text-sm md:text-base font-semibold ${
                  step === stepName ? 'bg-blue-600 text-white' : 
                  ['capture', 'preview', 'process', 'review'].indexOf(step) > index ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-500'
                }`}>
                  {['capture', 'preview', 'process', 'review'].indexOf(step) > index ? (
                    <CheckCircle className="w-5 h-5" />
                  ) : (
                    index + 1
                  )}
                </div>
                {index < 3 && (
                  <div className={`w-8 md:w-12 h-1 mx-2 ${
                    ['capture', 'preview', 'process', 'review'].indexOf(step) > index ? 'bg-green-500' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
          
          <div className="flex justify-between max-w-md mx-auto mt-2 text-xs md:text-sm text-gray-600">
            <span>צילום</span>
            <span>תצוגה</span>
            <span>עיבוד</span>
            <span>בדיקה</span>
          </div>
        </div>

        {/* Offline Warning */}
        {!isOnline && step === 'capture' && (
          <Alert className="mb-6 border-amber-200 bg-amber-50">
            <WifiOff className="h-4 w-4 text-amber-600" />
            <AlertDescription className="text-amber-800">
              אין חיבור לאינטרנט. תוכל לצלם חשבוניות והן יעובדו כשהחיבור יחזור.
            </AlertDescription>
          </Alert>
        )}

        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Step Content */}
        <div className="space-y-6">
          {step === 'capture' && (
            <CameraCapture 
              onImageCapture={handleImageCapture}
              onFileUpload={handleFileUpload}
              fileInputRef={fileInputRef}
              isOnline={isOnline}
            />
          )}

          {step === 'preview' && (
            <ImagePreview 
              images={capturedImages}
              onRemoveImage={removeImage}
              onAddMore={() => setStep('capture')}
              onProcess={processInvoice}
              isOnline={isOnline}
            />
          )}

          {step === 'process' && (
            <ProcessingStatus isProcessing={isProcessing} />
          )}

          {step === 'review' && extractedData && (
            <ItemsReview 
              extractedData={extractedData}
              onSave={saveInvoice}
              onBack={() => setStep('preview')}
            />
          )}
        </div>
      </div>
    </div>
  );
}
