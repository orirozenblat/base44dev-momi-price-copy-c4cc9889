import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Activity, 
  Database, 
  Wifi, 
  WifiOff, 
  AlertTriangle, 
  CheckCircle,
  Clock,
  Download,
  Trash2
} from "lucide-react";

export default function SystemMonitor() {
  const [systemHealth, setSystemHealth] = useState({
    isOnline: navigator.onLine,
    lastSync: localStorage.getItem('lastSync'),
    pendingActions: JSON.parse(localStorage.getItem('pendingActions') || '[]'),
    errors: JSON.parse(localStorage.getItem('app_errors') || '[]'),
    performance: {
      loadTime: performance.now(),
      memoryUsage: 0
    }
  });

  const [showDetails, setShowDetails] = useState(false);

  useEffect(() => {
    const updateHealth = () => {
      setSystemHealth(prev => ({
        ...prev,
        isOnline: navigator.onLine,
        lastSync: localStorage.getItem('lastSync'),
        pendingActions: JSON.parse(localStorage.getItem('pendingActions') || '[]'),
        errors: JSON.parse(localStorage.getItem('app_errors') || '[]'),
        performance: {
          loadTime: performance.now(),
          memoryUsage: (performance.memory?.usedJSHeapSize || 0) / 1024 / 1024
        }
      }));
    };

    const interval = setInterval(updateHealth, 5000);
    
    window.addEventListener('online', updateHealth);
    window.addEventListener('offline', updateHealth);

    return () => {
      clearInterval(interval);
      window.removeEventListener('online', updateHealth);
      window.removeEventListener('offline', updateHealth);
    };
  }, []);

  const clearErrors = () => {
    localStorage.removeItem('app_errors');
    setSystemHealth(prev => ({ ...prev, errors: [] }));
  };

  const exportLogs = () => {
    const logs = {
      timestamp: new Date().toISOString(),
      systemHealth,
      userAgent: navigator.userAgent,
      url: window.location.href,
      localStorage: Object.keys(localStorage).reduce((acc, key) => {
        if (key.startsWith('app_')) acc[key] = localStorage.getItem(key);
        return acc;
      }, {}),
      sessionStorage: Object.keys(sessionStorage).reduce((acc, key) => {
        acc[key] = sessionStorage.getItem(key);
        return acc;
      }, {})
    };

    const blob = new Blob([JSON.stringify(logs, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `system-logs-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getHealthStatus = () => {
    if (!systemHealth.isOnline) return { status: 'warning', text: 'לא מקוון' };
    if (systemHealth.errors.length > 0) return { status: 'error', text: 'שגיאות זוהו' };
    if (systemHealth.pendingActions.length > 0) return { status: 'warning', text: 'פעולות ממתינות' };
    return { status: 'success', text: 'תקין' };
  };

  const health = getHealthStatus();

  return (
    <Card className="shadow-lg border-0 bg-white/90 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-blue-600" />
            מוניטור מערכת
          </CardTitle>
          <Badge className={
            health.status === 'success' ? 'bg-green-100 text-green-800' :
            health.status === 'warning' ? 'bg-yellow-100 text-yellow-800' :
            'bg-red-100 text-red-800'
          }>
            {health.text}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Quick Status */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-2">
              {systemHealth.isOnline ? (
                <Wifi className="w-4 h-4 text-green-600" />
              ) : (
                <WifiOff className="w-4 h-4 text-red-600" />
              )}
              <span className="text-sm">
                {systemHealth.isOnline ? 'מקוון' : 'לא מקוון'}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-blue-600" />
              <span className="text-sm">
                {systemHealth.pendingActions.length} ממתינות
              </span>
            </div>

            <div className="flex items-center gap-2">
              {systemHealth.errors.length > 0 ? (
                <AlertTriangle className="w-4 h-4 text-red-600" />
              ) : (
                <CheckCircle className="w-4 h-4 text-green-600" />
              )}
              <span className="text-sm">
                {systemHealth.errors.length} שגיאות
              </span>
            </div>

            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-gray-600" />
              <span className="text-sm">
                {systemHealth.lastSync ? 
                  new Date(systemHealth.lastSync).toLocaleTimeString('he-IL') : 
                  'לא סונכרן'}
              </span>
            </div>
          </div>

          {/* Alerts */}
          {!systemHealth.isOnline && (
            <Alert className="border-yellow-200 bg-yellow-50">
              <WifiOff className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-yellow-800">
                אין חיבור לאינטרנט. פעולות יסונכרנו כשהחיבור יחזור.
              </AlertDescription>
            </Alert>
          )}

          {systemHealth.errors.length > 0 && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                זוהו {systemHealth.errors.length} שגיאות במערכת. 
                <Button variant="link" className="p-0 h-auto mr-1" onClick={() => setShowDetails(!showDetails)}>
                  הצג פרטים
                </Button>
              </AlertDescription>
            </Alert>
          )}

          {/* Performance Info */}
          {showDetails && (
            <div className="bg-gray-50 p-4 rounded-lg space-y-3">
              <h4 className="font-semibold">פרטי ביצועים</h4>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">זמן טעינה:</span>
                  <span className="mr-2 font-mono">
                    {(systemHealth.performance.loadTime / 1000).toFixed(2)}s
                  </span>
                </div>
                <div>
                  <span className="text-gray-600">זיכרון:</span>
                  <span className="mr-2 font-mono">
                    {systemHealth.performance.memoryUsage.toFixed(1)}MB
                  </span>
                </div>
              </div>

              {/* Recent Errors */}
              {systemHealth.errors.length > 0 && (
                <div>
                  <h5 className="font-medium mb-2">שגיאות אחרונות:</h5>
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {systemHealth.errors.slice(-5).map((error, index) => (
                      <div key={index} className="bg-white p-2 rounded border text-xs">
                        <div className="font-mono text-red-600">{error.id}</div>
                        <div className="text-gray-600">{error.error?.message}</div>
                        <div className="text-xs text-gray-400">
                          {new Date(error.timestamp).toLocaleString('he-IL')}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={exportLogs} className="gap-1">
              <Download className="w-3 h-3" />
              ייצא לוגים
            </Button>
            {systemHealth.errors.length > 0 && (
              <Button variant="outline" size="sm" onClick={clearErrors} className="gap-1">
                <Trash2 className="w-3 h-3" />
                נקה שגיאות
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}