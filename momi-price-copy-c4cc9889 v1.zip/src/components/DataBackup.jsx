
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge"; // Added this import
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Download, 
  Upload, 
  Database, 
  CheckCircle, 
  AlertTriangle,
  Clock,
  HardDrive
} from "lucide-react";
import { Invoice, InvoiceItem, Product, Supplier } from "@/api/entities";

export default function DataBackup() {
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [lastBackup, setLastBackup] = useState(localStorage.getItem('lastBackup'));

  const exportData = async () => {
    setIsExporting(true);
    setExportProgress(0);

    try {
      // Get all data
      setExportProgress(20);
      const [invoices, invoiceItems, products, suppliers] = await Promise.all([
        Invoice.list(),
        InvoiceItem.list(),
        Product.list(), 
        Supplier.list()
      ]);

      setExportProgress(60);

      // Create backup object
      const backup = {
        version: "1.0",
        timestamp: new Date().toISOString(),
        data: {
          invoices,
          invoiceItems,
          products,
          suppliers
        },
        metadata: {
          userAgent: navigator.userAgent,
          url: window.location.origin,
          recordCounts: {
            invoices: invoices.length,
            invoiceItems: invoiceItems.length,
            products: products.length,
            suppliers: suppliers.length
          }
        }
      };

      setExportProgress(80);

      // Create and download file
      const blob = new Blob([JSON.stringify(backup, null, 2)], { 
        type: 'application/json' 
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `momi-backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setExportProgress(100);

      // Update last backup time
      const backupTime = new Date().toISOString();
      localStorage.setItem('lastBackup', backupTime);
      setLastBackup(backupTime);

      setTimeout(() => {
        setExportProgress(0);
        setIsExporting(false);
      }, 1000);

    } catch (error) {
      console.error('Export error:', error);
      alert('שגיאה בייצוא הנתונים: ' + error.message);
      setIsExporting(false);
      setExportProgress(0);
    }
  };

  const importData = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setIsImporting(true);

    try {
      const text = await file.text();
      const backup = JSON.parse(text);

      // Validate backup structure
      if (!backup.data || !backup.version) {
        throw new Error('קובץ גיבוי לא תקין');
      }

      // Show confirmation
      const confirmed = window.confirm(
        `האם אתה בטוח שברצונך לשחזר נתונים מ-${new Date(backup.timestamp).toLocaleDateString('he-IL')}?\n` +
        `זה ימחק את כל הנתונים הקיימים ויחליף אותם בנתוני הגיבוי.`
      );

      if (!confirmed) {
        setIsImporting(false);
        return;
      }

      alert('שחזור נתונים יתבצע בקרוב - תכונה זו תהיה זמינה בגרסה הבאה');

    } catch (error) {
      console.error('Import error:', error);
      alert('שגיאה בשחזור הנתונים: ' + error.message);
    }

    setIsImporting(false);
    // Reset file input
    event.target.value = '';
  };

  const getBackupStats = () => {
    try {
      const stats = {
        localStorageSize: new Blob([JSON.stringify(localStorage)]).size / 1024,
        sessionStorageSize: new Blob([JSON.stringify(sessionStorage)]).size / 1024,
        errorCount: JSON.parse(localStorage.getItem('app_errors') || '[]').length,
        pendingActions: JSON.parse(localStorage.getItem('pendingActions') || '[]').length
      };
      return stats;
    } catch (error) {
      return { localStorageSize: 0, sessionStorageSize: 0, errorCount: 0, pendingActions: 0 };
    }
  };

  const stats = getBackupStats();

  return (
    <Card className="shadow-lg border-0 bg-white/90 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="w-5 h-5 text-blue-600" />
          גיבוי ושחזור נתונים
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Backup Status */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-semibold">סטטוס גיבוי</h4>
            {lastBackup ? (
              <Badge className="bg-green-100 text-green-800">
                <CheckCircle className="w-3 h-3 mr-1" />
                מגובה
              </Badge>
            ) : (
              <Badge className="bg-yellow-100 text-yellow-800">
                <AlertTriangle className="w-3 h-3 mr-1" />
                לא מגובה
              </Badge>
            )}
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-600">גיבוי אחרון:</span>
              <div className="font-medium">
                {lastBackup ? 
                  new Date(lastBackup).toLocaleString('he-IL') : 
                  'אף פעם'
                }
              </div>
            </div>
            <div>
              <span className="text-gray-600">גודל נתונים מקומיים:</span>
              <div className="font-medium">
                {stats.localStorageSize.toFixed(1)} KB
              </div>
            </div>
          </div>
        </div>

        {/* Data Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-blue-50 p-3 rounded-lg text-center">
            <HardDrive className="w-6 h-6 mx-auto mb-1 text-blue-600" />
            <div className="text-xs text-gray-600">מקומי</div>
            <div className="font-semibold">{stats.localStorageSize.toFixed(0)}KB</div>
          </div>
          <div className="bg-green-50 p-3 rounded-lg text-center">
            <Clock className="w-6 h-6 mx-auto mb-1 text-green-600" />
            <div className="text-xs text-gray-600">סשן</div>
            <div className="font-semibold">{stats.sessionStorageSize.toFixed(0)}KB</div>
          </div>
          <div className="bg-red-50 p-3 rounded-lg text-center">
            <AlertTriangle className="w-6 h-6 mx-auto mb-1 text-red-600" />
            <div className="text-xs text-gray-600">שגיאות</div>
            <div className="font-semibold">{stats.errorCount}</div>
          </div>
          <div className="bg-yellow-50 p-3 rounded-lg text-center">
            <Database className="w-6 h-6 mx-auto mb-1 text-yellow-600" />
            <div className="text-xs text-gray-600">ממתינות</div>
            <div className="font-semibold">{stats.pendingActions}</div>
          </div>
        </div>

        {/* Export Section */}
        <div>
          <h4 className="font-semibold mb-3">ייצוא נתונים</h4>
          <Alert className="mb-4 border-blue-200 bg-blue-50">
            <Database className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-800">
              ייצוא כל הנתונים לקובץ JSON לצורך גיבוי או ניתוח חיצוני.
            </AlertDescription>
          </Alert>
          
          <Button 
            onClick={exportData} 
            disabled={isExporting}
            className="w-full gap-2"
          >
            <Download className="w-4 h-4" />
            {isExporting ? `מייצא... ${exportProgress}%` : 'ייצא נתונים'}
          </Button>

          {isExporting && (
            <div className="mt-3">
              <div className="bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${exportProgress}%` }}
                />
              </div>
            )}
        </div>

        {/* Import Section */}
        <div>
          <h4 className="font-semibold mb-3">שחזור נתונים</h4>
          <Alert variant="destructive" className="mb-4">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>אזהרה:</strong> שחזור נתונים ימחק את כל המידע הקיים!
            </AlertDescription>
          </Alert>
          
          <div className="relative">
            <input
              type="file"
              accept=".json"
              onChange={importData}
              disabled={isImporting}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <Button 
              variant="outline" 
              disabled={isImporting}
              className="w-full gap-2"
            >
              <Upload className="w-4 h-4" />
              {isImporting ? 'משחזר...' : 'בחר קובץ גיבוי'}
            </Button>
          </div>
        </div>

        {/* Recommendations */}
        <div className="bg-yellow-50 p-4 rounded-lg">
          <h4 className="font-semibold mb-2 text-yellow-900">המלצות לגיבוי</h4>
          <ul className="text-sm text-yellow-800 space-y-1">
            <li>• בצע גיבוי לפני עדכונים גדולים במערכת</li>
            <li>• שמור קבצי גיבוי בענן או במכשיר חיצוני</li>
            <li>• בדוק את תקינות הגיבוי מדי פעם</li>
            <li>• בצע גיבוי שבועי לפחות</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
