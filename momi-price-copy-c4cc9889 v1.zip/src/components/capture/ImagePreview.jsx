import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { X, Plus, ArrowLeft, CheckCircle } from "lucide-react";

export default function ImagePreview({ images, onRemoveImage, onAddMore, onProcess }) {
  return (
    <div className="space-y-6">
      <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl font-bold">
              תמונות שנצלמו ({images.length})
            </CardTitle>
            <Badge variant="outline" className="bg-green-50 text-green-700">
              מוכן לעיבוד
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            {images.map((image, index) => (
              <div key={index} className="relative group">
                <img
                  src={URL.createObjectURL(image)}
                  alt={`Invoice ${index + 1}`}
                  className="w-full h-48 object-cover rounded-lg border-2 border-gray-200"
                />
                <div className="absolute inset-0 bg-black bg-opacity-40 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => onRemoveImage(index)}
                    className="gap-2"
                  >
                    <X className="w-4 h-4" />
                    הסר
                  </Button>
                </div>
                <div className="absolute top-2 right-2 bg-blue-600 text-white text-xs px-2 py-1 rounded-full">
                  {index + 1}
                </div>
              </div>
            ))}
          </div>

          <div className="flex gap-3 justify-center">
            <Button
              variant="outline"
              onClick={onAddMore}
              className="gap-2"
            >
              <Plus className="w-4 h-4" />
              הוסף תמונות
            </Button>
            <Button
              onClick={onProcess}
              className="bg-blue-600 hover:bg-blue-700 gap-2"
              disabled={images.length === 0}
            >
              <CheckCircle className="w-4 h-4" />
              עבד חשבונית
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Preview Tips */}
      <Card className="bg-amber-50 border-amber-200">
        <CardContent className="p-4">
          <h3 className="font-semibold text-amber-900 mb-2">בדוק לפני עיבוד:</h3>
          <ul className="text-sm text-amber-800 space-y-1">
            <li>• כל הטקסט בחשבונית קריא ובהיר</li>
            <li>• מחירים ומספרי ברקוד נראים ברור</li>
            <li>• אין חלקים חתוכים או מטושטשים</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}