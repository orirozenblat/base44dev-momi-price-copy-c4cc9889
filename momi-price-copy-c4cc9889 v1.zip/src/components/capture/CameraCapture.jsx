import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Camera, Upload, Smartphone } from "lucide-react";

export default function CameraCapture({ onImageCapture, onFileUpload, fileInputRef }) {
  const [isMobile] = useState(/iPhone|iPad|iPod|Android/i.test(navigator.userAgent));

  const handleCameraClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.setAttribute('capture', 'environment');
      fileInputRef.current.click();
    }
  };

  const handleUploadClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.removeAttribute('capture');
      fileInputRef.current.click();
    }
  };

  return (
    <div className="space-y-6">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={onFileUpload}
        className="hidden"
      />

      <div className="grid md:grid-cols-2 gap-6">
        {/* Camera Option */}
        <Card className="border-2 border-dashed border-blue-200 hover:border-blue-400 hover:bg-blue-50 transition-all duration-200 cursor-pointer">
          <CardContent className="p-8" onClick={handleCameraClick}>
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-blue-100 rounded-full flex items-center justify-center">
                {isMobile ? (
                  <Smartphone className="w-8 h-8 text-blue-600" />
                ) : (
                  <Camera className="w-8 h-8 text-blue-600" />
                )}
              </div>
              <h3 className="text-xl font-bold mb-2">
                {isMobile ? 'צלם עם הטלפון' : 'צלם עם המצלמה'}
              </h3>
              <p className="text-gray-600 mb-4">
                צלם את החשבונית ישירות מהמכשיר
              </p>
              <div className="bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold inline-flex items-center gap-2">
                <Camera className="w-5 h-5" />
                פתח מצלמה
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Upload Option */}
        <Card className="border-2 border-dashed border-green-200 hover:border-green-400 hover:bg-green-50 transition-all duration-200 cursor-pointer">
          <CardContent className="p-8" onClick={handleUploadClick}>
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-green-100 rounded-full flex items-center justify-center">
                <Upload className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold mb-2">העלה תמונה</h3>
              <p className="text-gray-600 mb-4">
                בחר תמונות קיימות מהמכשיר
              </p>
              <div className="bg-green-600 text-white px-6 py-3 rounded-xl font-semibold inline-flex items-center gap-2">
                <Upload className="w-5 h-5" />
                בחר קבצים
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Instructions */}
      <Card className="bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-blue-900">
            טיפים לצילום איכותי
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-blue-800">
            <li className="flex items-start gap-2">
              <span className="w-2 h-2 bg-blue-600 rounded-full mt-2"></span>
              וודא תאורה טובה ואחידה על החשבונית
            </li>
            <li className="flex items-start gap-2">
              <span className="w-2 h-2 bg-blue-600 rounded-full mt-2"></span>
              החזק את המכשיר יציב ומקביל לחשבונית
            </li>
            <li className="flex items-start gap-2">
              <span className="w-2 h-2 bg-blue-600 rounded-full mt-2"></span>
              כלול את כל החלקים החשובים בתמונה
            </li>
            <li className="flex items-start gap-2">
              <span className="w-2 h-2 bg-blue-600 rounded-full mt-2"></span>
              צלם מספר תמונות אם החשבונית ארוכה
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}