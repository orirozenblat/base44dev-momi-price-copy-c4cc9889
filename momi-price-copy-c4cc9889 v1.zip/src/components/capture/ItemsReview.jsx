import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  AlertTriangle, 
  CheckCircle, 
  Edit, 
  Save,
  ArrowRight,
  Phone,
  Brain,
  Target,
  Zap
} from "lucide-react";

export default function ItemsReview({ extractedData, onSave, onBack }) {
  const [editingItems, setEditingItems] = useState(extractedData.items);
  const [isSaving, setIsSaving] = useState(false);

  const handleItemEdit = (index, field, value) => {
    const updatedItems = [...editingItems];
    updatedItems[index] = {
      ...updatedItems[index],
      [field]: field === 'unit_price' || field === 'quantity' ? parseFloat(value) || 0 : value
    };

    // Recalculate totals and overcharge status
    if (field === 'unit_price' && updatedItems[index].catalog_price) {
      const priceDiff = updatedItems[index].unit_price - updatedItems[index].catalog_price;
      const overchargePercentage = (priceDiff / updatedItems[index].catalog_price) * 100;
      
      updatedItems[index] = {
        ...updatedItems[index],
        price_difference: priceDiff,
        overcharge_percentage: overchargePercentage,
        is_overcharged: overchargePercentage >= 8,
        total_price: updatedItems[index].unit_price * updatedItems[index].quantity
      };
    }

    setEditingItems(updatedItems);
  };

  const handleSave = async () => {
    setIsSaving(true);
    await onSave({
      ...extractedData,
      items: editingItems
    });
    setIsSaving(false);
  };

  const overchargedItems = editingItems.filter(item => item.is_overcharged);
  const totalSavings = overchargedItems.reduce((sum, item) => 
    sum + (item.price_difference * item.quantity), 0
  );

  const getConfidenceBadge = (confidence) => {
    if (confidence >= 0.8) return { color: 'bg-green-100 text-green-800', label: 'גבוהה' };
    if (confidence >= 0.6) return { color: 'bg-blue-100 text-blue-800', label: 'בינונית' };
    return { color: 'bg-red-100 text-red-800', label: 'נמוכה' };
  };

  const getValidationStatusBadge = (status) => {
    const statusMap = {
      'approved': { color: 'bg-green-100 text-green-800', label: 'אושר', icon: CheckCircle },
      'flagged': { color: 'bg-red-100 text-red-800', label: 'מסומן', icon: AlertTriangle },
      'needs_verification': { color: 'bg-blue-100 text-blue-800', label: 'נדרש אישור', icon: Target },
      'manual_review': { color: 'bg-gray-100 text-gray-800', label: 'בדיקה ידנית', icon: Edit }
    };
    return statusMap[status] || statusMap['manual_review'];
  };

  return (
    <div className="space-y-6">
      {/* Enhanced Summary with NLP insights */}
      <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-xl font-bold flex items-center gap-2">
            <Brain className="w-5 h-5 text-purple-600" />
            סיכום חכם של החשבונית
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">ספק:</span>
                <span className="font-semibold">{extractedData.supplier_name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">מספר חשבונית:</span>
                <span className="font-semibold">{extractedData.invoice_number}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">סה"כ:</span>
                <span className="font-semibold">₪{extractedData.total_amount?.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">איכות עיבוד:</span>
                <Badge className={`${extractedData.validation_summary?.processing_quality >= 0.8 ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                  {((extractedData.validation_summary?.processing_quality || 0) * 100).toFixed(0)}%
                </Badge>
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">פריטים שנבדקו:</span>
                <span className="font-semibold">{editingItems.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">זוהו אוטומטית:</span>
                <span className="font-semibold text-green-600">{extractedData.validation_summary?.high_confidence_items || 0}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">חריגי מחיר:</span>
                <span className={`font-semibold ${overchargedItems.length > 0 ? 'text-red-600' : 'text-green-600'}`}>
                  {overchargedItems.length}
                </span>
              </div>
              {totalSavings > 0 && (
                <div className="flex justify-between">
                  <span className="text-gray-600">חיסכון פוטנציאלי:</span>
                  <span className="font-semibold text-green-600">₪{totalSavings.toFixed(2)}</span>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Enhanced Items List */}
      <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-xl font-bold flex items-center gap-2">
            <Zap className="w-5 h-5 text-blue-600" />
            פרטי פריטים (ניתוח חכם)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {editingItems.map((item, index) => {
              const confidenceBadge = getConfidenceBadge(item.confidence_score);
              const statusBadge = getValidationStatusBadge(item.validation_status);
              
              return (
                <div 
                  key={index} 
                  className={`p-4 rounded-xl border-2 ${
                    item.is_overcharged ? 'border-red-200 bg-red-50' :
                    item.needs_review ? 'border-yellow-200 bg-yellow-50' :
                    'border-green-200 bg-green-50'
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <Input
                        value={item.product_name}
                        onChange={(e) => handleItemEdit(index, 'product_name', e.target.value)}
                        className="font-semibold mb-2"
                      />
                      <div className="text-sm text-gray-600 space-y-1">
                        <div>ברקוד: {item.barcode || 'לא זוהה'}</div>
                        {item.extracted_brand && (
                          <div>מותג מזוהה: <span className="font-medium">{item.extracted_brand}</span></div>
                        )}
                        {item.match_method && (
                          <div>שיטת זיהוי: <span className="font-medium">{item.match_method}</span></div>
                        )}
                      </div>
                    </div>
                    <div className="flex flex-col gap-2">
                      {item.is_overcharged && (
                        <Badge variant="destructive" className="gap-1">
                          <AlertTriangle className="w-3 h-3" />
                          יקר בـ{item.overcharge_percentage?.toFixed(1)}%
                        </Badge>
                      )}
                      <Badge className={confidenceBadge.color}>
                        <Brain className="w-3 h-3 mr-1" />
                        {confidenceBadge.label}
                      </Badge>
                      <Badge className={statusBadge.color}>
                        <statusBadge.icon className="w-3 h-3 mr-1" />
                        {statusBadge.label}
                      </Badge>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div>
                      <label className="text-xs text-gray-500 block mb-1">כמות</label>
                      <Input
                        type="number"
                        value={item.quantity}
                        onChange={(e) => handleItemEdit(index, 'quantity', e.target.value)}
                        className="h-8"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-500 block mb-1">מחיר יחידה</label>
                      <Input
                        type="number"
                        step="0.01"
                        value={item.unit_price}
                        onChange={(e) => handleItemEdit(index, 'unit_price', e.target.value)}
                        className="h-8"
                      />
                    </div>
                    {item.catalog_price && (
                      <div>
                        <label className="text-xs text-gray-500 block mb-1">מחיר מקטלוג</label>
                        <div className="h-8 px-3 border rounded-md bg-gray-50 flex items-center text-sm">
                          ₪{item.catalog_price.toFixed(2)}
                        </div>
                      </div>
                    )}
                    <div>
                      <label className="text-xs text-gray-500 block mb-1">סה"כ</label>
                      <div className="h-8 px-3 border rounded-md bg-gray-50 flex items-center text-sm font-semibold">
                        ₪{(item.unit_price * item.quantity).toFixed(2)}
                      </div>
                    </div>
                  </div>

                  {/* Enhanced price analysis */}
                  {item.is_overcharged && (
                    <div className="mt-3 p-3 bg-red-100 rounded-lg">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-semibold text-red-800">
                            הפרש מחיר: ₪{item.price_difference?.toFixed(2)} לפריט
                          </p>
                          <p className="text-xs text-red-600">
                            חיסכון פוטנציאלי: ₪{(item.price_difference * item.quantity).toFixed(2)}
                          </p>
                          {item.anomaly_reason && (
                            <p className="text-xs text-red-500 mt-1">
                              סיבה: {item.anomaly_reason === 'exceeds_threshold' ? 'חריגה מהסף המותר' : 'מחוץ לטווח היסטורי'}
                            </p>
                          )}
                        </div>
                        <Button size="sm" variant="outline" className="gap-1">
                          <Phone className="w-3 h-3" />
                          התקשר לספק
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Confidence and validation details */}
                  {item.confidence_score < 0.6 && (
                    <div className="mt-3 p-3 bg-yellow-100 rounded-lg">
                      <p className="text-sm font-semibold text-yellow-800">
                        נדרשת בדיקה ידנית - רמת ביטחון נמוכה ({(item.confidence_score * 100).toFixed(0)}%)
                      </p>
                      <p className="text-xs text-yellow-700">
                        מומלץ לוודא את זיהוי המוצר והמחיר לפני אישור החשבונית
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex gap-3 justify-end">
        <Button variant="outline" onClick={onBack}>
          חזור
        </Button>
        <Button 
          onClick={handleSave}
          disabled={isSaving}
          className="bg-green-600 hover:bg-green-700 gap-2"
        >
          <Save className="w-4 h-4" />
          {isSaving ? 'שומר...' : 'שמור חשבונית'}
        </Button>
      </div>
    </div>
  );
}