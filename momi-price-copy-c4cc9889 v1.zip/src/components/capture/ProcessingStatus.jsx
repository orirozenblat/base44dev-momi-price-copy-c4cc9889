import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, Eye, Search, CheckCircle } from "lucide-react";

export default function ProcessingStatus({ isProcessing }) {
  const steps = [
    { icon: Eye, label: "קריאת התמונה", status: "completed" },
    { icon: Search, label: "זיהוי מוצרים ומחירים", status: isProcessing ? "current" : "pending" },
    { icon: CheckCircle, label: "השוואת מחירים", status: "pending" }
  ];

  return (
    <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
      <CardContent className="p-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 mx-auto mb-4 bg-blue-100 rounded-full flex items-center justify-center">
            <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            מעבד חשבונית...
          </h2>
          <p className="text-gray-600">
            אנא המתן, זה יקח כמה שניות
          </p>
        </div>

        <div className="space-y-4 max-w-md mx-auto">
          {steps.map((step, index) => (
            <div key={index} className="flex items-center gap-4">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                step.status === 'completed' ? 'bg-green-100' :
                step.status === 'current' ? 'bg-blue-100' : 'bg-gray-100'
              }`}>
                {step.status === 'current' ? (
                  <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />
                ) : (
                  <step.icon className={`w-5 h-5 ${
                    step.status === 'completed' ? 'text-green-600' :
                    step.status === 'current' ? 'text-blue-600' : 'text-gray-400'
                  }`} />
                )}
              </div>
              <span className={`font-medium ${
                step.status === 'completed' ? 'text-green-700' :
                step.status === 'current' ? 'text-blue-700' : 'text-gray-500'
              }`}>
                {step.label}
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}