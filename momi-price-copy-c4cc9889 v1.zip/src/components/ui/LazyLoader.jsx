// Lazy loading component with intersection observer
import React, { useState, useEffect, useRef } from 'react';

export default function LazyLoader({ 
  children, 
  fallback = <div className="animate-pulse bg-gray-200 h-20 rounded"></div>,
  threshold = 0.1 
}) {
  const [isVisible, setIsVisible] = useState(false);
  const [hasLoaded, setHasLoaded] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          setHasLoaded(true);
          observer.disconnect();
        }
      },
      { threshold }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [threshold]);

  return (
    <div ref={ref}>
      {hasLoaded ? children : fallback}
    </div>
  );
}