import React, { createContext, useContext } from 'react';

// Context for Sidebar state
const SidebarContext = createContext(null);

export const useSidebar = () => {
  const context = useContext(SidebarContext);
  if (!context) {
    throw new Error('useSidebar must be used within a SidebarProvider');
  }
  return context;
};

// Provider component
export const SidebarProvider = ({ children }) => {
  const [isOpen, setIsOpen] = React.useState(true);
  const value = { isOpen, setIsOpen };
  return (
    <SidebarContext.Provider value={value}>{children}</SidebarContext.Provider>
  );
};

// Main Sidebar Container
export const Sidebar = ({ children }) => (
  <aside className="h-full w-64 flex flex-col border-r bg-white shadow-sm">
    {children}
  </aside>
);

// Sidebar Header
export const SidebarHeader = ({ children }) => (
  <div className="p-2 border-b">{children}</div>
);

// Sidebar Content (main area)
export const SidebarContent = ({ children }) => (
  <div className="flex-1 overflow-y-auto">{children}</div>
);

// Sidebar Menu
export const SidebarMenu = ({ children }) => (
  <div className="py-4 px-3 space-y-4">{children}</div>
);

// Sidebar Group (for sections)
export const SidebarGroup = ({ children, className }) => (
  <div className={className}>{children}</div>
);

// Sidebar Group Label
export const SidebarGroupLabel = ({ children }) => (
  <h4 className="px-2 mb-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
    {children}
  </h4>
);

// Sidebar Group Content (wraps items)
export const SidebarGroupContent = ({ children }) => (
  <div className="space-y-1">{children}</div>
);

// Sidebar Menu Item
export const SidebarMenuItem = ({ children, asChild }) => {
  if (asChild) {
    return children;
  }
  return <div className="menu-item flex items-center gap-3 px-4 py-3 rounded-xl">{children}</div>;
};

// Sidebar Footer
export const SidebarFooter = ({ children }) => (
  <div className="mt-auto p-2 border-t">{children}</div>
);