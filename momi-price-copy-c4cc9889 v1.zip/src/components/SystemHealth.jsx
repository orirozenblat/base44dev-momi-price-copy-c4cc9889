import React, { useState, useEffect } from 'react';
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, CheckCircle } from "lucide-react";

export default function SystemHealth() {
  const [healthStatus, setHealthStatus] = useState('healthy');

  useEffect(() => {
    // Simple health check
    const checkHealth = () => {
      try {
        const errors = JSON.parse(localStorage.getItem('app_errors') || '[]');
        const recentErrors = errors.filter(error => 
          new Date(error.timestamp) > new Date(Date.now() - 60 * 60 * 1000)
        );
        
        if (recentErrors.length > 3) {
          setHealthStatus('error');
        } else if (recentErrors.length > 0) {
          setHealthStatus('warning');
        } else {
          setHealthStatus('healthy');
        }
      } catch (error) {
        setHealthStatus('error');
      }
    };

    checkHealth();
    const interval = setInterval(checkHealth, 60000);
    return () => clearInterval(interval);
  }, []);

  if (healthStatus === 'healthy') {
    return null;
  }

  const config = {
    warning: { icon: AlertTriangle, color: 'text-yellow-600', bg: 'bg-yellow-100', label: 'אזהרה' },
    error: { icon: AlertTriangle, color: 'text-red-600', bg: 'bg-red-100', label: 'שגיאה' }
  };

  const { icon: Icon, color, bg, label } = config[healthStatus] || config.error;

  return (
    <div className="fixed bottom-4 left-4 z-50">
      <Badge className={`${bg} ${color} border-0 shadow-lg`}>
        <Icon className="w-3 h-3 mr-1" />
        {label}
      </Badge>
    </div>
  );
}