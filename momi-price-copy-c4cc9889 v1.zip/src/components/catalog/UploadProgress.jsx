import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Loader2, Upload, Search, Database } from "lucide-react";

export default function UploadProgress({ progress, isUploading }) {
  const getStepInfo = () => {
    if (progress < 30) return { icon: Upload, text: "מעלה קובץ..." };
    if (progress < 60) return { icon: Search, text: "מנתח נתונים..." };
    if (progress < 90) return { icon: Database, text: "שומר למאגר..." };
    return { icon: Database, text: "מסיים עיבוד..." };
  };

  const stepInfo = getStepInfo();
  const StepIcon = stepInfo.icon;

  return (
    <Card className="shadow-lg border-0 bg-blue-50 border-blue-200 mb-6">
      <CardContent className="p-6">
        <div className="flex items-center gap-4">
          <div className="flex items-center justify-center w-12 h-12 bg-blue-100 rounded-full">
            {isUploading ? (
              <Loader2 className="w-6 h-6 text-blue-600 animate-spin" />
            ) : (
              <StepIcon className="w-6 h-6 text-blue-600" />
            )}
          </div>
          
          <div className="flex-1">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold text-blue-900">
                {stepInfo.text}
              </h3>
              <span className="text-sm font-medium text-blue-700">
                {progress}%
              </span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        </div>
        
        <p className="text-sm text-blue-700 mt-3">
          אנא המתן, זה יקח כמה רגעים...
        </p>
      </CardContent>
    </Card>
  );
}