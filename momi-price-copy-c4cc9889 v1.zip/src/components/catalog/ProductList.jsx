import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Package, Edit, TrendingUp, Search } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import VirtualList from "../ui/VirtualList";
import LazyLoader from "../ui/LazyLoader";

export default function ProductList({ products, isLoading, suppliers }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("updated_date");

  // Optimized filtering and sorting with useMemo
  const filteredAndSortedProducts = useMemo(() => {
    let filtered = products;
    
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = products.filter(product =>
        product.product_title.toLowerCase().includes(term) ||
        product.brand?.toLowerCase().includes(term) ||
        product.barcode.includes(term)
      );
    }

    return filtered.sort((a, b) => {
      switch (sortBy) {
        case 'price':
          return (b.cost_price || 0) - (a.cost_price || 0);
        case 'name':
          return a.product_title.localeCompare(b.product_title);
        case 'updated_date':
        default:
          return new Date(b.last_updated || b.updated_date) - new Date(a.last_updated || a.updated_date);
      }
    });
  }, [products, searchTerm, sortBy]);

  const renderProductItem = (product, index) => (
    <LazyLoader key={product.id || index}>
      <Card className="shadow-sm border-0 bg-white hover:shadow-md transition-shadow">
        <CardContent className="p-4">
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3 flex-1">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <Package className="w-5 h-5 text-blue-600" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-gray-900 truncate mb-1">
                  {product.product_title}
                </h3>
                <p className="text-sm text-gray-600 mb-2">
                  {product.brand && `${product.brand} • `}
                  ברקוד: {product.barcode}
                </p>
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <span>{product.amount_value} {product.amount_unit}</span>
                  <span>•</span>
                  <span>{product.dept_code}</span>
                </div>
              </div>
            </div>
            <div className="text-left space-y-2">
              <div className="font-bold text-lg text-gray-900">
                ₪{product.cost_price?.toFixed(2)}
              </div>
              {product.retail_price && (
                <div className="text-sm text-gray-500">
                  מחיר מכירה: ₪{product.retail_price.toFixed(2)}
                </div>
              )}
              <Link to={createPageUrl(`ProductDetails?id=${product.id}`)}>
                <Button size="sm" variant="outline" className="gap-1">
                  <Edit className="w-3 h-3" />
                  עריכה
                </Button>
              </Link>
            </div>
          </div>
        </CardContent>
      </Card>
    </LazyLoader>
  );

  if (isLoading) {
    return (
      <Card className="shadow-lg border-0 bg-white">
        <CardContent className="p-6">
          <div className="space-y-4">
            {Array(5).fill(0).map((_, i) => (
              <div key={i} className="animate-pulse flex items-center gap-4">
                <div className="w-10 h-10 bg-gray-200 rounded-lg"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
                <div className="w-20 h-6 bg-gray-200 rounded"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-lg border-0 bg-white">
      <CardHeader>
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <CardTitle className="text-xl font-bold">
            מוצרים בקטלוג ({filteredAndSortedProducts.length})
          </CardTitle>
          <div className="flex gap-2 w-full md:w-auto">
            <div className="relative flex-1 md:w-64">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="חיפוש מהיר..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10"
              />
            </div>
            <select 
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-3 py-2 border rounded-md bg-white"
            >
              <option value="updated_date">לפי עדכון</option>
              <option value="name">לפי שם</option>
              <option value="price">לפי מחיר</option>
            </select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {filteredAndSortedProducts.length === 0 ? (
          <div className="text-center py-12">
            <Package className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              {searchTerm ? 'לא נמצאו מוצרים' : 'אין מוצרים בקטלוג'}
            </h3>
            <p className="text-gray-600">
              {searchTerm ? 'נסה מונחי חיפוש אחרים' : 'העלה מחירון כדי להתחיל'}
            </p>
          </div>
        ) : (
          <VirtualList
            items={filteredAndSortedProducts}
            itemHeight={100}
            containerHeight={600}
            renderItem={renderProductItem}
          />
        )}
      </CardContent>
    </Card>
  );
}