import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Upload, FileSpreadsheet, AlertCircle, FileText, ExternalLink } from "lucide-react";

export default function CatalogUpload({ onFileUpload, fileInputRef, isUploading }) {
  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      onFileUpload(file);
    }
  };

  return (
    <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm mb-8">
      <CardHeader>
        <CardTitle className="text-xl font-bold flex items-center gap-2">
          <Upload className="w-5 h-5 text-green-600" />
          העלאת מחירון
        </CardTitle>
      </CardHeader>
      <CardContent>
        <input
          ref={fileInputRef}
          type="file"
          accept=".csv,.json"
          onChange={handleFileChange}
          className="hidden"
          disabled={isUploading}
        />
        
        <div className="grid md:grid-cols-2 gap-6">
          {/* Upload Area */}
          <div 
            className="border-2 border-dashed border-green-200 rounded-xl p-8 text-center cursor-pointer hover:border-green-400 hover:bg-green-50 transition-all duration-200"
            onClick={() => !isUploading && fileInputRef.current?.click()}
          >
            <div className="flex items-center justify-center gap-4 mb-4">
              <FileSpreadsheet className="w-12 h-12 text-green-600" />
              <FileText className="w-12 h-12 text-blue-600" />
            </div>
            <h3 className="text-xl font-bold mb-2">העלה קובץ נתונים</h3>
            <p className="text-gray-600 mb-4">
              {isUploading ? 'מעלה קובץ...' : 'לחץ כדי לבחור קובץ CSV או JSON'}
            </p>
            <div className="bg-green-600 text-white px-6 py-3 rounded-xl font-semibold inline-flex items-center gap-2">
              <Upload className="w-5 h-5" />
              {isUploading ? 'מעבד...' : 'בחר קובץ'}
            </div>
          </div>

          {/* Instructions */}
          <div className="space-y-4">
            <h4 className="text-lg font-semibold text-gray-900">דרישות הקובץ:</h4>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start gap-2">
                <span className="w-2 h-2 bg-green-600 rounded-full mt-2"></span>
                קובץ CSV או JSON בלבד
              </li>
              <li className="flex items-start gap-2">
                <span className="w-2 h-2 bg-green-600 rounded-full mt-2"></span>
                עמודות CSV: code, name, trade_mark, size, supplier, cost
              </li>
              <li className="flex items-start gap-2">
                <span className="w-2 h-2 bg-green-600 rounded-full mt-2"></span>
                JSON: מערך אובייקטים או {"{ products: [...] }"}
              </li>
              <li className="flex items-start gap-2">
                <span className="w-2 h-2 bg-green-600 rounded-full mt-2"></span>
                גודל מקסימלי: 10MB
              </li>
            </ul>

            {/* Excel Conversion Guide */}
            <div className="p-4 bg-amber-50 rounded-lg border border-amber-200">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5" />
                <div>
                  <h5 className="font-semibold text-amber-900 mb-1">יש לך קובץ Excel?</h5>
                  <p className="text-sm text-amber-800 mb-2">
                    המרה לפורמט CSV היא פשוטה:
                  </p>
                  <ol className="text-xs text-amber-800 space-y-1 mr-4">
                    <li>1. פתח את קובץ האקסל</li>
                    <li>2. לחץ "שמור בשם" (Save As)</li>
                    <li>3. בחר "CSV (Comma delimited)"</li>
                    <li>4. שמור והעלה כאן</li>
                  </ol>
                </div>
              </div>
            </div>

            {/* Feature Request */}
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <div className="flex items-start gap-2">
                <ExternalLink className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <h5 className="font-semibold text-blue-900 mb-1">רוצה תמיכה באקסל?</h5>
                  <p className="text-sm text-blue-800 mb-2">
                    אנחנו עובדים על הוספת תמיכה בקבצי Excel.
                  </p>
                  <button 
                    onClick={() => window.open('mailto:support@base44.app?subject=Excel Support Request&body=Hi, I would like to request Excel file support for the data extraction feature.')}
                    className="text-xs text-blue-700 underline hover:text-blue-900"
                  >
                    בקש תכונה זו מהצוות
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}