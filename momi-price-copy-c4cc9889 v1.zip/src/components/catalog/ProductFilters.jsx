import React, { useState, useEffect } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Department } from '@/components/utils/entityImports';

export default function ProductFilters({ 
  suppliers, 
  selectedSupplier, 
  setSelectedSupplier,
  selectedCategory,
  setSelectedCategory 
}) {
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    const fetchDepartments = async () => {
      try {
        const departmentsData = await Department.list();
        // Sort by name for user-friendliness
        departmentsData.sort((a, b) => a.name.localeCompare(b.name, 'he'));
        setCategories(departmentsData);
      } catch (error) {
        console.error("Failed to fetch departments:", error);
      }
    };

    fetchDepartments();
  }, []);

  return (
    <div className="flex gap-3">
      <Select value={selectedSupplier} onValueChange={setSelectedSupplier}>
        <SelectTrigger className="w-48">
          <SelectValue placeholder="בחר ספק" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">כל הספקים</SelectItem>
          {suppliers.map((supplier) => (
            <SelectItem key={supplier.id} value={supplier.id}>
              {supplier.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select value={selectedCategory} onValueChange={setSelectedCategory}>
        <SelectTrigger className="w-48">
          <SelectValue placeholder="בחר קטגוריה" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">כל הקטגוריות</SelectItem>
          {categories.map((category) => (
            <SelectItem key={category.id} value={category.code}>
              {category.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}