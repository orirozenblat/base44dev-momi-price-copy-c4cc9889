import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, Calendar, DollarSign, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import { he } from "date-fns/locale";

export default function RecentInvoices({ invoices, isLoading }) {
  const statusConfig = {
    'pending_review': { label: 'ממתין לבדיקה', color: 'bg-yellow-100 text-yellow-800' },
    'approved': { label: 'אושר', color: 'bg-green-100 text-green-800' },
    'disputed': { label: 'במחלוקת', color: 'bg-red-100 text-red-800' },
    'resolved': { label: 'נפתר', color: 'bg-blue-100 text-blue-800' }
  };

  if (isLoading) {
    return (
      <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-xl font-bold">חשבוניות אחרונות</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array(5).fill(0).map((_, index) => (
              <div key={index} className="animate-pulse">
                <div className="h-16 bg-gray-200 rounded"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-xl font-bold flex items-center gap-2">
          <FileText className="w-5 h-5 text-blue-600" />
          חשבוניות אחרונות ({invoices.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        {invoices.length > 0 ? (
          <div className="space-y-4">
            {invoices.map((invoice) => (
              <div
                key={invoice.id}
                className="p-4 border rounded-xl hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4 flex-1">
                    <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
                      <FileText className="w-6 h-6 text-blue-600" />
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-gray-900">
                          חשבונית #{invoice.invoice_number}
                        </h3>
                        <Badge className={statusConfig[invoice.status]?.color || 'bg-gray-100 text-gray-800'}>
                          {statusConfig[invoice.status]?.label || invoice.status}
                        </Badge>
                      </div>

                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          <span>
                            {invoice.invoice_date ? 
                              format(new Date(invoice.invoice_date), 'dd/MM/yyyy', { locale: he }) :
                              'לא צוין'
                            }
                          </span>
                        </div>
                        <div className="flex items-center gap-1">
                          <DollarSign className="w-3 h-3" />
                          <span>₪{invoice.total_amount?.toFixed(2) || '0.00'}</span>
                        </div>
                        {invoice.overcharge_count > 0 && (
                          <Badge variant="destructive" className="text-xs">
                            {invoice.overcharge_count} חריגות
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>

                  <Link to={createPageUrl("InvoiceDetails") + `?id=${invoice.id}`}>
                    <Button variant="ghost" size="sm">
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </Link>
                </div>
              </div>
            ))}

            <div className="pt-4 border-t">
              <Link to={createPageUrl("InvoiceList")}>
                <Button variant="outline" className="w-full">
                  הצג את כל החשבוניות
                </Button>
              </Link>
            </div>
          </div>
        ) : (
          <div className="text-center py-12">
            <FileText className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              אין חשבוניות במערכת
            </h3>
            <p className="text-gray-600 mb-4">
              צלם חשבונית ראשונה כדי להתחיל
            </p>
            <Link to={createPageUrl("InvoiceCapture")}>
              <Button className="gap-2">
                <FileText className="w-4 h-4" />
                צלם חשבונית
              </Button>
            </Link>
          </div>
        )}
      </CardContent>
    </Card>
  );
}