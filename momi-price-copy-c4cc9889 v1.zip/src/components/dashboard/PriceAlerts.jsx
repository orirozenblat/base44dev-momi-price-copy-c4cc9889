import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, TrendingUp, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function PriceAlerts({ overchargedItems, isLoading }) {
  if (isLoading) {
    return (
      <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-lg font-bold">התראות מחיר</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {Array(3).fill(0).map((_, index) => (
              <div key={index} className="animate-pulse">
                <div className="h-12 bg-gray-200 rounded"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Show top 5 most expensive overcharges
  const topAlerts = overchargedItems
    .sort((a, b) => (b.price_difference * b.quantity) - (a.price_difference * a.quantity))
    .slice(0, 5);

  return (
    <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-lg font-bold flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-red-600" />
          התראות מחיר ({overchargedItems.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        {topAlerts.length > 0 ? (
          <div className="space-y-3">
            {topAlerts.map((item, index) => (
              <div
                key={item.id || index}
                className="p-3 bg-red-50 border border-red-200 rounded-lg"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900 text-sm mb-1">
                      {item.product_name}
                    </h4>
                    <div className="flex items-center gap-2 text-xs text-gray-600">
                      <Badge variant="destructive" className="text-xs">
                        +{item.overcharge_percentage?.toFixed(1) || '0'}%
                      </Badge>
                      <span>
                        חיסכון: ₪{((item.price_difference || 0) * (item.quantity || 1)).toFixed(2)}
                      </span>
                    </div>
                  </div>
                  <TrendingUp className="w-4 h-4 text-red-500" />
                </div>
              </div>
            ))}

            <div className="pt-3 border-t">
              <Link to={createPageUrl("PriceAlerts")}>
                <Button variant="outline" size="sm" className="w-full gap-2">
                  הצג את כל התראות
                  <ChevronRight className="w-3 h-3" />
                </Button>
              </Link>
            </div>
          </div>
        ) : (
          <div className="text-center py-8">
            <AlertTriangle className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <p className="text-sm text-gray-600">אין התראות מחיר פעילות</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}