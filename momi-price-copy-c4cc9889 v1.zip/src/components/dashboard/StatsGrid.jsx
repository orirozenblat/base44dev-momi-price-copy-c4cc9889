import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, DollarSign, AlertTriangle, Package } from "lucide-react";
import LazyLoader from "../ui/LazyLoader";

// Lightweight stats component with memoization
const StatCard = React.memo(({ icon: Icon, label, value, trend, color = "blue" }) => (
  <LazyLoader>
    <Card className="shadow-lg border-0 bg-white">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-500">{label}</p>
            <p className="text-2xl font-bold text-gray-900">{value}</p>
            {trend && (
              <p className={`text-xs ${trend > 0 ? 'text-green-600' : 'text-red-600'}`}>
                {trend > 0 ? '+' : ''}{trend.toFixed(1)}% מהחודש שעבר
              </p>
            )}
          </div>
          <Icon className={`w-8 h-8 text-${color}-600`} />
        </div>
      </CardContent>
    </Card>
  </LazyLoader>
));

export default function StatsGrid({ stats, isLoading }) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {Array(4).fill(0).map((_, i) => (
          <Card key={i} className="shadow-lg border-0 bg-white">
            <CardContent className="p-6">
              <div className="animate-pulse flex items-center justify-between">
                <div className="space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-20"></div>
                  <div className="h-8 bg-gray-200 rounded w-16"></div>
                </div>
                <div className="w-8 h-8 bg-gray-200 rounded"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <StatCard
        icon={Package}
        label="סה״כ חשבוניות"
        value={stats.totalInvoices}
        color="blue"
      />
      <StatCard
        icon={DollarSign}
        label="חיסכון חודשי"
        value={`₪${stats.monthlySavings?.toFixed(0) || '0'}`}
        trend={stats.savingsTrend}
        color="green"
      />
      <StatCard
        icon={AlertTriangle}
        label="התראות פעילות"
        value={stats.activeAlerts}
        color="orange"
      />
      <StatCard
        icon={TrendingUp}
        label="מוצרים בקטלוג"
        value={stats.totalProducts}
        color="purple"
      />
    </div>
  );
}