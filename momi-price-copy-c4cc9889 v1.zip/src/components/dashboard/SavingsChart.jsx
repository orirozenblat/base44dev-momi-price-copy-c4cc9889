import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingDown, DollarSign } from "lucide-react";

export default function SavingsChart({ overchargedItems, isLoading }) {
  if (isLoading) {
    return (
      <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-lg font-bold">סיכום חיסכון</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse">
            <div className="h-24 bg-gray-200 rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const totalSavings = overchargedItems.reduce((sum, item) => 
    sum + ((item.price_difference || 0) * (item.quantity || 1)), 0
  );

  const avgOvercharge = overchargedItems.length > 0 ? 
    overchargedItems.reduce((sum, item) => sum + (item.overcharge_percentage || 0), 0) / overchargedItems.length : 0;

  return (
    <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-lg font-bold flex items-center gap-2">
          <TrendingDown className="w-5 h-5 text-green-600" />
          סיכום חיסכון
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <DollarSign className="w-6 h-6 text-green-600" />
              <span className="text-3xl font-bold text-green-600">
                ₪{totalSavings.toFixed(2)}
              </span>
            </div>
            <p className="text-sm text-gray-600">חיסכון פוטנציאלי חודשי</p>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-4 border-t">
            <div className="text-center">
              <div className="text-xl font-bold text-gray-900">
                {overchargedItems.length}
              </div>
              <p className="text-xs text-gray-600">פריטים שזוהו</p>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-gray-900">
                {avgOvercharge.toFixed(1)}%
              </div>
              <p className="text-xs text-gray-600">הייקרות ממוצעת</p>
            </div>
          </div>

          {totalSavings > 1000 && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-3">
              <p className="text-sm text-green-800 text-center">
                💡 חיסכון משמעותי זוהה! שקול לנהל משא ומתן עם הספקים
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}