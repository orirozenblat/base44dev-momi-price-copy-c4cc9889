import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { 
  Phone, 
  Mail, 
  CheckCircle, 
  AlertTriangle,
  Calendar,
  Building2,
  DollarSign,
  Package
} from "lucide-react";
import { format } from "date-fns";
import { he } from "date-fns/locale";

export default function AlertDetails({ 
  alert, 
  invoice, 
  supplier, 
  onResolve, 
  onSendEmail, 
  actionLoading 
}) {
  const [notes, setNotes] = React.useState('');

  const handleResolve = () => {
    onResolve(alert.id, notes || 'נפתר ידנית');
  };

  const handleSendEmail = () => {
    if (!supplier?.email) return;
    
    const subject = `תיקון מחיר - ${alert.product_name}`;
    const body = `
שלום ${supplier.contact_person || 'רב כבוד'},

בהמשך לחשבונית מספר ${invoice?.invoice_number || 'לא זוהה'} מתאריך ${invoice ? format(new Date(invoice.invoice_date), 'dd/MM/yyyy', { locale: he }) : 'לא זוהה'},

זיהינו הפרש מחיר במוצר הבא:
• ${alert.product_name}
• מחיר שחויב: ₪${alert.unit_price?.toFixed(2)}
• מחיר מקטלוג: ₪${alert.catalog_price?.toFixed(2)}
• הפרש: +${alert.overcharge_percentage?.toFixed(1)}%
• חיסכון פוטנציאלי: ₪${(alert.price_difference * alert.quantity).toFixed(2)}

אנא בדקו ותקנו את המחיר בהתאם למחירון.

בברכה,
צוות רכישות
    `;
    
    onSendEmail(supplier.email, subject, body);
  };

  return (
    <Card className="shadow-lg border-0 bg-[hsl(var(--card))]">
      <CardHeader>
        <CardTitle className="text-lg font-bold">פרטי התראה</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Alert Details */}
        <div className="space-y-4">
          <div>
            <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
              <Package className="w-4 h-4 text-blue-600" />
              {alert.product_name}
            </h3>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <span className="text-gray-500">כמות:</span>
                <p className="font-semibold">{alert.quantity}</p>
              </div>
              <div>
                <span className="text-gray-500">מחיר חויב:</span>
                <p className="font-semibold">₪{alert.unit_price?.toFixed(2)}</p>
              </div>
              <div>
                <span className="text-gray-500">מחיר מקטלוג:</span>
                <p className="font-semibold text-green-600">₪{alert.catalog_price?.toFixed(2)}</p>
              </div>
              <div>
                <span className="text-gray-500">הפרש:</span>
                <Badge variant="destructive">
                  +{alert.overcharge_percentage?.toFixed(1)}%
                </Badge>
              </div>
            </div>
          </div>

          {/* Financial Impact */}
          <div className="p-4 bg-red-50 rounded-lg border border-red-200">
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="w-4 h-4 text-red-600" />
              <span className="font-semibold text-red-800">השפעה כלכלית</span>
            </div>
            <p className="text-sm text-red-700">
              חיסכון פוטנציאלי: <strong>₪{(alert.price_difference * alert.quantity).toFixed(2)}</strong>
            </p>
          </div>

          {/* Invoice Info */}
          {invoice && (
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <div className="flex items-center gap-2 mb-2">
                <Calendar className="w-4 h-4 text-blue-600" />
                <span className="font-semibold text-blue-800">פרטי חשבונית</span>
              </div>
              <div className="text-sm text-blue-700 space-y-1">
                <p>מספר: #{invoice.invoice_number}</p>
                <p>תאריך: {format(new Date(invoice.invoice_date), 'dd/MM/yyyy', { locale: he })}</p>
                <p>סכום כולל: ₪{invoice.total_amount?.toFixed(2)}</p>
              </div>
            </div>
          )}

          {/* Supplier Info */}
          {supplier && (
            <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
              <div className="flex items-center gap-2 mb-2">
                <Building2 className="w-4 h-4 text-gray-600" />
                <span className="font-semibold text-gray-800">פרטי ספק</span>
              </div>
              <div className="text-sm text-gray-700 space-y-1">
                <p><strong>שם:</strong> {supplier.name}</p>
                <p><strong>איש קשר:</strong> {supplier.contact_person}</p>
                <p><strong>טלפון:</strong> {supplier.phone}</p>
                <p><strong>אימייל:</strong> {supplier.email}</p>
              </div>
            </div>
          )}

          {/* Notes */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              הערות לפתרון
            </label>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="הוסף הערות על הטיפול בהתראה..."
              rows={3}
            />
          </div>

          {/* Actions */}
          <div className="space-y-3">
            {supplier?.phone && (
              <Button 
                variant="outline" 
                className="w-full justify-start gap-2"
                onClick={() => window.open(`tel:${supplier.phone}`)}
              >
                <Phone className="w-4 h-4" />
                התקשר לספק
              </Button>
            )}
            
            {supplier?.email && (
              <Button 
                variant="outline" 
                className="w-full justify-start gap-2"
                onClick={handleSendEmail}
                disabled={actionLoading}
              >
                <Mail className="w-4 h-4" />
                שלח מייל לספק
              </Button>
            )}
            
            <Button 
              onClick={handleResolve}
              disabled={actionLoading}
              className="w-full bg-green-600 hover:bg-green-700 gap-2"
            >
              <CheckCircle className="w-4 h-4" />
              {actionLoading ? 'מעבד...' : 'פתור התראה'}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}