import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle, TrendingDown, DollarSign, Clock } from "lucide-react";

export default function AlertsStats({ stats }) {
  const statCards = [
    {
      icon: AlertTriangle,
      label: "סה״כ התראות",
      value: stats.total,
      color: "text-[hsl(var(--warning))]",
      bgColor: "bg-[hsl(var(--warning-light))]"
    },
    {
      icon: AlertTriangle,
      label: "קריטיות",
      value: stats.critical,
      color: "text-[hsl(var(--destructive))]",
      bgColor: "bg-[hsl(var(--destructive-light))]"
    },
    {
      icon: Clock,
      label: "בינוניות",
      value: stats.moderate,
      color: "text-[hsl(var(--warning))]",
      bgColor: "bg-[hsl(var(--warning-light))]"
    },
    {
      icon: DollarSign,
      label: "חיסכון פוטנציאלי",
      value: `₪${stats.totalSavings.toFixed(2)}`,
      color: "text-[hsl(var(--success))]",
      bgColor: "bg-[hsl(var(--success-light))]"
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
      {statCards.map((stat, index) => (
        <Card key={index} className="shadow-lg border-0 bg-[hsl(var(--card))]">
          <CardContent className="p-4 lg:p-6">
            <div className="flex items-center gap-3">
              <div className={`p-2 lg:p-3 rounded-xl ${stat.bgColor}`}>
                <stat.icon className={`w-4 h-4 lg:w-6 lg:h-6 ${stat.color}`} />
              </div>
              <div>
                <p className="text-xs lg:text-sm font-medium text-gray-600">{stat.label}</p>
                <p className="text-lg lg:text-xl font-bold text-gray-900">{stat.value}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}