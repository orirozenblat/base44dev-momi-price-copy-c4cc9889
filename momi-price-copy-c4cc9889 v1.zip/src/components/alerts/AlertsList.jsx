
import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertTriangle,
  CheckCircle,
  Table,
  ChevronRight
} from "lucide-react";
import { format } from "date-fns";
import { he } from "date-fns/locale";
import { InvoiceItem } from '@/api/entities';
import { Product } from '@/api/entities';
import { Supplier } from '@/api/entities';

export default function AlertsList({ 
  alerts, 
  invoices, 
  suppliers, 
  isLoading, 
  selectedAlert, 
  onSelectAlert, 
  onResolveAlert, 
  actionLoading 
}) {
  const getInvoiceForAlert = (alert) => {
    return invoices.find(invoice => invoice.id === alert.invoice_id);
  };

  const getSupplierForInvoice = (invoice) => {
    if (!invoice) return null;
    return suppliers.find(s => s.id === invoice.supplier_id);
  };

  const renderSkeleton = () => (
    <div className="space-y-4">
      {Array(5).fill(0).map((_, i) => (
        <div key={i} className="p-4 border rounded-xl">
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3 flex-1">
              <Skeleton className="w-10 h-10 rounded-lg" />
              <div className="space-y-2 flex-1">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
                <Skeleton className="h-3 w-1/3" />
              </div>
            </div>
            <Skeleton className="h-6 w-16" />
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <Card className="shadow-lg border-0 bg-[hsl(var(--card))]">
      <CardHeader>
        <CardTitle className="text-lg font-bold">
          רשימת התראות פעילות ({alerts.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? renderSkeleton() : (
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {alerts.map((alert) => {
              const invoice = getInvoiceForAlert(alert);
              const supplier = getSupplierForInvoice(invoice);
              const isSelected = selectedAlert?.id === alert.id;
              
              return (
                <div 
                  key={alert.id}
                  className={`p-4 border-2 rounded-xl cursor-pointer transition-all duration-200 ${
                    isSelected 
                      ? 'border-[hsl(var(--primary))] bg-[hsl(var(--primary-light))]' 
                      : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                  }`}
                  onClick={() => onSelectAlert(alert)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3 flex-1">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        alert.overcharge_percentage >= 15 
                          ? 'bg-[hsl(var(--destructive-light))]' 
                          : 'bg-[hsl(var(--warning-light))]'
                      }`}>
                        <AlertTriangle className={`w-5 h-5 ${
                          alert.overcharge_percentage >= 15 
                            ? 'text-[hsl(var(--destructive))]' 
                            : 'text-[hsl(var(--warning))]'
                        }`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-gray-900 truncate mb-1">
                          {alert.product_name}
                        </h3>
                        <p className="text-sm text-gray-600 mb-1">
                          ספק: {supplier?.name || 'לא ידוע'}
                        </p>
                        <p className="text-sm text-gray-600">
                          חשבונית: #{invoice?.invoice_number} • {invoice && format(new Date(invoice.invoice_date), 'dd/MM', { locale: he })}
                        </p>
                        <p className="text-sm font-semibold text-[hsl(var(--destructive))] mt-1">
                          הפרש: ₪{alert.price_difference?.toFixed(2)} × {alert.quantity} = ₪{(alert.price_difference * alert.quantity).toFixed(2)}
                        </p>
                      </div>
                    </div>
                    <div className="text-left space-y-2">
                      <Badge className={
                        alert.overcharge_percentage >= 15 
                          ? 'bg-[hsl(var(--destructive-light))] text-[hsl(var(--destructive-dark))]'
                          : 'bg-[hsl(var(--warning-light))] text-[hsl(var(--warning-dark))]'
                      }>
                        +{alert.overcharge_percentage?.toFixed(1)}%
                      </Badge>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={(e) => {
                          e.stopPropagation();
                          onResolveAlert(alert.id, 'הותר ידנית');
                        }}
                        disabled={actionLoading}
                        className="block w-full gap-1"
                      >
                        <CheckCircle className="w-3 h-3" />
                        פתור
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
            {alerts.length === 0 && (
              <div className="text-center py-12">
                <AlertTriangle className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  אין התראות פעילות
                </h3>
                <p className="text-gray-600">
                  כל המחירים תקינים או שכל ההתראות טופלו
                </p>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
