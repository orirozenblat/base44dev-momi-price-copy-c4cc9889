import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Phone, Mail, X } from "lucide-react";
import { format } from "date-fns";
import { he } from "date-fns/locale";

export default function NegotiationPanel({ 
  alert, 
  invoice, 
  supplier,
  onClose,
  onSendEmail, 
  onResolve, 
  actionLoading 
}) {
  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4"
      onClick={onClose}
    >
      <Card 
        className="max-w-lg w-full shadow-2xl animate-in fade-in-0 zoom-in-95"
        onClick={(e) => e.stopPropagation()}
      >
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl font-bold">משא ומתן עם {supplier?.name}</CardTitle>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
          <p className="text-sm text-gray-600">
            בנוגע למוצר: {alert.product_name}
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Key info */}
            <div className="p-4 bg-amber-50 rounded-lg border border-amber-200">
              <h3 className="font-semibold text-amber-900 mb-2">פרטי המקרה</h3>
              <ul className="text-sm text-amber-800 space-y-1">
                <li><strong>מוצר:</strong> {alert.product_name}</li>
                <li><strong>הפרש מחיר ליחידה:</strong> ₪{alert.price_difference?.toFixed(2)}</li>
                <li><strong>חיסכון פוטנציאלי:</strong> ₪{(alert.price_difference * alert.quantity).toFixed(2)}</li>
                <li><strong>חשבונית:</strong> #{invoice?.invoice_number} מתאריך {invoice && format(new Date(invoice.invoice_date), 'dd/MM/yyyy', { locale: he })}</li>
              </ul>
            </div>
            
            {/* Contact options */}
            <div className="space-y-3">
              <h3 className="font-semibold">יצירת קשר</h3>
              {supplier?.phone && (
                <a href={`tel:${supplier.phone}`} className="block">
                  <Button variant="outline" className="w-full justify-start gap-3">
                    <Phone className="w-4 h-4 text-blue-600" />
                    <div className="text-right">
                      <p>התקשר לאיש הקשר</p>
                      <p className="text-xs text-gray-500">{supplier.contact_person} - {supplier.phone}</p>
                    </div>
                  </Button>
                </a>
              )}
              {supplier?.email && (
                <a href={`mailto:${supplier.email}`} className="block">
                  <Button variant="outline" className="w-full justify-start gap-3">
                    <Mail className="w-4 h-4 text-green-600" />
                    <div className="text-right">
                      <p>שלח מייל לספק</p>
                      <p className="text-xs text-gray-500">{supplier.email}</p>
                    </div>
                  </Button>
                </a>
              )}
            </div>

            {/* Negotiation Tips */}
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <h3 className="font-semibold text-blue-900 mb-2">טיפים למשא ומתן</h3>
              <ul className="text-sm text-blue-800 space-y-1 list-disc list-inside">
                <li>הצג את הנתונים באופן ברור ומדויק</li>
                <li>בקש זיכוי על ההפרש בהזמנה הנוכחית</li>
                <li>ודא שהמחיר יתוקן להזמנות הבאות</li>
                <li>שקול הנחות על כמויות גדולות יותר</li>
              </ul>
            </div>

            {/* Resolution */}
            <div className="flex gap-4">
              <Button 
                onClick={() => onResolve(alert.id, 'מחיר תוקן בעקבות משא ומתן')}
                disabled={actionLoading}
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                סמן כנפתר
              </Button>
              <Button 
                variant="outline" 
                onClick={onClose}
                className="flex-1"
              >
                סגור
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}