import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Building2, Save } from "lucide-react";

export default function StoreSettings({ user, onSave, isSaving }) {
  const [storeData, setStoreData] = useState({
    store_name: user?.store_name || '',
    store_address: user?.store_address || '',
    store_phone: user?.store_phone || '',
    business_number: user?.business_number || '',
    tax_id: user?.tax_id || '',
    store_type: user?.store_type || 'supermarket',
    default_currency: user?.default_currency || 'ILS'
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(storeData);
  };

  const handleChange = (field, value) => {
    setStoreData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-xl font-bold flex items-center gap-2">
          <Building2 className="w-5 h-5 text-green-600" />
          הגדרות חנות
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Store Basic Info */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900">פרטי חנות</h3>
            
            <div className="space-y-2">
              <Label htmlFor="store_name">שם החנות</Label>
              <Input
                id="store_name"
                value={storeData.store_name}
                onChange={(e) => handleChange('store_name', e.target.value)}
                placeholder="סופרמרקט המרכז"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="store_address">כתובת</Label>
              <Input
                id="store_address"
                value={storeData.store_address}
                onChange={(e) => handleChange('store_address', e.target.value)}
                placeholder="רחוב הרצל 10, תל אביב"
              />
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="store_phone">טלפון חנות</Label>
                <Input
                  id="store_phone"
                  value={storeData.store_phone}
                  onChange={(e) => handleChange('store_phone', e.target.value)}
                  placeholder="03-1234567"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="store_type">סוג חנות</Label>
                <Select value={storeData.store_type} onValueChange={(value) => handleChange('store_type', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="בחר סוג חנות" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="supermarket">סופרמרקט</SelectItem>
                    <SelectItem value="mini_market">מיני מרקט</SelectItem>
                    <SelectItem value="hypermarket">היפרמרקט</SelectItem>
                    <SelectItem value="convenience">חנות נוחות</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Business Info */}
          <div className="space-y-4 pt-6 border-t">
            <h3 className="font-semibold text-gray-900">פרטים עסקיים</h3>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="business_number">מספר עסק</Label>
                <Input
                  id="business_number"
                  value={storeData.business_number}
                  onChange={(e) => handleChange('business_number', e.target.value)}
                  placeholder="123456789"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="tax_id">ח.פ / ע.מ</Label>
                <Input
                  id="tax_id"
                  value={storeData.tax_id}
                  onChange={(e) => handleChange('tax_id', e.target.value)}
                  placeholder="123456789"
                />
              </div>
            </div>
          </div>

          {/* System Settings */}
          <div className="space-y-4 pt-6 border-t">
            <h3 className="font-semibold text-gray-900">הגדרות מערכת</h3>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="default_currency">מטבע ברירת מחדל</Label>
                <Select value={storeData.default_currency} onValueChange={(value) => handleChange('default_currency', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="בחר מטבע" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ILS">שקל חדש (₪)</SelectItem>
                    <SelectItem value="USD">דולר ($)</SelectItem>
                    <SelectItem value="EUR">יורו (€)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Save Button */}
          <div className="flex justify-end pt-6 border-t">
            <Button 
              type="submit" 
              disabled={isSaving}
              className="bg-green-600 hover:bg-green-700 gap-2"
            >
              <Save className="w-4 h-4" />
              {isSaving ? 'שומר...' : 'שמור הגדרות'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}