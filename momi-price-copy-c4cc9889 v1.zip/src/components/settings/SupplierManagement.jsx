import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Building2,
  Plus,
  Edit,
  Trash2,
  Phone,
  Mail,
  Save,
  X
} from "lucide-react";
import { Supplier } from "@/components/utils/entityImports";

export default function SupplierManagement({ suppliers, onSaveSupplier, isSaving }) {
  const [editingSupplier, setEditingSupplier] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    contact_person: '',
    phone: '',
    email: '',
    payment_terms: '',
    is_active: true
  });

  const resetForm = () => {
    setFormData({
      name: '',
      contact_person: '',
      phone: '',
      email: '',
      payment_terms: '',
      is_active: true
    });
    setEditingSupplier(null);
    setShowAddForm(false);
  };

  const handleEdit = (supplier) => {
    setFormData(supplier);
    setEditingSupplier(supplier.id);
    setShowAddForm(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await onSaveSupplier(formData);
    resetForm();
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="space-y-6">
      {/* Add/Edit Form */}
      {showAddForm && (
        <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-bold">
                {editingSupplier ? 'עריכת ספק' : 'הוספת ספק חדש'}
              </CardTitle>
              <Button variant="ghost" size="icon" onClick={resetForm}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">שם הספק</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => handleChange('name', e.target.value)}
                    placeholder="שם הספק"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="contact_person">איש קשר</Label>
                  <Input
                    id="contact_person"
                    value={formData.contact_person}
                    onChange={(e) => handleChange('contact_person', e.target.value)}
                    placeholder="שם איש הקשר"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">טלפון</Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => handleChange('phone', e.target.value)}
                    placeholder="03-1234567"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">אימייל</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleChange('email', e.target.value)}
                    placeholder="supplier@example.com"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="payment_terms">תנאי תשלום</Label>
                <Input
                  id="payment_terms"
                  value={formData.payment_terms}
                  onChange={(e) => handleChange('payment_terms', e.target.value)}
                  placeholder="30 יום"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <Button
                  type="submit"
                  disabled={isSaving}
                  className="bg-blue-600 hover:bg-blue-700 gap-2"
                >
                  <Save className="w-4 h-4" />
                  {isSaving ? 'שומר...' : editingSupplier ? 'עדכן ספק' : 'הוסף ספק'}
                </Button>
                <Button type="button" variant="outline" onClick={resetForm}>
                  ביטול
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Suppliers List */}
      <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl font-bold flex items-center gap-2">
              <Building2 className="w-5 h-5 text-blue-600" />
              ספקים ({suppliers?.length || 0})
            </CardTitle>
            <Button
              onClick={() => setShowAddForm(true)}
              className="bg-blue-600 hover:bg-blue-700 gap-2"
            >
              <Plus className="w-4 h-4" />
              הוסף ספק
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {suppliers && suppliers.length > 0 ? (
            <div className="space-y-4">
              {suppliers.map((supplier) => (
                <div key={supplier.id} className="p-4 border rounded-xl hover:bg-gray-50 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-4 flex-1">
                      <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
                        <Building2 className="w-6 h-6 text-blue-600" />
                      </div>

                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-gray-900">{supplier.name}</h3>
                          <Badge variant={supplier.is_active ? "default" : "secondary"}>
                            {supplier.is_active ? 'פעיל' : 'לא פעיל'}
                          </Badge>
                        </div>

                        {supplier.contact_person && (
                          <p className="text-sm text-gray-600 mb-1">
                            איש קשר: {supplier.contact_person}
                          </p>
                        )}

                        <div className="flex items-center gap-4 text-sm text-gray-600">
                          {supplier.phone && (
                            <div className="flex items-center gap-1">
                              <Phone className="w-3 h-3" />
                              <span>{supplier.phone}</span>
                            </div>
                          )}
                          {supplier.email && (
                            <div className="flex items-center gap-1">
                              <Mail className="w-3 h-3" />
                              <span>{supplier.email}</span>
                            </div>
                          )}
                        </div>

                        {supplier.payment_terms && (
                          <p className="text-xs text-gray-500 mt-1">
                            תנאי תשלום: {supplier.payment_terms}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEdit(supplier)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Building2 className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                אין ספקים במערכת
              </h3>
              <p className="text-gray-600 mb-4">
                הוסף ספקים כדי להתחיל לנהל את הקטלוג
              </p>
              <Button
                onClick={() => setShowAddForm(true)}
                className="gap-2"
              >
                <Plus className="w-4 h-4" />
                הוסף ספק ראשון
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}