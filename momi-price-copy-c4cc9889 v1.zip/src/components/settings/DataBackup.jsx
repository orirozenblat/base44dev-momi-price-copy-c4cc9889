
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Download, 
  Upload, 
  Database, 
  CheckCircle, 
  AlertTriangle,
  Clock,
  HardDrive
} from "lucide-react";
import { Invoice, InvoiceItem, Product, Supplier, User } from "@/components/utils/entityImports";

export default function DataBackup() {
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [lastBackup, setLastBackup] = useState(localStorage.getItem('lastBackupTime'));
  const [backupSize, setBackupSize] = useState(0);

  // Initialize backupSize from localStorage if available, ensuring it's a number
  React.useEffect(() => {
    const storedSize = localStorage.getItem('lastBackupSize');
    if (storedSize) {
      setBackupSize(parseInt(storedSize, 10));
    }
  }, []);

  const createBackup = async () => {
    setIsBackingUp(true);
    try {
      // Fetch all data
      const [users, suppliers, products, invoices, invoiceItems] = await Promise.all([
        User.list().catch(() => []),
        Supplier.list().catch(() => []),
        Product.list().catch(() => []),
        Invoice.list().catch(() => []),
        InvoiceItem.list().catch(() => [])
      ]);

      const backupData = {
        version: "1.0",
        timestamp: new Date().toISOString(),
        data: {
          users,
          suppliers,
          products,
          invoices,
          invoiceItems
        },
        metadata: {
          totalRecords: users.length + suppliers.length + products.length + invoices.length + invoiceItems.length,
          tables: {
            users: users.length,
            suppliers: suppliers.length,
            products: products.length,
            invoices: invoices.length,
            invoiceItems: invoiceItems.length
          }
        }
      };

      // Convert to JSON and create downloadable file
      const jsonString = JSON.stringify(backupData, null, 2);
      const blob = new Blob([jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      // Create download link
      const link = document.createElement('a');
      link.href = url;
      link.download = `momi-backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      // Update backup info
      const now = new Date().toISOString();
      setLastBackup(now);
      setBackupSize(blob.size);
      localStorage.setItem('lastBackupTime', now);
      localStorage.setItem('lastBackupSize', blob.size.toString());

      alert('הגיבוי נוצר והורד בהצלחה!');
    } catch (error) {
      console.error('Backup creation failed:', error);
      alert('שגיאה ביצירת הגיבוי: ' + error.message);
    }
    setIsBackingUp(false);
  };

  const handleFileRestore = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (!confirm('האם אתה בטוח שברצונך לשחזר נתונים מגיבוי? פעולה זו עלולה להחליף נתונים קיימים!')) {
      return;
    }

    setIsRestoring(true);
    try {
      const text = await file.text();
      const backupData = JSON.parse(text);

      // Validate backup structure
      if (!backupData.version || !backupData.data) {
        throw new Error('קובץ גיבוי לא תקין');
      }

      // Note: Actual restore would need backend support for bulk operations
      // For now, we'll just validate the backup file
      console.log('Backup data validated:', backupData.metadata);
      
      alert(`גיבוי תקף נטען! כולל ${backupData.metadata.totalRecords} רשומות. שחזור מלא יהיה זמין בגרסה הבאה.`);
      
    } catch (error) {
      console.error('Restore failed:', error);
      alert('שגיאה בשחזור הגיבוי: ' + error.message);
    }
    setIsRestoring(false);
    
    // Reset file input
    event.target.value = '';
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getBackupStatus = () => {
    if (!lastBackup) {
      return {
        icon: AlertTriangle,
        color: 'text-yellow-600',
        bgColor: 'bg-yellow-100',
        label: 'לא בוצע גיבוי'
      };
    }

    const backupDate = new Date(lastBackup);
    const daysSinceBackup = (Date.now() - backupDate.getTime()) / (1000 * 60 * 60 * 24);

    if (daysSinceBackup > 7) {
      return {
        icon: AlertTriangle,
        color: 'text-red-600',
        bgColor: 'bg-red-100',
        label: 'גיבוי ישן'
      };
    }

    return {
      icon: CheckCircle,
      color: 'text-green-600',
      bgColor: 'bg-green-100',
      label: 'גיבוי עדכני'
    };
  };

  const backupStatus = getBackupStatus();
  const BackupIcon = backupStatus.icon;

  return (
    <Card className="shadow-lg border-0 bg-white">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="w-5 h-5 text-blue-600" />
          גיבוי ושחזור נתונים
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Backup Status */}
        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-full ${backupStatus.bgColor}`}>
              <BackupIcon className={`w-5 h-5 ${backupStatus.color}`} />
            </div>
            <div>
              <p className="font-semibold">{backupStatus.label}</p>
              {lastBackup && (
                <p className="text-sm text-gray-600">
                  גיבוי אחרון: {new Date(lastBackup).toLocaleString('he-IL')}
                </p>
              )}
              {backupSize > 0 && (
                <p className="text-xs text-gray-500">
                  גודל: {formatFileSize(backupSize)}
                </p>
              )}
            </div>
          </div>
          <Badge className={`${backupStatus.bgColor} ${backupStatus.color} border-0`}>
            <HardDrive className="w-3 h-3 mr-1" />
            {lastBackup ? 'קיים' : 'לא קיים'}
          </Badge>
        </div>

        {/* Backup Actions */}
        <div className="space-y-4">
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              מומלץ לבצע גיבוי לפני עדכונים או שינויים משמעותיים במערכת.
            </AlertDescription>
          </Alert>

          <div className="grid md:grid-cols-2 gap-4">
            {/* Create Backup */}
            <div className="space-y-3">
              <h4 className="font-semibold flex items-center gap-2">
                <Download className="w-4 h-4" />
                יצירת גיבוי
              </h4>
              <p className="text-sm text-gray-600">
                הורד גיבוי מלא של כל נתוני המערכת
              </p>
              <Button
                onClick={createBackup}
                disabled={isBackingUp}
                className="w-full gap-2"
              >
                <Download className={`w-4 h-4 ${isBackingUp ? 'animate-bounce' : ''}`} />
                {isBackingUp ? 'יוצר גיבוי...' : 'צור גיבוי'}
              </Button>
            </div>

            {/* Restore Backup */}
            <div className="space-y-3">
              <h4 className="font-semibold flex items-center gap-2">
                <Upload className="w-4 h-4" />
                שחזור גיבוי
              </h4>
              <p className="text-sm text-gray-600">
                העלה וטען קובץ גיבוי קיים
              </p>
              <div className="relative">
                <input
                  type="file"
                  accept=".json"
                  onChange={handleFileRestore}
                  disabled={isRestoring}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <Button
                  variant="outline"
                  disabled={isRestoring}
                  className="w-full gap-2"
                >
                  <Upload className={`w-4 h-4 ${isRestoring ? 'animate-bounce' : ''}`} />
                  {isRestoring ? 'משחזר...' : 'בחר קובץ גיבוי'}
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Backup Schedule Recommendation */}
        <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-start gap-3">
            <Clock className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <h4 className="font-semibold text-blue-900">המלצות גיבוי</h4>
              <ul className="text-sm text-blue-800 mt-2 space-y-1">
                <li>• בצע גיבוי יומי בסוף יום העבודה</li>
                <li>• שמור גיבויים במיקום נפרד ובטוח</li>
                <li>• בדוק תקינות הגיבוי מדי פעם</li>
                <li>• גיבוי לפני עדכונים חשובים</li>
              </ul>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
