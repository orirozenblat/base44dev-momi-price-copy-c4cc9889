import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Activity, 
  AlertTriangle, 
  CheckCircle,
  Database,
  HardDrive,
  Wifi,
  Clock,
  RefreshCw
} from "lucide-react";
import DatabaseManager from "../database/DatabaseManager";
import ConnectionMonitor from "../connectivity/ConnectionMonitor";

export default function SystemMonitor() {
  const [systemHealth, setSystemHealth] = useState({
    status: 'checking',
    uptime: 0,
    errors: [],
    performance: {
      responseTime: 0,
      memoryUsage: 0,
      errorRate: 0
    }
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    checkSystemHealth();
    const interval = setInterval(checkSystemHealth, 30000); // Check every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const checkSystemHealth = async () => {
    setIsLoading(true);
    try {
      const startTime = Date.now();
      
      // Test system responsiveness
      const testResponse = await fetch('/api/health').catch(() => ({ ok: false }));
      const responseTime = Date.now() - startTime;
      
      // Get stored errors
      const storedErrors = JSON.parse(localStorage.getItem('app_errors') || '[]');
      const recentErrors = storedErrors.filter(error => 
        new Date(error.timestamp) > new Date(Date.now() - 24 * 60 * 60 * 1000)
      );

      // Calculate error rate
      const errorRate = recentErrors.length / (24 * 60 * 60 / 300); // errors per 5-minute window

      setSystemHealth({
        status: testResponse.ok ? 'healthy' : 'degraded',
        uptime: Date.now() - (performance.timeOrigin || Date.now()),
        errors: recentErrors,
        performance: {
          responseTime,
          memoryUsage: (navigator.deviceMemory || 4) * 1024, // MB
          errorRate: Math.min(errorRate, 100)
        }
      });
    } catch (error) {
      console.error('System health check failed:', error);
      setSystemHealth(prev => ({
        ...prev,
        status: 'error'
      }));
    }
    setIsLoading(false);
  };

  const clearSystemErrors = () => {
    localStorage.removeItem('app_errors');
    setSystemHealth(prev => ({
      ...prev,
      errors: []
    }));
  };

  const getHealthStatusConfig = () => {
    switch (systemHealth.status) {
      case 'healthy':
        return {
          icon: CheckCircle,
          color: 'text-green-600',
          bgColor: 'bg-green-100',
          label: 'תקין'
        };
      case 'degraded':
        return {
          icon: AlertTriangle,
          color: 'text-yellow-600',
          bgColor: 'bg-yellow-100',
          label: 'ביצועים מופחתים'
        };
      case 'error':
        return {
          icon: AlertTriangle,
          color: 'text-red-600',
          bgColor: 'bg-red-100',
          label: 'שגיאה'
        };
      default:
        return {
          icon: Activity,
          color: 'text-gray-600',
          bgColor: 'bg-gray-100',
          label: 'בודק...'
        };
    }
  };

  const formatUptime = (ms) => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days} ימים, ${hours % 24} שעות`;
    if (hours > 0) return `${hours} שעות, ${minutes % 60} דקות`;
    if (minutes > 0) return `${minutes} דקות`;
    return `${seconds} שניות`;
  };

  const healthConfig = getHealthStatusConfig();
  const HealthIcon = healthConfig.icon;

  return (
    <div className="space-y-6">
      {/* System Health Overview */}
      <Card className="shadow-lg border-0 bg-white">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-blue-600" />
              מעקב מערכת
            </CardTitle>
            <Button
              variant="outline"
              size="sm"
              onClick={checkSystemHealth}
              disabled={isLoading}
              className="gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              רענן
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Status Badge */}
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-full ${healthConfig.bgColor}`}>
                <HealthIcon className={`w-5 h-5 ${healthConfig.color}`} />
              </div>
              <div>
                <p className="font-semibold">{healthConfig.label}</p>
                <p className="text-sm text-gray-600">
                  זמן פעילות: {formatUptime(systemHealth.uptime)}
                </p>
              </div>
            </div>

            {/* Performance Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-3 bg-gray-50 rounded-lg">
                <Clock className="w-6 h-6 mx-auto mb-1 text-blue-600" />
                <p className="text-lg font-bold">{systemHealth.performance.responseTime}ms</p>
                <p className="text-xs text-gray-600">זמן תגובה</p>
              </div>
              
              <div className="text-center p-3 bg-gray-50 rounded-lg">
                <HardDrive className="w-6 h-6 mx-auto mb-1 text-purple-600" />
                <p className="text-lg font-bold">{systemHealth.performance.memoryUsage}MB</p>
                <p className="text-xs text-gray-600">זיכרון</p>
              </div>
              
              <div className="text-center p-3 bg-gray-50 rounded-lg">
                <AlertTriangle className="w-6 h-6 mx-auto mb-1 text-red-600" />
                <p className="text-lg font-bold">{systemHealth.errors.length}</p>
                <p className="text-xs text-gray-600">שגיאות (24 שעות)</p>
              </div>
            </div>

            {/* Recent Errors */}
            {systemHealth.errors.length > 0 && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  זוהו {systemHealth.errors.length} שגיאות ב-24 השעות האחרונות
                  <Button
                    variant="link"
                    size="sm"
                    onClick={clearSystemErrors}
                    className="p-0 h-auto mr-2 text-red-800"
                  >
                    נקה שגיאות
                  </Button>
                </AlertDescription>
              </Alert>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Connection Monitor */}
      <Card className="shadow-lg border-0 bg-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Wifi className="w-5 h-5 text-green-600" />
            מעקב חיבור
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ConnectionMonitor />
        </CardContent>
      </Card>

      {/* Database Manager */}
      <DatabaseManager />
    </div>
  );
}