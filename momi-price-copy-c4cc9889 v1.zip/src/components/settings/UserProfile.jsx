import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { User, Save } from "lucide-react";

export default function UserProfile({ user, onSave, isSaving }) {
  const [profileData, setProfileData] = useState({
    full_name: user?.full_name || '',
    phone: user?.phone || '',
    position: user?.position || '',
    department: user?.department || ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(profileData);
  };

  const handleChange = (field, value) => {
    setProfileData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-xl font-bold flex items-center gap-2">
          <User className="w-5 h-5 text-blue-600" />
          פרופיל אישי
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Info */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900">פרטים אישיים</h3>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="full_name">שם מלא</Label>
                <Input
                  id="full_name"
                  value={profileData.full_name}
                  onChange={(e) => handleChange('full_name', e.target.value)}
                  placeholder="הכנס שם מלא"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="email">אימייל</Label>
                <Input
                  id="email"
                  value={user?.email || ''}
                  disabled
                  className="bg-gray-50"
                />
                <p className="text-xs text-gray-500">לא ניתן לשנות את כתובת האימייל</p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="phone">טלפון</Label>
                <Input
                  id="phone"
                  value={profileData.phone}
                  onChange={(e) => handleChange('phone', e.target.value)}
                  placeholder="050-1234567"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="position">תפקיד</Label>
                <Input
                  id="position"
                  value={profileData.position}
                  onChange={(e) => handleChange('position', e.target.value)}
                  placeholder="מנהל רכישות"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="department">מחלקה</Label>
              <Input
                id="department"
                value={profileData.department}
                onChange={(e) => handleChange('department', e.target.value)}
                placeholder="רכישות ולוגיסטיקה"
              />
            </div>
          </div>

          {/* Account Info */}
          <div className="space-y-4 pt-6 border-t">
            <h3 className="font-semibold text-gray-900">מידע חשבון</h3>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>סטטוס חשבון</Label>
                <div className="px-3 py-2 bg-green-50 border border-green-200 rounded-md">
                  <span className="text-green-800 font-medium">פעיל</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>תפקיד במערכת</Label>
                <div className="px-3 py-2 bg-blue-50 border border-blue-200 rounded-md">
                  <span className="text-blue-800 font-medium">
                    {user?.role === 'admin' ? 'מנהל' : 'משתמש'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Save Button */}
          <div className="flex justify-end pt-6 border-t">
            <Button 
              type="submit" 
              disabled={isSaving}
              className="bg-blue-600 hover:bg-blue-700 gap-2"
            >
              <Save className="w-4 h-4" />
              {isSaving ? 'שומר...' : 'שמור שינויים'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}