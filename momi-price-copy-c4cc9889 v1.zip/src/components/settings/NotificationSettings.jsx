import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Bell, Save } from "lucide-react";

export default function NotificationSettings({ user, onSave, isSaving }) {
  const [notificationData, setNotificationData] = useState({
    email_alerts: user?.email_alerts ?? true,
    sms_alerts: user?.sms_alerts ?? false,
    price_alert_threshold: user?.price_alert_threshold ?? 8,
    alert_frequency: user?.alert_frequency || 'immediate',
    daily_summary: user?.daily_summary ?? true,
    weekly_report: user?.weekly_report ?? true,
    critical_alerts_only: user?.critical_alerts_only ?? false
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(notificationData);
  };

  const handleChange = (field, value) => {
    setNotificationData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-xl font-bold flex items-center gap-2">
          <Bell className="w-5 h-5 text-amber-600" />
          הגדרות התראות
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Alert Types */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900">סוגי התראות</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <Label htmlFor="email_alerts" className="font-medium">התראות מייל</Label>
                  <p className="text-sm text-gray-600">קבל התראות חריגי מחיר במייל</p>
                </div>
                <Switch
                  id="email_alerts"
                  checked={notificationData.email_alerts}
                  onCheckedChange={(checked) => handleChange('email_alerts', checked)}
                />
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <Label htmlFor="sms_alerts" className="font-medium">התראות SMS</Label>
                  <p className="text-sm text-gray-600">קבל התראות דחופות בסמס</p>
                </div>
                <Switch
                  id="sms_alerts"
                  checked={notificationData.sms_alerts}
                  onCheckedChange={(checked) => handleChange('sms_alerts', checked)}
                />
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <Label htmlFor="critical_alerts_only" className="font-medium">התראות קריטיות בלבד</Label>
                  <p className="text-sm text-gray-600">רק חריגים של 15% ומעלה</p>
                </div>
                <Switch
                  id="critical_alerts_only"
                  checked={notificationData.critical_alerts_only}
                  onCheckedChange={(checked) => handleChange('critical_alerts_only', checked)}
                />
              </div>
            </div>
          </div>

          {/* Alert Settings */}
          <div className="space-y-4 pt-6 border-t">
            <h3 className="font-semibold text-gray-900">הגדרות התראות</h3>
            
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="price_alert_threshold">סף התראת מחיר (%)</Label>
                <Input
                  id="price_alert_threshold"
                  type="number"
                  min="1"
                  max="50"
                  value={notificationData.price_alert_threshold}
                  onChange={(e) => handleChange('price_alert_threshold', parseInt(e.target.value))}
                />
                <p className="text-xs text-gray-500">התראה כאשר המחיר גבוה בכמה אחוזים</p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="alert_frequency">תדירות התראות</Label>
                <Select 
                  value={notificationData.alert_frequency} 
                  onValueChange={(value) => handleChange('alert_frequency', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="בחר תדירות" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="immediate">מיידי</SelectItem>
                    <SelectItem value="hourly">כל שעה</SelectItem>
                    <SelectItem value="daily">יומי</SelectItem>
                    <SelectItem value="weekly">שבועי</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Reports */}
          <div className="space-y-4 pt-6 border-t">
            <h3 className="font-semibold text-gray-900">דוחות</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <Label htmlFor="daily_summary" className="font-medium">סיכום יומי</Label>
                  <p className="text-sm text-gray-600">סיכום פעילות יומית במייל</p>
                </div>
                <Switch
                  id="daily_summary"
                  checked={notificationData.daily_summary}
                  onCheckedChange={(checked) => handleChange('daily_summary', checked)}
                />
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <Label htmlFor="weekly_report" className="font-medium">דוח שבועי</Label>
                  <p className="text-sm text-gray-600">דוח מפורט של חיסכון וביצועים</p>
                </div>
                <Switch
                  id="weekly_report"
                  checked={notificationData.weekly_report}
                  onCheckedChange={(checked) => handleChange('weekly_report', checked)}
                />
              </div>
            </div>
          </div>

          {/* Save Button */}
          <div className="flex justify-end pt-6 border-t">
            <Button 
              type="submit" 
              disabled={isSaving}
              className="bg-amber-600 hover:bg-amber-700 gap-2"
            >
              <Save className="w-4 h-4" />
              {isSaving ? 'שומר...' : 'שמור הגדרות'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}