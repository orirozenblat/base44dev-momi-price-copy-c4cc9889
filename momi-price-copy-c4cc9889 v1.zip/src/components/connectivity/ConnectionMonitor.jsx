import React, { useState, useEffect } from 'react';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Wifi, 
  WifiOff, 
  Database, 
  Activity,
  AlertTriangle,
  CheckCircle,
  Clock
} from "lucide-react";
import { User } from "@/components/utils/entityImports";

export default function ConnectionMonitor() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [dbStatus, setDbStatus] = useState('unknown');
  const [lastSync, setLastSync] = useState(null);
  const [retryQueue, setRetryQueue] = useState([]);
  const [syncInProgress, setSyncInProgress] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      checkDatabaseConnection();
      processRetryQueue();
    };
    
    const handleOffline = () => {
      setIsOnline(false);
      setDbStatus('offline');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Initial check
    checkDatabaseConnection();

    // Periodic health check every 30 seconds
    const healthInterval = setInterval(checkDatabaseConnection, 30000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(healthInterval);
    };
  }, []);

  const checkDatabaseConnection = async () => {
    if (!isOnline) {
      setDbStatus('offline');
      return;
    }

    try {
      setDbStatus('checking');
      await User.list();
      setDbStatus('connected');
      setLastSync(new Date().toISOString());
    } catch (error) {
      console.error('Database connection check failed:', error);
      setDbStatus('error');
    }
  };

  const processRetryQueue = async () => {
    if (retryQueue.length === 0 || syncInProgress) return;

    setSyncInProgress(true);
    const processedItems = [];

    for (const queueItem of retryQueue) {
      try {
        await queueItem.operation();
        processedItems.push(queueItem.id);
      } catch (error) {
        console.error('Failed to process queued item:', queueItem.id, error);
      }
    }

    setRetryQueue(prev => prev.filter(item => !processedItems.includes(item.id)));
    setSyncInProgress(false);

    if (processedItems.length > 0) {
      console.log(`Processed ${processedItems.length} queued operations`);
    }
  };

  const addToRetryQueue = (operation, description) => {
    const queueItem = {
      id: `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      operation,
      description,
      timestamp: new Date().toISOString()
    };
    
    setRetryQueue(prev => [...prev, queueItem]);
  };

  const getNetworkStatusConfig = () => {
    if (!isOnline) {
      return {
        icon: WifiOff,
        color: 'text-red-600',
        bgColor: 'bg-red-100',
        label: 'לא מקוון'
      };
    }
    
    return {
      icon: Wifi,
      color: 'text-green-600',
      bgColor: 'bg-green-100',
      label: 'מקוון'
    };
  };

  const getDatabaseStatusConfig = () => {
    switch (dbStatus) {
      case 'connected':
        return {
          icon: CheckCircle,
          color: 'text-green-600',
          bgColor: 'bg-green-100',
          label: 'מחובר'
        };
      case 'error':
        return {
          icon: AlertTriangle,
          color: 'text-red-600',
          bgColor: 'bg-red-100',
          label: 'שגיאה'
        };
      case 'checking':
        return {
          icon: Activity,
          color: 'text-yellow-600',
          bgColor: 'bg-yellow-100',
          label: 'בודק...'
        };
      default:
        return {
          icon: Database,
          color: 'text-gray-600',
          bgColor: 'bg-gray-100',
          label: 'לא ידוע'
        };
    }
  };

  const networkConfig = getNetworkStatusConfig();
  const dbConfig = getDatabaseStatusConfig();
  const NetworkIcon = networkConfig.icon;
  const DbIcon = dbConfig.icon;

  // Only show if there are connection issues
  if (isOnline && dbStatus === 'connected' && retryQueue.length === 0) {
    return null;
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 max-w-xs">
      <Card className="shadow-lg border-0 bg-white/90 backdrop-blur-sm">
        <CardContent className="p-3">
          <div className="flex items-center gap-2 text-sm">
            <Badge className={`${networkConfig.bgColor} ${networkConfig.color} border-0`}>
              <NetworkIcon className="w-3 h-3 mr-1" />
              {networkConfig.label}
            </Badge>
            
            <Badge className={`${dbConfig.bgColor} ${dbConfig.color} border-0`}>
              <DbIcon className={`w-3 h-3 mr-1 ${dbStatus === 'checking' ? 'animate-spin' : ''}`} />
              {dbConfig.label}
            </Badge>

            {retryQueue.length > 0 && (
              <Badge className="bg-orange-100 text-orange-800 border-0">
                <Clock className="w-3 h-3 mr-1" />
                {retryQueue.length}
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}