import React from 'react';
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Clock } from "lucide-react";

export default function RetryQueueStatus() {
  // Simple placeholder - would integrate with actual retry queue
  return null;
}