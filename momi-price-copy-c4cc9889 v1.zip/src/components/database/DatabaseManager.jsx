
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Database, 
  CheckCircle, 
  AlertTriangle, 
  RefreshCw,
  Activity,
  Users,
  Package,
  FileText,
  Truck
} from "lucide-react";
import { Invoice, InvoiceItem, Product, Supplier, User } from "@/components/utils/entityImports";

export default function DatabaseManager() {
  const [dbStats, setDbStats] = useState({
    users: 0,
    suppliers: 0,
    products: 0,
    invoices: 0,
    invoiceItems: 0,
    lastSync: null
  });
  const [isLoading, setIsLoading] = useState(true);
  const [connectionStatus, setConnectionStatus] = useState('checking');
  const [lastError, setLastError] = useState(null);

  useEffect(() => {
    checkDatabaseConnection();
    loadDatabaseStats();
  }, []);

  const checkDatabaseConnection = async () => {
    try {
      setConnectionStatus('checking');
      // Test database connection by attempting to list users
      await User.list();
      setConnectionStatus('connected');
      setLastError(null);
    } catch (error) {
      console.error('Database connection error:', error);
      setConnectionStatus('error');
      setLastError(error.message);
    }
  };

  const loadDatabaseStats = async () => {
    setIsLoading(true);
    try {
      const [
        users,
        suppliers,
        products,
        invoices,
        invoiceItems
      ] = await Promise.all([
        User.list().catch(() => []),
        Supplier.list().catch(() => []),
        Product.list().catch(() => []),
        Invoice.list().catch(() => []),
        InvoiceItem.list().catch(() => [])
      ]);

      setDbStats({
        users: users.length,
        suppliers: suppliers.length,
        products: products.length,
        invoices: invoices.length,
        invoiceItems: invoiceItems.length,
        lastSync: new Date().toISOString()
      });
    } catch (error) {
      console.error('Error loading database stats:', error);
    }
    setIsLoading(false);
  };

  const initializeDatabase = async () => {
    try {
      setIsLoading(true);
      
      // Create default admin user if none exists
      const users = await User.list();
      if (users.length === 0) {
        await User.create({
          full_name: "מנהל מערכת",
          email: "admin@momi.app",
          role: "admin",
          store_id: "main_store",
          preferences: {
            notifications_enabled: true,
            email_alerts: true,
            language: "he"
          }
        });
      }

      // Create sample supplier if none exists
      const suppliers = await Supplier.list();
      if (suppliers.length === 0) {
        await Supplier.bulkCreate([
          {
            name: "תנובה",
            contact_person: "יוסי כהן",
            phone: "03-1234567",
            email: "orders@tnuva.co.il",
            payment_terms: "שוטף + 30",
            is_active: true
          },
          {
            name: "שטראוס",
            contact_person: "רחל לוי",
            phone: "04-9876543",
            email: "sales@strauss.co.il",
            payment_terms: "שוטף + 45",
            is_active: true
          }
        ]);
      }

      await loadDatabaseStats();
      await checkDatabaseConnection();
      
      alert('מסד הנתונים אותחל בהצלחה!');
    } catch (error) {
      console.error('Database initialization error:', error);
      alert('שגיאה באתחול מסד הנתונים: ' + error.message);
    }
    setIsLoading(false);
  };

  const clearDatabase = async () => {
    if (!confirm('האם אתה בטוח שברצונך למחוק את כל הנתונים? פעולה זו לא ניתנת לביטול!')) {
      return;
    }

    try {
      setIsLoading(true);
      
      // Note: We can't actually delete all records with the current API
      // This would need to be implemented on the backend
      alert('פונקציית מחיקה זו תהיה זמינה בגרסה הבאה');
      
    } catch (error) {
      console.error('Clear database error:', error);
      alert('שגיאה במחיקת מסד הנתונים: ' + error.message);
    }
    setIsLoading(false);
  };

  const getConnectionStatusConfig = () => {
    switch (connectionStatus) {
      case 'connected':
        return {
          icon: CheckCircle,
          color: 'text-green-600',
          bgColor: 'bg-green-100',
          label: 'מחובר'
        };
      case 'error':
        return {
          icon: AlertTriangle,
          color: 'text-red-600',
          bgColor: 'bg-red-100',
          label: 'שגיאה'
        };
      default:
        return {
          icon: RefreshCw,
          color: 'text-yellow-600',
          bgColor: 'bg-yellow-100',
          label: 'בודק...'
        };
    }
  };

  const statusConfig = getConnectionStatusConfig();
  const StatusIcon = statusConfig.icon;

  return (
    <div className="space-y-6">
      {/* Connection Status */}
      <Card className="shadow-lg border-0 bg-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5 text-blue-600" />
            סטטוס מסד נתונים
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-full ${statusConfig.bgColor}`}>
                <StatusIcon className={`w-5 h-5 ${statusConfig.color} ${connectionStatus === 'checking' ? 'animate-spin' : ''}`} />
              </div>
              <div>
                <p className="font-semibold">{statusConfig.label}</p>
                {lastError && (
                  <p className="text-sm text-red-600">{lastError}</p>
                )}
                {dbStats.lastSync && (
                  <p className="text-xs text-gray-500">
                    עדכון אחרון: {new Date(dbStats.lastSync).toLocaleString('he-IL')}
                  </p>
                )}
              </div>
            </div>
            <Button
              variant="outline"
              onClick={checkDatabaseConnection}
              disabled={isLoading}
              className="gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              בדוק חיבור
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Database Statistics */}
      <Card className="shadow-lg border-0 bg-white">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-purple-600" />
            סטטיסטיקות מסד נתונים
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <Users className="w-8 h-8 mx-auto mb-2 text-blue-600" />
              <p className="text-2xl font-bold">{dbStats.users}</p>
              <p className="text-sm text-gray-600">משתמשים</p>
            </div>
            
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <Truck className="w-8 h-8 mx-auto mb-2 text-green-600" />
              <p className="text-2xl font-bold">{dbStats.suppliers}</p>
              <p className="text-sm text-gray-600">ספקים</p>
            </div>
            
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <Package className="w-8 h-8 mx-auto mb-2 text-purple-600" />
              <p className="text-2xl font-bold">{dbStats.products}</p>
              <p className="text-sm text-gray-600">מוצרים</p>
            </div>
            
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <FileText className="w-8 h-8 mx-auto mb-2 text-orange-600" />
              <p className="text-2xl font-bold">{dbStats.invoices}</p>
              <p className="text-sm text-gray-600">חשבוניות</p>
            </div>
            
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <Activity className="w-8 h-8 mx-auto mb-2 text-red-600" />
              <p className="text-2xl font-bold">{dbStats.invoiceItems}</p>
              <p className="text-sm text-gray-600">פריטי חשבונית</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Database Actions */}
      <Card className="shadow-lg border-0 bg-white">
        <CardHeader>
          <CardTitle>פעולות מסד נתונים</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                פעולות אלו משפיעות על כל הנתונים במערכת. השתמש בזהירות!
              </AlertDescription>
            </Alert>
            
            <div className="flex flex-wrap gap-3">
              <Button
                onClick={initializeDatabase}
                disabled={isLoading}
                className="bg-blue-600 hover:bg-blue-700 gap-2"
              >
                <Database className="w-4 h-4" />
                אתחל מסד נתונים
              </Button>
              
              <Button
                variant="outline"
                onClick={loadDatabaseStats}
                disabled={isLoading}
                className="gap-2"
              >
                <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
                רענן נתונים
              </Button>
              
              <Button
                variant="destructive"
                onClick={clearDatabase}
                disabled={isLoading}
                className="gap-2"
              >
                <AlertTriangle className="w-4 h-4" />
                נקה מסד נתונים
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
