import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Loader2, AlertTriangle } from "lucide-react";

// Global loading overlay
export function GlobalLoader({ message = "טוען...", subMessage = null }) {
  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center" dir="rtl">
      <Card className="w-80 shadow-2xl">
        <CardContent className="p-8 text-center">
          <div className="flex flex-col items-center space-y-4">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
            <div>
              <h3 className="font-semibold text-lg">{message}</h3>
              {subMessage && (
                <p className="text-sm text-gray-600 mt-1">{subMessage}</p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Page-level loading skeleton
export function PageLoader({ title = "טוען נתונים..." }) {
  return (
    <div className="p-4 md:p-8 bg-gradient-to-br from-gray-50 to-blue-50 min-h-screen" dir="rtl">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <Skeleton className="h-8 w-64 mb-2" />
          <Skeleton className="h-4 w-96" />
        </div>
        
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-4">
                  <Skeleton className="h-6 w-48" />
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-3/4" />
                      <Skeleton className="h-4 w-1/2" />
                    </div>
                    <div className="space-y-3">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-2/3" />
                      <Skeleton className="h-4 w-3/4" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-3">
                  <Skeleton className="h-5 w-32" />
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

// List loading skeleton
export function ListLoader({ itemCount = 5, showHeader = true }) {
  return (
    <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
      {showHeader && (
        <div className="p-6 border-b">
          <Skeleton className="h-6 w-48" />
        </div>
      )}
      <CardContent className="p-6">
        <div className="space-y-4">
          {Array(itemCount).fill(0).map((_, i) => (
            <div key={i} className="flex items-center justify-between p-4 border rounded-xl">
              <div className="flex items-center gap-4 flex-1">
                <Skeleton className="w-12 h-12 rounded-xl" />
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-3 w-1/2" />
                </div>
              </div>
              <div className="text-right space-y-1">
                <Skeleton className="h-4 w-16" />
                <Skeleton className="h-3 w-12" />
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// Operation loading state
export function OperationLoader({ 
  operation = "מבצע פעולה...", 
  progress = null, 
  canCancel = false, 
  onCancel = null 
}) {
  return (
    <div className="fixed inset-0 bg-black/30 backdrop-blur-sm z-40 flex items-center justify-center" dir="rtl">
      <Card className="w-96 shadow-xl">
        <CardContent className="p-6">
          <div className="text-center space-y-4">
            <div className="flex justify-center">
              <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
            </div>
            <div>
              <h3 className="font-semibold">{operation}</h3>
              {progress !== null && (
                <div className="mt-2">
                  <div className="bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{progress}%</p>
                </div>
              )}
            </div>
            {canCancel && onCancel && (
              <button
                onClick={onCancel}
                className="text-sm text-gray-500 hover:text-gray-700 underline"
              >
                ביטול
              </button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Error state component
export function ErrorState({ 
  title = "שגיאה", 
  message = "אירעה שגיאה לא צפויה", 
  onRetry = null,
  showDetails = false,
  details = null 
}) {
  return (
    <Card className="shadow-lg border-red-200 bg-red-50">
      <CardContent className="p-8 text-center">
        <AlertTriangle className="w-12 h-12 mx-auto mb-4 text-red-500" />
        <h3 className="text-lg font-semibold text-red-900 mb-2">{title}</h3>
        <p className="text-red-700 mb-4">{message}</p>
        
        {showDetails && details && (
          <details className="text-right mb-4">
            <summary className="cursor-pointer text-sm text-red-600 hover:text-red-800">
              הצג פרטים טכניים
            </summary>
            <pre className="mt-2 text-xs bg-red-100 p-2 rounded overflow-auto max-h-32 text-right">
              {typeof details === 'string' ? details : JSON.stringify(details, null, 2)}
            </pre>
          </details>
        )}
        
        {onRetry && (
          <button
            onClick={onRetry}
            className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition-colors"
          >
            נסה שוב
          </button>
        )}
      </CardContent>
    </Card>
  );
}