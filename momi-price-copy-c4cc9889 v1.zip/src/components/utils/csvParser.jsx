export const parseCsv = (csvText) => {
  const lines = csvText.trim().split(/\r\n|\n/);
  if (lines.length < 2) {
    return [];
  }

  // Sanitize headers: trim whitespace, remove quotes, convert to lowercase
  const headers = lines[0].split(',').map(h => 
    h.trim().replace(/^"|"$/g, '').toLowerCase()
  );
  
  const data = [];

  for (let i = 1; i < lines.length; i++) {
    if (!lines[i].trim()) continue; // Skip empty lines

    const values = lines[i].split(',').map(v => v.trim().replace(/^"|"$/g, ''));
    if (values.length === headers.length) {
      const entry = {};
      for (let j = 0; j < headers.length; j++) {
        // use the sanitized, lowercase header as the key
        entry[headers[j]] = values[j]; 
      }
      data.push(entry);
    }
  }
  return data;
};