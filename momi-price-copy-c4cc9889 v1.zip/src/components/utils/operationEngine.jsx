// Intelligent operation cost engine - chooses cheapest viable path
export class OperationEngine {
  static operationCosts = {
    // String operations (cheapest)
    exact_match: 1,
    simple_includes: 2,
    
    // Moderate operations
    basic_similarity: 10,
    cached_lookup: 15,
    
    // Expensive operations
    fuzzy_match: 50,
    nlp_processing: 100,
    ai_extraction: 200
  };

  static cache = new Map();
  static cacheExpiry = new Map();
  static CACHE_TTL = 5 * 60 * 1000; // 5 minutes

  static getCachedResult(key) {
    const now = Date.now();
    if (this.cache.has(key) && this.cacheExpiry.get(key) > now) {
      return this.cache.get(key);
    }
    // Clean expired entries
    if (this.cacheExpiry.has(key)) {
      this.cache.delete(key);
      this.cacheExpiry.delete(key);
    }
    return null;
  }

  static setCachedResult(key, result) {
    this.cache.set(key, result);
    this.cacheExpiry.set(key, Date.now() + this.CACHE_TTL);
  }

  static findBestMatch(searchTerm, items, options = {}) {
    const cacheKey = `match_${searchTerm}_${items.length}`;
    const cached = this.getCachedResult(cacheKey);
    if (cached) return cached;

    const { threshold = 0.8, maxCost = 100 } = options;
    let bestMatch = null;
    let bestScore = 0;
    let totalCost = 0;

    // Step 1: Try exact match (cheapest)
    for (const item of items) {
      if (item.barcode === searchTerm || item.product_title === searchTerm) {
        bestMatch = { item, score: 1.0, method: 'exact_match' };
        totalCost = this.operationCosts.exact_match;
        break;
      }
    }

    // Step 2: Try simple includes (still cheap)
    if (!bestMatch && totalCost + this.operationCosts.simple_includes <= maxCost) {
      const normalized = searchTerm.toLowerCase().trim();
      for (const item of items) {
        if (item.product_title.toLowerCase().includes(normalized)) {
          const score = normalized.length / item.product_title.length;
          if (score > bestScore && score >= threshold) {
            bestMatch = { item, score, method: 'simple_includes' };
            bestScore = score;
          }
        }
      }
      totalCost += this.operationCosts.simple_includes;
    }

    // Step 3: Basic similarity (moderate cost)
    if (!bestMatch && totalCost + this.operationCosts.basic_similarity <= maxCost) {
      for (const item of items) {
        const score = this.calculateBasicSimilarity(searchTerm, item.product_title);
        if (score > bestScore && score >= threshold) {
          bestMatch = { item, score, method: 'basic_similarity' };
          bestScore = score;
        }
      }
      totalCost += this.operationCosts.basic_similarity;
    }

    const result = bestMatch || { item: null, score: 0, method: 'no_match' };
    result.cost = totalCost;
    
    this.setCachedResult(cacheKey, result);
    return result;
  }

  static calculateBasicSimilarity(str1, str2) {
    if (!str1 || !str2) return 0;
    
    const s1 = str1.toLowerCase().trim();
    const s2 = str2.toLowerCase().trim();
    
    if (s1 === s2) return 1;
    
    // Simple Jaccard similarity
    const set1 = new Set(s1.split(' '));
    const set2 = new Set(s2.split(' '));
    const intersection = new Set([...set1].filter(x => set2.has(x)));
    const union = new Set([...set1, ...set2]);
    
    return intersection.size / union.size;
  }

  static shouldUseExpensiveOperation(confidence, threshold = 0.6) {
    return confidence < threshold;
  }

  static cleanupCache() {
    const now = Date.now();
    for (const [key, expiry] of this.cacheExpiry.entries()) {
      if (expiry <= now) {
        this.cache.delete(key);
        this.cacheExpiry.delete(key);
      }
    }
  }
}

// Lightweight text utilities - only what's needed
export class QuickText {
  static normalizeHebrew(text) {
    if (!text) return '';
    return text.replace(/\s+/g, ' ').trim();
  }

  static extractNumbers(text) {
    const matches = text.match(/\d+(?:[.,]\d+)?/g);
    return matches ? matches.map(m => parseFloat(m.replace(',', '.'))) : [];
  }

  static hasHebrewBrand(text, brands = ['תנובה', 'שטראוס', 'אליט']) {
    const normalized = text.toLowerCase();
    return brands.some(brand => normalized.includes(brand.toLowerCase()));
  }
}