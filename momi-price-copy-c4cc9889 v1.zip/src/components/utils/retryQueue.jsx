/**
 * Generic retry queue system for failed database operations
 * Handles offline scenarios and connection failures across the entire app
 */

class RetryQueue {
  constructor() {
    this.queue = [];
    this.isProcessing = false;
    this.retryInterval = null;
    this.maxRetries = 3;
    this.retryDelay = 5000; // 5 seconds
    
    // Load persisted queue from localStorage
    this.loadPersistedQueue();
    
    // Start monitoring connection
    this.startConnectionMonitoring();
  }

  loadPersistedQueue() {
    try {
      const persistedQueue = localStorage.getItem('retryQueue');
      if (persistedQueue) {
        this.queue = JSON.parse(persistedQueue).map(item => ({
          ...item,
          createdAt: new Date(item.createdAt),
          lastAttempt: item.lastAttempt ? new Date(item.lastAttempt) : null
        }));
      }
    } catch (error) {
      console.error('Failed to load persisted retry queue:', error);
      this.queue = [];
    }
  }

  persistQueue() {
    try {
      localStorage.setItem('retryQueue', JSON.stringify(this.queue));
    } catch (error) {
      console.error('Failed to persist retry queue:', error);
    }
  }

  startConnectionMonitoring() {
    const checkConnection = () => {
      if (navigator.onLine && this.queue.length > 0 && !this.isProcessing) {
        this.processQueue();
      }
    };

    window.addEventListener('online', checkConnection);
    
    // Check every 30 seconds for pending operations
    this.retryInterval = setInterval(checkConnection, 30000);
  }

  /**
   * Add a failed operation to the retry queue
   * @param {Object} operation - The operation to retry
   * @param {string} operation.type - Type of operation (create, update, delete)
   * @param {string} operation.entityName - Name of the entity
   * @param {string} operation.method - SDK method name
   * @param {Array} operation.args - Arguments for the method
   * @param {string} operation.id - Unique identifier for this operation
   * @param {Object} operation.metadata - Additional context
   */
  addOperation(operation) {
    const queueItem = {
      ...operation,
      id: operation.id || `${operation.entityName}_${operation.method}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date(),
      attempts: 0,
      lastAttempt: null,
      lastError: null,
      status: 'pending'
    };

    this.queue.push(queueItem);
    this.persistQueue();
    
    console.log(`Added operation to retry queue: ${queueItem.id}`);
    
    // Try to process immediately if online
    if (navigator.onLine && !this.isProcessing) {
      setTimeout(() => this.processQueue(), 1000);
    }

    return queueItem.id;
  }

  async processQueue() {
    if (this.isProcessing || this.queue.length === 0) return;
    
    this.isProcessing = true;
    console.log(`Processing retry queue: ${this.queue.length} operations`);

    const pendingOperations = this.queue.filter(op => op.status === 'pending' && op.attempts < this.maxRetries);
    
    for (const operation of pendingOperations) {
      if (!navigator.onLine) {
        console.log('Lost connection during queue processing, stopping');
        break;
      }

      try {
        await this.executeOperation(operation);
        operation.status = 'completed';
        console.log(`Successfully executed queued operation: ${operation.id}`);
      } catch (error) {
        operation.attempts++;
        operation.lastAttempt = new Date();
        operation.lastError = error.message;
        
        if (operation.attempts >= this.maxRetries) {
          operation.status = 'failed';
          console.error(`Operation failed after ${this.maxRetries} attempts: ${operation.id}`, error);
        } else {
          console.warn(`Operation attempt ${operation.attempts} failed: ${operation.id}`, error);
        }
      }
    }

    // Remove completed or permanently failed operations
    this.queue = this.queue.filter(op => op.status === 'pending');
    this.persistQueue();
    
    this.isProcessing = false;
    
    // Dispatch event for UI updates
    window.dispatchEvent(new CustomEvent('retryQueueUpdate', { 
      detail: { 
        queueLength: this.queue.length,
        completed: pendingOperations.filter(op => op.status === 'completed').length,
        failed: pendingOperations.filter(op => op.status === 'failed').length
      }
    }));
  }

  async executeOperation(operation) {
    // Dynamic entity import
    const entityModule = await import(`@/api/entities/${operation.entityName}`);
    const EntitySDK = entityModule[operation.entityName];
    
    if (!EntitySDK || !EntitySDK[operation.method]) {
      throw new Error(`Invalid entity or method: ${operation.entityName}.${operation.method}`);
    }

    // Execute the operation with original arguments
    return await EntitySDK[operation.method](...operation.args);
  }

  /**
   * Get current queue status for UI display
   */
  getQueueStatus() {
    return {
      total: this.queue.length,
      pending: this.queue.filter(op => op.status === 'pending').length,
      failed: this.queue.filter(op => op.status === 'failed').length,
      isProcessing: this.isProcessing
    };
  }

  /**
   * Clear completed and failed operations
   */
  clearQueue() {
    this.queue = this.queue.filter(op => op.status === 'pending');
    this.persistQueue();
  }

  /**
   * Get detailed queue items for debugging
   */
  getQueueItems() {
    return [...this.queue];
  }

  destroy() {
    if (this.retryInterval) {
      clearInterval(this.retryInterval);
    }
    window.removeEventListener('online', this.checkConnection);
  }
}

// Create singleton instance
const retryQueue = new RetryQueue();

/**
 * Higher-order function to wrap entity operations with retry queue support
 * @param {string} entityName - Name of the entity
 * @param {string} method - Method name
 * @param {Array} args - Method arguments
 * @param {Object} metadata - Additional context
 */
export const withRetryQueue = async (entityName, method, args, metadata = {}) => {
  try {
    // Try the operation immediately
    const entityModule = await import(`@/api/entities/${entityName}`);
    const EntitySDK = entityModule[entityName];
    
    return await EntitySDK[method](...args);
  } catch (error) {
    console.warn(`Operation failed, adding to retry queue: ${entityName}.${method}`, error);
    
    // Add to retry queue
    const operationId = retryQueue.addOperation({
      type: method.startsWith('create') ? 'create' : 
            method.startsWith('update') ? 'update' : 
            method.startsWith('delete') ? 'delete' : 'unknown',
      entityName,
      method,
      args,
      metadata: {
        ...metadata,
        originalError: error.message,
        userAgent: navigator.userAgent,
        timestamp: new Date().toISOString()
      }
    });

    // Re-throw the error so the UI can handle it appropriately
    const queueError = new Error(`Operation queued for retry (ID: ${operationId}). Original error: ${error.message}`);
    queueError.isQueued = true;
    queueError.queueId = operationId;
    throw queueError;
  }
};

export default retryQueue;