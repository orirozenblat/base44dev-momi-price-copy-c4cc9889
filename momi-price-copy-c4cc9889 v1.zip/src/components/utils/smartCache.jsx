// Lightweight cache that stores only essential data to avoid quota issues
export const SmartCache = {
  // Get an item from sessionStorage
  get: (key) => {
    try {
      const itemStr = sessionStorage.getItem(key);
      if (!itemStr) {
        return null;
      }
      const item = JSON.parse(itemStr);
      const now = new Date();
      // Check if the item has expired
      if (now.getTime() > item.expiry) {
        sessionStorage.removeItem(key);
        return null;
      }
      return item.value;
    } catch (error) {
      console.warn('Cache get error:', error);
      return null;
    }
  },

  // Set an item in sessionStorage with size limit check
  set: (key, value, ttl = 300) => { // Default 5 minute cache
    try {
      const now = new Date();
      const item = {
        value: value,
        expiry: now.getTime() + ttl * 1000,
      };
      
      const itemStr = JSON.stringify(item);
      
      // Check if the data is too large (limit to 1MB per item)
      if (itemStr.length > 1024 * 1024) {
        console.warn(`Cache item ${key} too large (${itemStr.length} bytes), skipping cache`);
        return;
      }
      
      sessionStorage.setItem(key, itemStr);
    } catch (error) {
      console.warn('Cache set error:', error);
      // If storage is full, clear some old items and try again
      if (error.name === 'QuotaExceededError') {
        this.cleanup();
        try {
          const item = {
            value: value,
            expiry: now.getTime() + ttl * 1000,
          };
          sessionStorage.setItem(key, JSON.stringify(item));
        } catch (retryError) {
          console.warn('Cache retry failed:', retryError);
        }
      }
    }
  },

  // Remove an item
  remove: (key) => {
    try {
      sessionStorage.removeItem(key);
    } catch (error) {
      console.warn('Cache remove error:', error);
    }
  },

  // Clear expired items to free up space
  cleanup: () => {
    try {
      const now = new Date().getTime();
      const keysToRemove = [];
      
      for (let i = 0; i < sessionStorage.length; i++) {
        const key = sessionStorage.key(i);
        if (key) {
          try {
            const itemStr = sessionStorage.getItem(key);
            const item = JSON.parse(itemStr);
            if (item.expiry && now > item.expiry) {
              keysToRemove.push(key);
            }
          } catch (e) {
            // If we can't parse it, remove it
            keysToRemove.push(key);
          }
        }
      }
      
      keysToRemove.forEach(key => sessionStorage.removeItem(key));
      console.log(`Cleaned up ${keysToRemove.length} expired cache items`);
    } catch (error) {
      console.warn('Cache cleanup error:', error);
    }
  },

  // Get stats about cache usage
  getStats: () => {
    try {
      let totalSize = 0;
      let itemCount = 0;
      
      for (let i = 0; i < sessionStorage.length; i++) {
        const key = sessionStorage.key(i);
        if (key) {
          const value = sessionStorage.getItem(key);
          totalSize += value.length;
          itemCount++;
        }
      }
      
      return {
        itemCount,
        totalSize,
        totalSizeKB: Math.round(totalSize / 1024),
        totalSizeMB: Math.round(totalSize / (1024 * 1024) * 100) / 100
      };
    } catch (error) {
      console.warn('Cache stats error:', error);
      return { itemCount: 0, totalSize: 0, totalSizeKB: 0, totalSizeMB: 0 };
    }
  }
};