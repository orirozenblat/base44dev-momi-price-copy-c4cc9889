
// Centralized entity import utility
// This provides a clean way to import all entities while respecting the /entities JSON-only constraint

export const getEntitySDK = (entityName) => {
  // Dynamic import mapping for entity SDKs
  const entityMap = {
    'User': () => import('@/api/entities'),
    'Supplier': () => import('@/api/entities'), 
    'Product': () => import('@/api/entities'),
    'Invoice': () => import('@/api/entities'),
    'InvoiceItem': () => import('@/api/entities'),
    'Department': () => import('@/api/entities')
  };
  
  return entityMap[entityName]?.() || null;
};

// Static imports for immediate use (recommended approach)
export { User } from '@/api/entities';
export { Supplier } from '@/api/entities';
export { Product } from '@/api/entities';
export { Invoice } from '@/api/entities';
export { InvoiceItem } from '@/api/entities';
export { Department } from '@/api/entities';

// Bulk entity operations utility
export const bulkEntityOperations = {
  async getAllCounts() {
    const { User, Supplier, Product, Invoice, InvoiceItem } = await import('@/components/utils/entityImports');
    
    return {
      users: (await User.list()).length,
      suppliers: (await Supplier.list()).length,
      products: (await Product.list()).length,
      invoices: (await Invoice.list()).length,
      invoiceItems: (await InvoiceItem.list()).length
    };
  },

  async exportAllData() {
    const { User, Supplier, Product, Invoice, InvoiceItem } = await import('@/components/utils/entityImports');
    
    const [users, suppliers, products, invoices, invoiceItems] = await Promise.all([
      User.list().catch(() => []),
      Supplier.list().catch(() => []),
      Product.list().catch(() => []),
      Invoice.list().catch(() => []),
      InvoiceItem.list().catch(() => [])
    ]);

    return {
      users,
      suppliers,
      products,
      invoices,
      invoiceItems,
      exportDate: new Date().toISOString(),
      version: '1.0'
    };
  }
};
