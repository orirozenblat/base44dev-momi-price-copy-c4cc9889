// Enhanced text processing utilities for Hebrew content and NLP features
import { he } from "date-fns/locale";

export class HebrewTextProcessor {
  static cleanHebrewText(text) {
    if (!text) return '';
    
    // Remove common OCR artifacts and normalize Hebrew text
    return text
      .replace(/[״״‟‛„"]/g, '"') // Normalize quotes
      .replace(/[׳'`]/g, "'") // Normalize apostrophes  
      .replace(/[\u200B-\u200D\uFEFF]/g, '') // Remove zero-width characters
      .replace(/\s+/g, ' ') // Normalize whitespace
      .trim();
  }

  static normalizeProductName(name) {
    if (!name) return '';
    
    const cleaned = this.cleanHebrewText(name);
    
    // Common Hebrew abbreviations and their full forms
    const abbreviations = {
      'גר\'': 'גרם',
      'ק"ג': 'קילוגרם', 
      'קג\'': 'קילוגרם',
      'מ"ל': 'מיליליטר',
      'מל\'': 'מיליליטר',
      'ליט\'': 'ליטר',
      'יח\'': 'יחידה',
      'חב\'': 'חבילה',
      'אר\'': 'אריזה'
    };

    let normalized = cleaned;
    Object.entries(abbreviations).forEach(([abbr, full]) => {
      const regex = new RegExp(abbr.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
      normalized = normalized.replace(regex, full);
    });

    return normalized;
  }

  static extractBrandFromTitle(title) {
    if (!title) return '';
    
    const normalized = this.normalizeProductName(title);
    
    // Enhanced brand detection with Hebrew brands
    const hebrewBrands = [
      'תנובה', 'שטראוס', 'אליט', 'קוקה קולה', 'פנטה', 'אסם', 'בישולים',
      'מעדן', 'תרה', 'יוניליוור', 'נסטלה', 'דנונה', 'קפה עלית', 'ויסוצקי',
      'טעמי', 'רמי לוי', 'פריגת', 'זוגלובק', 'ארטיק', 'מילקי', 'קליק',
      'סנו', 'פרי', 'ברקת', 'אורגניק', 'טבעי', 'אקו', 'הרמוניה'
    ];
    
    // Check for exact brand matches
    for (const brand of hebrewBrands) {
      if (normalized.includes(brand)) {
        return brand;
      }
    }
    
    // Extract potential brand from beginning (first 1-2 words)
    const words = normalized.split(' ').filter(w => w.length > 1);
    if (words.length > 0) {
      const firstWords = words.slice(0, 2).join(' ');
      if (firstWords.length >= 2 && firstWords.length <= 15) {
        return firstWords;
      }
    }
    
    return '';
  }

  static extractSizeInfo(text) {
    if (!text) return { value: 1, unit: 'יחידה', confidence: 0.1 };
    
    const normalized = this.normalizeProductName(text);
    
    // Enhanced size patterns for Hebrew content
    const sizePatterns = [
      { pattern: /(\d+(?:[.,]\d+)?)\s*(?:קילוגרם|קילו|ק"?ג|kg)/i, unit: 'קילו', multiplier: 1 },
      { pattern: /(\d+(?:[.,]\d+)?)\s*(?:גרם|גר'?|g)/i, unit: 'גרם', multiplier: 1 },
      { pattern: /(\d+(?:[.,]\d+)?)\s*(?:ליטר|ל'?|liter|l)\b/i, unit: 'ליטר', multiplier: 1 },
      { pattern: /(\d+(?:[.,]\d+)?)\s*(?:מיליליטר|מ"?ל|ml)/i, unit: 'מ״ל', multiplier: 1 },
      { pattern: /(\d+(?:[.,]\d+)?)\s*(?:יחידה|יח'?|unit|חתיכה)/i, unit: 'יחידה', multiplier: 1 },
      { pattern: /(\d+)\s*(?:חבילות?|חב'?|pack)/i, unit: 'חבילה', multiplier: 1 }
    ];
    
    for (const { pattern, unit, multiplier } of sizePatterns) {
      const match = normalized.match(pattern);
      if (match) {
        const value = parseFloat(match[1].replace(',', '.')) * multiplier;
        return { 
          value, 
          unit, 
          confidence: 0.9,
          originalText: match[0]
        };
      }
    }
    
    return { value: 1, unit: 'יחידה', confidence: 0.3 };
  }
}

export class ProductMatcher {
  static calculateAdvancedSimilarity(str1, str2) {
    if (!str1 || !str2) return 0;
    
    const normalized1 = HebrewTextProcessor.normalizeProductName(str1.toLowerCase());
    const normalized2 = HebrewTextProcessor.normalizeProductName(str2.toLowerCase());
    
    // Multiple similarity metrics
    const editDistance = this.getEditDistance(normalized1, normalized2);
    const editSimilarity = (Math.max(normalized1.length, normalized2.length) - editDistance) / Math.max(normalized1.length, normalized2.length);
    
    const tokenSimilarity = this.getTokenSimilarity(normalized1, normalized2);
    const substringBonus = this.getSubstringBonus(normalized1, normalized2);
    
    // Weighted combination
    return (editSimilarity * 0.4 + tokenSimilarity * 0.4 + substringBonus * 0.2);
  }

  static getEditDistance(str1, str2) {
    const matrix = Array(str2.length + 1).fill().map(() => Array(str1.length + 1).fill(0));
    
    for (let i = 0; i <= str1.length; i++) matrix[0][i] = i;
    for (let j = 0; j <= str2.length; j++) matrix[j][0] = j;
    
    for (let j = 1; j <= str2.length; j++) {
      for (let i = 1; i <= str1.length; i++) {
        if (str1[i - 1] === str2[j - 1]) {
          matrix[j][i] = matrix[j - 1][i - 1];
        } else {
          matrix[j][i] = Math.min(
            matrix[j - 1][i] + 1,
            matrix[j][i - 1] + 1,
            matrix[j - 1][i - 1] + 1
          );
        }
      }
    }
    
    return matrix[str2.length][str1.length];
  }

  static getTokenSimilarity(str1, str2) {
    const tokens1 = new Set(str1.split(/\s+/).filter(t => t.length > 1));
    const tokens2 = new Set(str2.split(/\s+/).filter(t => t.length > 1));
    
    const intersection = new Set([...tokens1].filter(x => tokens2.has(x)));
    const union = new Set([...tokens1, ...tokens2]);
    
    return union.size > 0 ? intersection.size / union.size : 0;
  }

  static getSubstringBonus(str1, str2) {
    const longer = str1.length > str2.length ? str1 : str2;
    const shorter = str1.length > str2.length ? str2 : str1;
    
    if (longer.includes(shorter)) return 0.3;
    if (shorter.length > 3 && longer.includes(shorter.substring(0, Math.floor(shorter.length / 2)))) return 0.1;
    
    return 0;
  }
}

export class ConfidenceScorer {
  static calculateOverallConfidence(factors) {
    const {
      ocrConfidence = 0.5,
      productMatchScore = 0,
      priceConsistency = 0.5,
      barcodeMatch = false,
      sizeInfoPresent = false
    } = factors;

    let confidence = 0;
    let totalWeight = 0;

    // OCR confidence (30% weight)
    confidence += ocrConfidence * 0.3;
    totalWeight += 0.3;

    // Product match score (35% weight)
    confidence += productMatchScore * 0.35;
    totalWeight += 0.35;

    // Price consistency (20% weight)  
    confidence += priceConsistency * 0.2;
    totalWeight += 0.2;

    // Bonus factors
    if (barcodeMatch) {
      confidence += 0.1; // 10% bonus for barcode match
      totalWeight += 0.1;
    }

    if (sizeInfoPresent) {
      confidence += 0.05; // 5% bonus for size info
      totalWeight += 0.05;
    }

    return Math.min(confidence / totalWeight, 1.0);
  }

  static determineValidationStatus(confidence, overchargePercentage) {
    if (confidence >= 0.8 && overchargePercentage <= 5) {
      return 'approved';
    } else if (confidence >= 0.6 && overchargePercentage <= 15) {
      return 'flagged';
    } else if (confidence < 0.4) {
      return 'manual_review';
    } else {
      return 'needs_verification';
    }
  }
}

export class PriceAnomalyDetector {
  static isAnomalous(currentPrice, catalogPrice, historicalPrices = [], threshold = 0.08) {
    if (!catalogPrice || catalogPrice <= 0) return { isAnomaly: false, confidence: 0 };

    const priceDifference = currentPrice - catalogPrice;
    const overchargePercentage = (priceDifference / catalogPrice) * 100;

    // Basic threshold check
    if (overchargePercentage <= threshold * 100) {
      return { isAnomaly: false, confidence: 0.9 };
    }

    // Enhanced analysis with historical data
    if (historicalPrices.length > 0) {
      const avgHistoricalPrice = historicalPrices.reduce((sum, p) => sum + p, 0) / historicalPrices.length;
      const historicalVariance = this.calculateVariance(historicalPrices);
      
      // If current price is within 2 standard deviations of historical average, reduce anomaly confidence
      const stdDev = Math.sqrt(historicalVariance);
      const zScore = Math.abs(currentPrice - avgHistoricalPrice) / stdDev;
      
      if (zScore < 2) {
        return { 
          isAnomaly: overchargePercentage > threshold * 100, 
          confidence: Math.max(0.3, 0.9 - (zScore * 0.2)),
          reason: 'within_historical_range'
        };
      }
    }

    return { 
      isAnomaly: true, 
      confidence: Math.min(0.95, 0.5 + (overchargePercentage / 100)),
      overchargePercentage,
      reason: 'exceeds_threshold'
    };
  }

  static calculateVariance(prices) {
    if (prices.length === 0) return 0;
    const mean = prices.reduce((sum, p) => sum + p, 0) / prices.length;
    return prices.reduce((sum, p) => sum + Math.pow(p - mean, 2), 0) / prices.length;
  }
}