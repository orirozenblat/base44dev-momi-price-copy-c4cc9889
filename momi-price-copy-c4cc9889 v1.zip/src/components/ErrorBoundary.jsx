import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle, RefreshCw, Bug, Copy } from "lucide-react";

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { 
      hasError: false, 
      error: null, 
      errorInfo: null,
      errorId: null
    };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    const errorId = `error_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const errorReport = {
      id: errorId,
      timestamp: new Date().toISOString(),
      error: {
        message: error.message,
        stack: error.stack,
        name: error.name
      },
      errorInfo: {
        componentStack: errorInfo.componentStack
      },
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'N/A',
      url: typeof window !== 'undefined' ? window.location.href : 'N/A',
      userId: typeof localStorage !== 'undefined' ? localStorage.getItem('userId') || 'anonymous' : 'N/A',
      sessionId: typeof sessionStorage !== 'undefined' ? sessionStorage.getItem('sessionId') || 'unknown' : 'N/A'
    };

    // Store error in localStorage for debugging
    if (typeof localStorage !== 'undefined') {
      const existingErrors = JSON.parse(localStorage.getItem('app_errors') || '[]');
      existingErrors.push(errorReport);
      if (existingErrors.length > 50) {
        existingErrors.splice(0, existingErrors.length - 50);
      }
      localStorage.setItem('app_errors', JSON.stringify(existingErrors));
    }

    console.error('Error Boundary Caught:', errorReport);
    
    this.setState({
      error,
      errorInfo,
      errorId
    });
  }

  handleReload = () => {
    if (typeof window !== 'undefined') {
      window.location.reload();
    }
  };

  handleRetry = () => {
    this.setState({ 
      hasError: false, 
      error: null, 
      errorInfo: null, 
      errorId: null 
    });
  };

  copyErrorDetails = () => {
    const errorDetails = {
      id: this.state.errorId,
      message: this.state.error?.message,
      stack: this.state.error?.stack,
      componentStack: this.state.errorInfo?.componentStack,
      timestamp: new Date().toISOString(),
      url: typeof window !== 'undefined' ? window.location.href : 'N/A'
    };
    
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(JSON.stringify(errorDetails, null, 2));
      alert('פרטי השגיאה הועתקו ללוח');
    } else {
      console.warn('Clipboard API not available.');
      alert('הדפדפן שלך אינו תומך בהעתקה ללוח.');
    }
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-gradient-to-br from-red-50 to-red-100 p-4 flex items-center justify-center" dir="rtl">
          <Card className="max-w-2xl w-full shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-red-800">
                <AlertTriangle className="w-6 h-6" />
                שגיאה במערכת
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert variant="destructive">
                <Bug className="h-4 w-4" />
                <AlertDescription>
                  <strong>מזהה שגיאה:</strong> {this.state.errorId}
                  <br />
                  <strong>הודעה:</strong> {this.state.error?.message}
                </AlertDescription>
              </Alert>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">מה קרה?</h4>
                <p className="text-sm text-gray-600 mb-3">
                  אירעה שגיאה לא צפויה באפליקציה. הפרטים נשמרו לצורך ניפוי באגים.
                </p>
                
                <div className="flex flex-wrap gap-2">
                  <Button onClick={this.handleRetry} className="gap-2">
                    <RefreshCw className="w-4 h-4" />
                    נסה שוב
                  </Button>
                  <Button variant="outline" onClick={this.handleReload} className="gap-2">
                    <RefreshCw className="w-4 h-4" />
                    רענן דף
                  </Button>
                  <Button variant="outline" onClick={this.copyErrorDetails} className="gap-2">
                    <Copy className="w-4 h-4" />
                    העתק פרטי שגיאה
                  </Button>
                </div>
              </div>

              {typeof window !== 'undefined' && window.location.hostname === 'localhost' && (
                <details className="bg-gray-100 p-3 rounded text-xs">
                  <summary className="cursor-pointer font-semibold">פרטי שגיאה (למפתחים)</summary>
                  <pre className="mt-2 overflow-auto max-h-40">
                    {this.state.error?.stack}
                  </pre>
                  <pre className="mt-2 overflow-auto max-h-40">
                    {this.state.errorInfo?.componentStack}
                  </pre>
                </details>
              )}
            </CardContent>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;